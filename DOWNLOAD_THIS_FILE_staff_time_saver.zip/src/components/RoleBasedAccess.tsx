import { useAuth } from "../hooks/use-auth";
import { UserRoleType } from "../../shared/schema";

// Define the permission structure
export const permissions = {
  // Client management
  VIEW_CLIENTS: "VIEW_CLIENTS",
  CREATE_CLIENT: "CREATE_CLIENT",
  EDIT_CLIENT: "EDIT_CLIENT",
  DELETE_CLIENT: "DELETE_CLIENT",

  // Matter management
  VIEW_MATTERS: "VIEW_MATTERS",
  CREATE_MATTER: "CREATE_MATTER",
  EDIT_MATTER: "EDIT_MATTER",
  DELETE_MATTER: "DELETE_MATTER",

  // Document management
  VIEW_DOCUMENTS: "VIEW_DOCUMENTS",
  UPLOAD_DOCUMENT: "UPLOAD_DOCUMENT",
  REQUEST_SIGNATURE: "REQUEST_SIGNATURE",
  DELETE_DOCUMENT: "DELETE_DOCUMENT",
  ANALYZE_DOCUMENT: "ANALYZE_DOCUMENT",

  // User management
  VIEW_USERS: "VIEW_USERS",
  CREATE_USER: "CREATE_USER",
  EDIT_USER: "EDIT_USER",
  DELETE_USER: "DELETE_USER",

  // Billing
  VIEW_INVOICES: "VIEW_INVOICES",
  CREATE_INVOICE: "CREATE_INVOICE",
  EDIT_INVOICE: "EDIT_INVOICE",
  DELETE_INVOICE: "DELETE_INVOICE",
  
  // Time tracking
  VIEW_TIME_ENTRIES: "VIEW_TIME_ENTRIES",
  CREATE_TIME_ENTRY: "CREATE_TIME_ENTRY",
  EDIT_TIME_ENTRY: "EDIT_TIME_ENTRY",
  DELETE_TIME_ENTRY: "DELETE_TIME_ENTRY",

  // Reports
  VIEW_REPORTS: "VIEW_REPORTS",
  CREATE_REPORT: "CREATE_REPORT",
  EXPORT_REPORT: "EXPORT_REPORT",

  // Settings
  MANAGE_SETTINGS: "MANAGE_SETTINGS",
};

// Define permissions for each role
const rolePermissions: Record<UserRoleType, string[]> = {
  admin: Object.values(permissions), // Admins have all permissions
  
  attorney: [
    // Client permissions
    permissions.VIEW_CLIENTS,
    permissions.CREATE_CLIENT,
    permissions.EDIT_CLIENT,
    
    // Matter permissions
    permissions.VIEW_MATTERS,
    permissions.CREATE_MATTER,
    permissions.EDIT_MATTER,
    
    // Document permissions
    permissions.VIEW_DOCUMENTS,
    permissions.UPLOAD_DOCUMENT,
    permissions.REQUEST_SIGNATURE,
    permissions.ANALYZE_DOCUMENT,
    
    // User management (limited)
    permissions.VIEW_USERS,
    
    // Billing permissions
    permissions.VIEW_INVOICES,
    permissions.CREATE_INVOICE,
    
    // Time tracking
    permissions.VIEW_TIME_ENTRIES,
    permissions.CREATE_TIME_ENTRY,
    permissions.EDIT_TIME_ENTRY,
    
    // Reports
    permissions.VIEW_REPORTS,
    permissions.CREATE_REPORT,
    permissions.EXPORT_REPORT,
  ],
  
  paralegal: [
    // Client permissions
    permissions.VIEW_CLIENTS,
    permissions.CREATE_CLIENT,
    permissions.EDIT_CLIENT,
    
    // Matter permissions
    permissions.VIEW_MATTERS,
    permissions.CREATE_MATTER,
    permissions.EDIT_MATTER,
    
    // Document permissions
    permissions.VIEW_DOCUMENTS,
    permissions.UPLOAD_DOCUMENT,
    permissions.REQUEST_SIGNATURE,
    
    // Time tracking
    permissions.VIEW_TIME_ENTRIES,
    permissions.CREATE_TIME_ENTRY,
    permissions.EDIT_TIME_ENTRY,
    
    // Reports (limited)
    permissions.VIEW_REPORTS,
  ],
  
  staff: [
    // Limited permissions
    permissions.VIEW_CLIENTS,
    permissions.VIEW_MATTERS,
    permissions.VIEW_DOCUMENTS,
    permissions.UPLOAD_DOCUMENT,
    permissions.VIEW_TIME_ENTRIES,
    permissions.CREATE_TIME_ENTRY,
    permissions.EDIT_TIME_ENTRY,
  ],
};

interface RoleBasedAccessProps {
  permission: string;
  children: React.ReactNode;
  fallback?: React.ReactNode;
}

/**
 * Component that conditionally renders children based on whether the 
 * current user has the specified permission.
 * 
 * Example:
 * <RoleBasedAccess permission={permissions.CREATE_CLIENT}>
 *   <Button>Create New Client</Button>
 * </RoleBasedAccess>
 */
export const RoleBasedAccess: React.FC<RoleBasedAccessProps> = ({
  permission,
  children,
  fallback = null,
}) => {
  const hasPermission = useHasPermission(permission);
  return hasPermission ? <>{children}</> : <>{fallback}</>;
};

/**
 * Hook to check if the current user has a specific permission
 * 
 * Example:
 * const canCreateClient = useHasPermission(permissions.CREATE_CLIENT);
 * 
 * if (canCreateClient) {
 *   // Do something...
 * }
 */
export function useHasPermission(permission: string): boolean {
  const { user } = useAuth();
  
  if (!user) {
    return false;
  }
  
  // Type assertion since we know the structure
  const userRole = user.role as UserRoleType;
  
  // Check if the user's role has the required permission
  return rolePermissions[userRole]?.includes(permission) || false;
}