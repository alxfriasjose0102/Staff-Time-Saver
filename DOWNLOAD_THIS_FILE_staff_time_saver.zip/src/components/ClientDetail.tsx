import React from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { Loader2, Mail, Phone, Building, MapPin, FileText, Edit, Trash2, ArrowLeft, Clock } from 'lucide-react';
import { Button } from './ui/button';
import { formatDate } from '../lib/utils';
import { useToast } from '../hooks/use-toast';

interface Matter {
  id: number;
  title: string;
  description?: string;
  type: string;
  createdAt: string;
}

interface Client {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  company?: string;
  address?: string;
  city?: string;
  state?: string;
  zipCode?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
  matters: Matter[];
}

interface ClientDetailProps {
  clientId: number;
  onBack: () => void;
  onEdit: (id: number) => void;
}

export const ClientDetail: React.FC<ClientDetailProps> = ({ clientId, onBack, onEdit }) => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Fetch client details
  const { data: client, isLoading, error } = useQuery<Client>({
    queryKey: ['/api/clients', clientId],
    queryFn: async () => {
      const response = await fetch(`/api/clients/${clientId}`, {
        credentials: 'include',
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch client details');
      }
      
      return response.json();
    },
  });
  
  // Delete client mutation
  const deleteClientMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch(`/api/clients/${clientId}`, {
        method: 'DELETE',
        credentials: 'include',
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to delete client');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/clients'] });
      toast({
        title: 'Success',
        description: 'Client has been successfully deleted',
        variant: 'success',
      });
      onBack();
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    }
  });
  
  // Handle delete confirmation
  const handleDelete = () => {
    if (window.confirm(t('clients.deleteConfirmation'))) {
      deleteClientMutation.mutate();
    }
  };
  
  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
      </div>
    );
  }
  
  if (error || !client) {
    return (
      <div className="flex h-64 flex-col items-center justify-center text-center">
        <p className="text-lg font-medium text-red-500 mb-4">
          {t('clients.errorLoadingDetail')}
        </p>
        <p className="text-gray-500 dark:text-gray-400 mb-6">
          {(error as Error)?.message || t('clients.clientNotFound')}
        </p>
        <Button onClick={onBack} variant="outline">
          <ArrowLeft className="h-4 w-4 mr-2" />
          {t('common.back')}
        </Button>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      {/* Header with actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center">
          <Button variant="ghost" onClick={onBack} className="mr-2 p-2">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-2xl font-bold">{client.firstName} {client.lastName}</h1>
        </div>
        
        <div className="flex space-x-2">
          <Button variant="outline" onClick={() => onEdit(client.id)}>
            <Edit className="h-4 w-4 mr-2" />
            {t('common.edit')}
          </Button>
          <Button variant="outline" className="text-red-600 border-red-600 hover:bg-red-50 dark:hover:bg-red-900" onClick={handleDelete}>
            <Trash2 className="h-4 w-4 mr-2" />
            {t('common.delete')}
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main client information */}
        <div className="lg:col-span-2 space-y-6">
          {/* Basic information */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
            <h2 className="text-lg font-semibold mb-4">{t('clients.basicInformation')}</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-y-4">
              <div className="flex items-start">
                <Mail className="h-5 w-5 text-gray-400 mr-2 mt-0.5" />
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{t('clients.email')}</p>
                  <p className="font-medium">{client.email}</p>
                </div>
              </div>
              
              {client.phone && (
                <div className="flex items-start">
                  <Phone className="h-5 w-5 text-gray-400 mr-2 mt-0.5" />
                  <div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{t('clients.phone')}</p>
                    <p className="font-medium">{client.phone}</p>
                  </div>
                </div>
              )}
              
              {client.company && (
                <div className="flex items-start">
                  <Building className="h-5 w-5 text-gray-400 mr-2 mt-0.5" />
                  <div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{t('clients.company')}</p>
                    <p className="font-medium">{client.company}</p>
                  </div>
                </div>
              )}
              
              <div className="flex items-start">
                <Clock className="h-5 w-5 text-gray-400 mr-2 mt-0.5" />
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{t('clients.clientSince')}</p>
                  <p className="font-medium">{formatDate(new Date(client.createdAt))}</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Address */}
          {(client.address || client.city || client.state || client.zipCode) && (
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
              <h2 className="text-lg font-semibold mb-4">{t('clients.address')}</h2>
              
              <div className="flex items-start">
                <MapPin className="h-5 w-5 text-gray-400 mr-2 mt-0.5" />
                <div>
                  {client.address && <p className="font-medium">{client.address}</p>}
                  {(client.city || client.state || client.zipCode) && (
                    <p className="font-medium">
                      {[
                        client.city,
                        client.state,
                        client.zipCode
                      ].filter(Boolean).join(', ')}
                    </p>
                  )}
                </div>
              </div>
            </div>
          )}
          
          {/* Notes */}
          {client.notes && (
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
              <h2 className="text-lg font-semibold mb-4">{t('clients.notes')}</h2>
              <p className="whitespace-pre-line">{client.notes}</p>
            </div>
          )}
        </div>
        
        {/* Matters sidebar */}
        <div className="space-y-6">
          {/* Matters list */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">{t('clients.matters')}</h2>
              <Button variant="outline" size="sm">
                <FileText className="h-4 w-4 mr-2" />
                {t('clients.newMatter')}
              </Button>
            </div>
            
            {client.matters && client.matters.length > 0 ? (
              <div className="space-y-4">
                {client.matters.map(matter => (
                  <div 
                    key={matter.id} 
                    className="p-4 border border-gray-200 dark:border-gray-700 rounded-md hover:bg-gray-50 dark:hover:bg-gray-750 cursor-pointer transition-colors"
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium">{matter.title}</h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{matter.type}</p>
                      </div>
                      <div className="text-xs text-gray-500 dark:text-gray-400">
                        {formatDate(new Date(matter.createdAt))}
                      </div>
                    </div>
                    {matter.description && (
                      <p className="text-sm mt-2 line-clamp-2">{matter.description}</p>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6">
                <FileText className="h-10 w-10 text-gray-300 dark:text-gray-600 mx-auto mb-2" />
                <p className="text-gray-500 dark:text-gray-400">{t('clients.noMatters')}</p>
              </div>
            )}
          </div>
          
          {/* Activity & documents placeholder */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
            <h2 className="text-lg font-semibold mb-4">{t('clients.recentActivity')}</h2>
            <div className="text-center py-6">
              <p className="text-gray-500 dark:text-gray-400 text-sm">
                {t('clients.activityComingSoon')}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};