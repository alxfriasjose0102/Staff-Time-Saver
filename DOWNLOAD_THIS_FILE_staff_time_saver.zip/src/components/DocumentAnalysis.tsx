import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { useToast } from '../hooks/use-toast';
import { Skeleton } from './ui/skeleton';
import { BarChart, FileText, AlertTriangle, CheckCircle, RefreshCw, GitCompare } from 'lucide-react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { apiRequest } from '../lib/queryClient';
import { Badge } from './ui/badge';
import { Alert, AlertDescription, AlertTitle } from './ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';

interface DocumentAnalysisResult {
  summary: string;
  keyPoints: string[];
  legalRisks: {
    risk: string;
    severity: 'low' | 'medium' | 'high';
    suggestion: string;
  }[];
  nextSteps: string[];
  relevantCaseLaw?: string[];
  confidenceScore: number;
}

interface DocumentMetadata {
  documentType: string;
  parties: string[];
  effectiveDate?: string;
  expirationDate?: string;
  jurisdiction?: string;
  governingLaw?: string;
  keyProvisions: string[];
  [key: string]: any;
}

interface Document {
  id: number;
  title: string;
  fileName?: string;
  fileUrl?: string;
  status: string;
}

interface DocumentComparisonResult {
  similarities: string[];
  differences: string[];
  recommendations: string[];
}

interface DocumentAnalysisProps {
  document: Document;
  otherDocuments?: Document[];
}

export const DocumentAnalysis: React.FC<DocumentAnalysisProps> = ({ document, otherDocuments = [] }) => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [selectedComparisonDocId, setSelectedComparisonDocId] = useState<number | null>(null);
  
  // Fetch document analysis
  const { 
    data: analysis,
    isLoading: isAnalysisLoading,
    isError: isAnalysisError,
    refetch: refetchAnalysis
  } = useQuery<DocumentAnalysisResult>({
    queryKey: [`/api/documents/${document.id}/analyze`],
    queryFn: async () => {
      const res = await apiRequest('POST', `/api/documents/${document.id}/analyze`);
      if (!res.ok) {
        throw new Error('Failed to analyze document');
      }
      return res.json();
    },
    enabled: false, // Don't run query on component mount
  });
  
  // Fetch document metadata
  const { 
    data: metadata,
    isLoading: isMetadataLoading,
    isError: isMetadataError,
    refetch: refetchMetadata
  } = useQuery<DocumentMetadata>({
    queryKey: [`/api/documents/${document.id}/extract-metadata`],
    queryFn: async () => {
      const res = await apiRequest('POST', `/api/documents/${document.id}/extract-metadata`);
      if (!res.ok) {
        throw new Error('Failed to extract document metadata');
      }
      return res.json();
    },
    enabled: false, // Don't run query on component mount
  });
  
  // Fetch document summary
  const { 
    data: summary,
    isLoading: isSummaryLoading,
    isError: isSummaryError,
    refetch: refetchSummary
  } = useQuery<{ summary: string }>({
    queryKey: [`/api/documents/${document.id}/summarize`],
    queryFn: async () => {
      const res = await apiRequest('POST', `/api/documents/${document.id}/summarize`);
      if (!res.ok) {
        throw new Error('Failed to summarize document');
      }
      return res.json();
    },
    enabled: false, // Don't run query on component mount
  });
  
  // Document comparison mutation
  const {
    mutate: compareDocuments,
    data: comparisonResult,
    isPending: isComparisonLoading,
    isError: isComparisonError,
    reset: resetComparison
  } = useMutation<
    DocumentComparisonResult, 
    Error,
    { document1Id: number, document2Id: number }
  >({
    mutationFn: async ({ document1Id, document2Id }) => {
      const res = await apiRequest('POST', `/api/documents/compare`, { document1Id, document2Id });
      if (!res.ok) {
        throw new Error('Failed to compare documents');
      }
      return res.json();
    },
  });
  
  // Handle document analysis
  const handleAnalyzeDocument = () => {
    refetchAnalysis();
    toast({
      title: t('documentAnalysis.analyzing'),
      description: t('documentAnalysis.pleaseWait'),
    });
  };
  
  // Handle metadata extraction
  const handleExtractMetadata = () => {
    refetchMetadata();
    toast({
      title: t('documentAnalysis.extractingMetadata'),
      description: t('documentAnalysis.pleaseWait'),
    });
  };
  
  // Handle document summarization
  const handleSummarizeDocument = () => {
    refetchSummary();
    toast({
      title: t('documentAnalysis.summarizing'),
      description: t('documentAnalysis.pleaseWait'),
    });
  };
  
  // Handle document comparison
  const handleCompareDocuments = () => {
    if (!selectedComparisonDocId) {
      toast({
        title: t('documentAnalysis.selectDocumentError'),
        description: t('documentAnalysis.pleaseSelectDocument'),
        variant: 'destructive',
      });
      return;
    }
    
    compareDocuments({ 
      document1Id: document.id, 
      document2Id: selectedComparisonDocId 
    });
    
    toast({
      title: t('documentAnalysis.comparing'),
      description: t('documentAnalysis.pleaseWait'),
    });
  };
  
  // Render severity badge
  const renderSeverityBadge = (severity: 'low' | 'medium' | 'high') => {
    const color = severity === 'high' ? 'destructive' : severity === 'medium' ? 'warning' : 'secondary';
    return (
      <Badge variant={color as any}>
        {t(`documentAnalysis.severity.${severity}`)}
      </Badge>
    );
  };
  
  return (
    <Tabs defaultValue="summary" className="w-full">
      <TabsList className="grid grid-cols-4">
        <TabsTrigger value="summary">
          {t('documentAnalysis.tabs.summary')}
        </TabsTrigger>
        <TabsTrigger value="analysis">
          {t('documentAnalysis.tabs.analysis')}
        </TabsTrigger>
        <TabsTrigger value="metadata">
          {t('documentAnalysis.tabs.metadata')}
        </TabsTrigger>
        <TabsTrigger value="compare">
          {t('documentAnalysis.tabs.compare')}
        </TabsTrigger>
      </TabsList>
      
      {/* Summary Tab */}
      <TabsContent value="summary" className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle>{t('documentAnalysis.summary.title')}</CardTitle>
            <CardDescription>
              {t('documentAnalysis.summary.description')}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isSummaryLoading ? (
              <div className="space-y-2">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-5/6" />
              </div>
            ) : summary ? (
              <div className="prose max-w-none dark:prose-invert">
                <p className="text-lg">{summary.summary}</p>
              </div>
            ) : (
              <div className="text-center py-8">
                <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">
                  {t('documentAnalysis.summary.noSummary')}
                </p>
              </div>
            )}
          </CardContent>
          <CardFooter>
            <Button 
              onClick={handleSummarizeDocument} 
              disabled={isSummaryLoading}
              className="ml-auto"
            >
              {isSummaryLoading && <RefreshCw className="mr-2 h-4 w-4 animate-spin" />}
              {isSummaryLoading ? t('common.processing') : t('documentAnalysis.summary.summarize')}
            </Button>
          </CardFooter>
        </Card>
      </TabsContent>
      
      {/* Analysis Tab */}
      <TabsContent value="analysis" className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle>{t('documentAnalysis.analysis.title')}</CardTitle>
            <CardDescription>
              {t('documentAnalysis.analysis.description')}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isAnalysisLoading ? (
              <div className="space-y-4">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-24 w-full" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-12 w-full" />
              </div>
            ) : analysis ? (
              <div className="space-y-6">
                {/* Key Points */}
                <div>
                  <h3 className="text-lg font-semibold mb-2">
                    {t('documentAnalysis.analysis.keyPoints')}
                  </h3>
                  <ul className="list-disc pl-5 space-y-1">
                    {analysis.keyPoints.map((point, index) => (
                      <li key={index}>{point}</li>
                    ))}
                  </ul>
                </div>
                
                {/* Legal Risks */}
                <div>
                  <h3 className="text-lg font-semibold mb-2">
                    {t('documentAnalysis.analysis.legalRisks')}
                  </h3>
                  {analysis.legalRisks.length > 0 ? (
                    <div className="space-y-3">
                      {analysis.legalRisks.map((risk, index) => (
                        <Alert key={index} variant={risk.severity === 'high' ? 'destructive' : risk.severity === 'medium' ? 'warning' : 'default'}>
                          <AlertTriangle className="h-4 w-4" />
                          <AlertTitle className="flex items-center gap-2">
                            {risk.risk}
                            {renderSeverityBadge(risk.severity)}
                          </AlertTitle>
                          <AlertDescription>
                            {risk.suggestion}
                          </AlertDescription>
                        </Alert>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-500 italic">
                      {t('documentAnalysis.analysis.noRisksFound')}
                    </p>
                  )}
                </div>
                
                {/* Next Steps */}
                <div>
                  <h3 className="text-lg font-semibold mb-2">
                    {t('documentAnalysis.analysis.nextSteps')}
                  </h3>
                  <ul className="list-decimal pl-5 space-y-1">
                    {analysis.nextSteps.map((step, index) => (
                      <li key={index}>{step}</li>
                    ))}
                  </ul>
                </div>
                
                {/* Relevant Case Law (if available) */}
                {analysis.relevantCaseLaw && analysis.relevantCaseLaw.length > 0 && (
                  <div>
                    <h3 className="text-lg font-semibold mb-2">
                      {t('documentAnalysis.analysis.relevantCaseLaw')}
                    </h3>
                    <ul className="list-disc pl-5 space-y-1">
                      {analysis.relevantCaseLaw.map((caseRef, index) => (
                        <li key={index}>{caseRef}</li>
                      ))}
                    </ul>
                  </div>
                )}
                
                {/* Confidence Score */}
                <div className="mt-4 flex items-center gap-2">
                  <span className="text-sm text-gray-500">
                    {t('documentAnalysis.analysis.confidenceScore')}:
                  </span>
                  <Badge variant={analysis.confidenceScore > 0.7 ? 'outline' : 'secondary'}>
                    {Math.round(analysis.confidenceScore * 100)}%
                  </Badge>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <BarChart className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">
                  {t('documentAnalysis.analysis.noAnalysis')}
                </p>
              </div>
            )}
          </CardContent>
          <CardFooter>
            <Button 
              onClick={handleAnalyzeDocument} 
              disabled={isAnalysisLoading}
              className="ml-auto"
            >
              {isAnalysisLoading && <RefreshCw className="mr-2 h-4 w-4 animate-spin" />}
              {isAnalysisLoading ? t('common.processing') : t('documentAnalysis.analysis.analyze')}
            </Button>
          </CardFooter>
        </Card>
      </TabsContent>
      
      {/* Metadata Tab */}
      <TabsContent value="metadata" className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle>{t('documentAnalysis.metadata.title')}</CardTitle>
            <CardDescription>
              {t('documentAnalysis.metadata.description')}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isMetadataLoading ? (
              <div className="space-y-3">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-4 w-5/6" />
                <Skeleton className="h-4 w-2/3" />
                <Skeleton className="h-4 w-full" />
              </div>
            ) : metadata ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Document Type */}
                <div className="col-span-1 md:col-span-2">
                  <h3 className="text-sm font-medium text-gray-500">
                    {t('documentAnalysis.metadata.documentType')}
                  </h3>
                  <p className="text-lg">{metadata.documentType}</p>
                </div>
                
                {/* Parties */}
                <div className="col-span-1 md:col-span-2">
                  <h3 className="text-sm font-medium text-gray-500">
                    {t('documentAnalysis.metadata.parties')}
                  </h3>
                  <ul className="list-disc pl-5 mt-1">
                    {metadata.parties.map((party, index) => (
                      <li key={index}>{party}</li>
                    ))}
                  </ul>
                </div>
                
                {/* Dates */}
                <div>
                  <h3 className="text-sm font-medium text-gray-500">
                    {t('documentAnalysis.metadata.effectiveDate')}
                  </h3>
                  <p>{metadata.effectiveDate || t('common.notSpecified')}</p>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-gray-500">
                    {t('documentAnalysis.metadata.expirationDate')}
                  </h3>
                  <p>{metadata.expirationDate || t('common.notSpecified')}</p>
                </div>
                
                {/* Legal Information */}
                <div>
                  <h3 className="text-sm font-medium text-gray-500">
                    {t('documentAnalysis.metadata.jurisdiction')}
                  </h3>
                  <p>{metadata.jurisdiction || t('common.notSpecified')}</p>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-gray-500">
                    {t('documentAnalysis.metadata.governingLaw')}
                  </h3>
                  <p>{metadata.governingLaw || t('common.notSpecified')}</p>
                </div>
                
                {/* Key Provisions */}
                <div className="col-span-1 md:col-span-2">
                  <h3 className="text-sm font-medium text-gray-500">
                    {t('documentAnalysis.metadata.keyProvisions')}
                  </h3>
                  {metadata.keyProvisions && metadata.keyProvisions.length > 0 ? (
                    <ul className="list-disc pl-5 mt-1">
                      {metadata.keyProvisions.map((provision, index) => (
                        <li key={index}>{provision}</li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-gray-500 italic mt-1">
                      {t('documentAnalysis.metadata.noProvisions')}
                    </p>
                  )}
                </div>
                
                {/* Other Fields */}
                {Object.entries(metadata).map(([key, value]) => {
                  // Skip fields we've already rendered
                  if ([
                    'documentType', 'parties', 'effectiveDate', 'expirationDate',
                    'jurisdiction', 'governingLaw', 'keyProvisions'
                  ].includes(key)) {
                    return null;
                  }
                  
                  // Skip empty arrays or objects
                  if (
                    (Array.isArray(value) && value.length === 0) ||
                    (typeof value === 'object' && value !== null && Object.keys(value).length === 0)
                  ) {
                    return null;
                  }
                  
                  return (
                    <div key={key} className="col-span-1 md:col-span-2">
                      <h3 className="text-sm font-medium text-gray-500">
                        {key.charAt(0).toUpperCase() + key.slice(1).replace(/([A-Z])/g, ' $1')}
                      </h3>
                      <p>
                        {typeof value === 'string' ? value : 
                         Array.isArray(value) ? value.join(', ') : 
                         JSON.stringify(value)}
                      </p>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8">
                <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">
                  {t('documentAnalysis.metadata.noMetadata')}
                </p>
              </div>
            )}
          </CardContent>
          <CardFooter>
            <Button 
              onClick={handleExtractMetadata} 
              disabled={isMetadataLoading}
              className="ml-auto"
            >
              {isMetadataLoading && <RefreshCw className="mr-2 h-4 w-4 animate-spin" />}
              {isMetadataLoading ? t('common.processing') : t('documentAnalysis.metadata.extract')}
            </Button>
          </CardFooter>
        </Card>
      </TabsContent>
      
      {/* Compare Tab */}
      <TabsContent value="compare" className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle>{t('documentAnalysis.compare.title')}</CardTitle>
            <CardDescription>
              {t('documentAnalysis.compare.description')}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Document selection */}
              <div>
                <h3 className="text-sm font-medium mb-2">
                  {t('documentAnalysis.compare.selectDocument')}
                </h3>
                
                <Select 
                  value={selectedComparisonDocId?.toString() || ''}
                  onValueChange={(value) => setSelectedComparisonDocId(Number(value))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder={t('documentAnalysis.compare.selectPlaceholder')} />
                  </SelectTrigger>
                  <SelectContent>
                    {otherDocuments.map((doc) => (
                      <SelectItem key={doc.id} value={doc.id.toString()}>
                        {doc.title}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              {/* Comparison Results */}
              {isComparisonLoading ? (
                <div className="space-y-4">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-24 w-full" />
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-24 w-full" />
                </div>
              ) : comparisonResult ? (
                <div className="space-y-6">
                  {/* Similarities */}
                  <div>
                    <h3 className="text-lg font-semibold mb-2 flex items-center gap-2">
                      <CheckCircle className="h-5 w-5 text-green-500" />
                      {t('documentAnalysis.compare.similarities')}
                    </h3>
                    <ul className="list-disc pl-5 space-y-1">
                      {comparisonResult.similarities.map((similarity, index) => (
                        <li key={index}>{similarity}</li>
                      ))}
                    </ul>
                  </div>
                  
                  {/* Differences */}
                  <div>
                    <h3 className="text-lg font-semibold mb-2 flex items-center gap-2">
                      <AlertTriangle className="h-5 w-5 text-amber-500" />
                      {t('documentAnalysis.compare.differences')}
                    </h3>
                    <ul className="list-disc pl-5 space-y-1">
                      {comparisonResult.differences.map((difference, index) => (
                        <li key={index}>{difference}</li>
                      ))}
                    </ul>
                  </div>
                  
                  {/* Recommendations */}
                  <div>
                    <h3 className="text-lg font-semibold mb-2">
                      {t('documentAnalysis.compare.recommendations')}
                    </h3>
                    <ul className="list-decimal pl-5 space-y-1">
                      {comparisonResult.recommendations.map((recommendation, index) => (
                        <li key={index}>{recommendation}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <GitCompare className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">
                    {t('documentAnalysis.compare.noComparison')}
                  </p>
                </div>
              )}
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            {comparisonResult && (
              <Button 
                variant="outline"
                onClick={() => {
                  resetComparison();
                  setSelectedComparisonDocId(null);
                }}
              >
                {t('common.reset')}
              </Button>
            )}
            <Button 
              onClick={handleCompareDocuments} 
              disabled={isComparisonLoading || !selectedComparisonDocId}
              className={comparisonResult ? "ml-auto" : ""}
            >
              {isComparisonLoading && <RefreshCw className="mr-2 h-4 w-4 animate-spin" />}
              {isComparisonLoading ? t('common.processing') : t('documentAnalysis.compare.compare')}
            </Button>
          </CardFooter>
        </Card>
      </TabsContent>
    </Tabs>
  );
};