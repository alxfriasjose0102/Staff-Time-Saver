import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { CheckCircle, Copy, ChevronDown, ChevronUp, Info, RefreshCcw, FileText } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { Tooltip } from '@/components/ui/tooltip';

interface DocumentAnalysisResult {
  summary: string;
  keyPoints: string[];
  legalRisks: {
    risk: string;
    severity: 'low' | 'medium' | 'high';
    suggestion: string;
  }[];
  nextSteps: string[];
  relevantCaseLaw?: string[];
  confidenceScore: number;
}

interface DocumentMetadata {
  documentType: string;
  parties: string[];
  effectiveDate?: string;
  expirationDate?: string;
  jurisdiction?: string;
  governingLaw?: string;
  keyProvisions: string[];
  [key: string]: any;
}

interface Document {
  id: number;
  title: string;
  content?: string;
  fileName?: string;
  fileUrl?: string;
  status?: string;
}

interface DocumentAnalysisProps {
  document: Document;
  onAnalysisComplete?: (result: DocumentAnalysisResult, metadata: DocumentMetadata) => void;
}

import { analyzeDocument as openAIAnalyzeDocument } from '@/lib/openai';

// Use the OpenAI integration to analyze the document
const analyzeDocument = async (content: string): Promise<{
  result: DocumentAnalysisResult;
  metadata: DocumentMetadata;
}> => {
  try {
    // Make the API call to OpenAI
    return await openAIAnalyzeDocument(content);
  } catch (error) {
    console.error("Error in document analysis:", error);
    
    // Fallback mechanism if API call fails
    // In a production environment, we should handle this more gracefully
    // and provide appropriate error messaging to the user
    throw error;
  }
};

export const DocumentAnalysis: React.FC<DocumentAnalysisProps> = ({ 
  document,
  onAnalysisComplete
}) => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [documentText, setDocumentText] = useState(document.content || '');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<DocumentAnalysisResult | null>(null);
  const [metadata, setMetadata] = useState<DocumentMetadata | null>(null);
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    keyPoints: true,
    legalRisks: true,
    nextSteps: true,
    relevantCaseLaw: true
  });

  const toggleSection = (section: string) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      toast({
        title: t('common.copied'),
        description: t('common.copiedToClipboard'),
      });
    });
  };

  const handleAnalyze = async () => {
    if (!documentText.trim()) {
      toast({
        title: t('documents.analysisError'),
        description: t('documents.emptyDocument'),
        variant: 'destructive',
      });
      return;
    }

    setIsAnalyzing(true);

    try {
      const { result, metadata } = await analyzeDocument(documentText);
      setAnalysisResult(result);
      setMetadata(metadata);
      
      // Automatically switch to results tab
      setActiveAnalysisTab("results");
      
      if (onAnalysisComplete) {
        onAnalysisComplete(result, metadata);
      }

      toast({
        title: t('documents.analysisComplete'),
        description: t('documents.analysisSuccess'),
      });
    } catch (error) {
      console.error('Analysis error:', error);
      toast({
        title: t('documents.analysisError'),
        description: error instanceof Error ? error.message : t('documents.unknownError'),
        variant: 'destructive',
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getSeverityColor = (severity: 'low' | 'medium' | 'high') => {
    switch (severity) {
      case 'low':
        return 'bg-yellow-50 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300';
      case 'medium':
        return 'bg-orange-50 text-orange-800 dark:bg-orange-900/20 dark:text-orange-300';
      case 'high':
        return 'bg-red-50 text-red-800 dark:bg-red-900/20 dark:text-red-300';
      default:
        return '';
    }
  };

  const getConfidenceColor = (score: number) => {
    if (score >= 0.8) return 'text-green-600 dark:text-green-400';
    if (score >= 0.6) return 'text-yellow-600 dark:text-yellow-400';
    return 'text-red-600 dark:text-red-400';
  };

  const [activeAnalysisTab, setActiveAnalysisTab] = useState("input");

  return (
    <div className="space-y-6">
      <Tabs 
        value={activeAnalysisTab} 
        onValueChange={setActiveAnalysisTab} 
        defaultValue="input" 
        className="w-full"
      >
        <TabsList>
          <TabsTrigger value="input" onClick={() => setActiveAnalysisTab("input")}>
            {t('documents.documentInput')}
          </TabsTrigger>
          {analysisResult && (
            <TabsTrigger value="results" onClick={() => setActiveAnalysisTab("results")}>
              {t('documents.analysisResults')}
            </TabsTrigger>
          )}
        </TabsList>
        
        <TabsContent value="input" className="space-y-4">
          <div className="space-y-2">
            <h3 className="text-lg font-medium">{document.title || t('documents.untitledDocument')}</h3>
            <p className="text-sm text-gray-500 dark:text-gray-400">{t('documents.pasteContent')}</p>
          </div>
          
          <Textarea
            value={documentText}
            onChange={(e) => setDocumentText(e.target.value)}
            placeholder={t('documents.documentPlaceholder')}
            className="min-h-[400px] font-mono text-sm"
          />
          
          <div className="flex justify-end">
            <Button 
              onClick={handleAnalyze} 
              disabled={isAnalyzing || !documentText.trim()}
              className="relative"
            >
              {isAnalyzing ? (
                <>
                  <span className="mr-2 inline-block animate-spin">
                    <RefreshCcw className="h-4 w-4" />
                  </span>
                  {t('documents.analyzing')}
                </>
              ) : (
                <>
                  <FileText className="mr-2 h-4 w-4" />
                  {t('documents.analyzeButton')}
                </>
              )}
            </Button>
          </div>
        </TabsContent>
        
        {analysisResult && (
          <TabsContent value="results" className="space-y-6">
            <Alert className="bg-blue-50 dark:bg-blue-900/10 border-blue-200 dark:border-blue-800">
              <Info className="h-4 w-4" />
              <AlertTitle>{t('documents.confidenceScore')}</AlertTitle>
              <AlertDescription className="flex items-center">
                <span className={`text-lg font-semibold ${getConfidenceColor(analysisResult.confidenceScore)}`}>
                  {Math.round(analysisResult.confidenceScore * 100)}%
                </span>
                <Tooltip content={
                  <span className="max-w-xs">
                    The confidence score represents the AI's assessment of its analysis accuracy.
                    Higher scores indicate greater confidence in the results.
                  </span>
                }>
                  <Info className="h-4 w-4 ml-2 text-gray-400 cursor-help" />
                </Tooltip>
              </AlertDescription>
            </Alert>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Left column - Analysis */}
              <div className="space-y-6">
                <Card>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between">
                      <CardTitle>{t('documents.summary')}</CardTitle>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-8 w-8 p-0" 
                        onClick={() => copyToClipboard(analysisResult.summary)}
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-700 dark:text-gray-300">
                      {analysisResult.summary}
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-center">
                      <CardTitle>{t('documents.keyPoints')}</CardTitle>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 w-8 p-0 ml-2"
                        onClick={() => toggleSection('keyPoints')}
                      >
                        {expandedSections.keyPoints ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </Button>
                    </div>
                  </CardHeader>
                  {expandedSections.keyPoints && (
                    <CardContent>
                      <ul className="list-disc pl-5 space-y-1 text-sm text-gray-700 dark:text-gray-300">
                        {analysisResult.keyPoints.map((point, i) => (
                          <li key={i}>{point}</li>
                        ))}
                      </ul>
                    </CardContent>
                  )}
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-center">
                      <CardTitle>{t('documents.legalRisks')}</CardTitle>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 w-8 p-0 ml-2"
                        onClick={() => toggleSection('legalRisks')}
                      >
                        {expandedSections.legalRisks ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </Button>
                    </div>
                  </CardHeader>
                  {expandedSections.legalRisks && (
                    <CardContent>
                      <div className="space-y-4">
                        {analysisResult.legalRisks.map((risk, i) => (
                          <div key={i} className="border rounded-md p-3">
                            <div className="flex items-center justify-between">
                              <h4 className="font-medium text-gray-900 dark:text-gray-100">{risk.risk}</h4>
                              <span 
                                className={`px-2 py-0.5 rounded-full text-xs uppercase font-medium ${getSeverityColor(risk.severity)}`}
                              >
                                {risk.severity}
                              </span>
                            </div>
                            <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">{risk.suggestion}</p>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  )}
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-center">
                      <CardTitle>{t('documents.nextSteps')}</CardTitle>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 w-8 p-0 ml-2"
                        onClick={() => toggleSection('nextSteps')}
                      >
                        {expandedSections.nextSteps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </Button>
                    </div>
                  </CardHeader>
                  {expandedSections.nextSteps && (
                    <CardContent>
                      <ul className="space-y-2 text-sm text-gray-700 dark:text-gray-300">
                        {analysisResult.nextSteps.map((step, i) => (
                          <li key={i} className="flex items-start">
                            <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                            <span>{step}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  )}
                </Card>

                {analysisResult.relevantCaseLaw && analysisResult.relevantCaseLaw.length > 0 && (
                  <Card>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-center">
                        <CardTitle>{t('documents.relevantCaseLaw')}</CardTitle>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 w-8 p-0 ml-2"
                          onClick={() => toggleSection('relevantCaseLaw')}
                        >
                          {expandedSections.relevantCaseLaw ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                        </Button>
                      </div>
                    </CardHeader>
                    {expandedSections.relevantCaseLaw && (
                      <CardContent>
                        <ul className="list-disc pl-5 space-y-1 text-sm text-gray-700 dark:text-gray-300">
                          {analysisResult.relevantCaseLaw.map((caseRef, i) => (
                            <li key={i}>{caseRef}</li>
                          ))}
                        </ul>
                      </CardContent>
                    )}
                  </Card>
                )}
              </div>

              {/* Right column - Metadata */}
              <div className="space-y-6">
                {metadata && (
                  <Card>
                    <CardHeader>
                      <CardTitle>{t('documents.metadata')}</CardTitle>
                      <CardDescription>
                        {t('documents.documentType')}: {metadata.documentType}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">
                          {t('documents.parties')}
                        </h4>
                        <ul className="list-disc pl-5 space-y-1 text-sm">
                          {metadata.parties.map((party, i) => (
                            <li key={i}>{party}</li>
                          ))}
                        </ul>
                      </div>

                      {metadata.effectiveDate && (
                        <div>
                          <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">
                            {t('documents.effectiveDate')}
                          </h4>
                          <p className="text-sm">{metadata.effectiveDate}</p>
                        </div>
                      )}

                      {metadata.expirationDate && (
                        <div>
                          <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">
                            {t('documents.expirationDate')}
                          </h4>
                          <p className="text-sm">{metadata.expirationDate}</p>
                        </div>
                      )}

                      {metadata.jurisdiction && (
                        <div>
                          <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">
                            {t('documents.jurisdiction')}
                          </h4>
                          <p className="text-sm">{metadata.jurisdiction}</p>
                        </div>
                      )}

                      {metadata.governingLaw && (
                        <div>
                          <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">
                            {t('documents.governingLaw')}
                          </h4>
                          <p className="text-sm">{metadata.governingLaw}</p>
                        </div>
                      )}

                      {metadata.keyProvisions && metadata.keyProvisions.length > 0 && (
                        <div>
                          <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">
                            {t('documents.keyProvisions')}
                          </h4>
                          <ul className="list-disc pl-5 space-y-1 text-sm">
                            {metadata.keyProvisions.map((provision, i) => (
                              <li key={i}>{provision}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
};