import { useEffect } from 'react';
import { useAuth } from '../hooks/use-auth';
import { supabase } from '../lib/supabaseClient';

/**
 * SessionCheck - Silent component that checks for existing session
 * and refreshes auth state. Should be included at the root level.
 */
const SessionCheck: React.FC = () => {
  const { refreshAuth } = useAuth();

  useEffect(() => {
    const checkSession = async () => {
      try {
        // Get current session from Supabase
        const { data } = await supabase.auth.getSession();
        const session = data.session;
        
        if (session) {
          // If we have a session, refresh the auth state to
          // ensure user data is up to date
          await refreshAuth();
          console.log('Session check complete, user is authenticated');
        } else {
          console.log('Session check complete, no active session found');
        }
      } catch (error) {
        console.error('Error checking session:', error);
      }
    };

    checkSession();
  }, [refreshAuth]);

  // This component doesn't render anything
  return null;
};

export default SessionCheck;