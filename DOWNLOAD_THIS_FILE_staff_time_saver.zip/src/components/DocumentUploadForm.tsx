import React, { useState, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { z } from 'zod';
import { Loader2, Upload, X, Check, FileText, File } from 'lucide-react';
import { Button } from './ui/button';
import { useToast } from '../hooks/use-toast';
import { documentStatusEnum } from '../shared/schema';

// Document upload form validation schema
const documentSchema = z.object({
  title: z.string().min(1, 'Document title is required'),
  clientId: z.number({
    required_error: 'Client is required',
    invalid_type_error: 'Client is required'
  }),
  matterId: z.number().optional(),
  status: z.enum(documentStatusEnum.enumValues, {
    required_error: 'Status is required'
  }),
  needsSignature: z.boolean().default(false),
});

type DocumentFormData = z.infer<typeof documentSchema> & {
  file?: File;
};

interface Client {
  id: number;
  firstName: string;
  lastName: string;
}

interface Matter {
  id: number;
  title: string;
  clientId: number;
}

interface DocumentUploadFormProps {
  onCancel: () => void;
  onSuccess: () => void;
}

export const DocumentUploadForm: React.FC<DocumentUploadFormProps> = ({ onCancel, onSuccess }) => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Form state
  const [formData, setFormData] = useState<DocumentFormData>({
    title: '',
    clientId: 0,
    matterId: undefined,
    status: 'Draft',
    needsSignature: false,
  });
  
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  // Fetch clients for dropdown
  const { data: clients, isLoading: isLoadingClients } = useQuery<Client[]>({
    queryKey: ['/api/clients'],
    queryFn: async () => {
      const response = await fetch('/api/clients', {
        credentials: 'include',
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch clients');
      }
      
      return response.json();
    },
  });
  
  // Fetch matters for the selected client
  const { data: matters, isLoading: isLoadingMatters } = useQuery<Matter[]>({
    queryKey: ['/api/matters', { clientId: formData.clientId }],
    queryFn: async () => {
      if (!formData.clientId) return [];
      
      const response = await fetch(`/api/matters?clientId=${formData.clientId}`, {
        credentials: 'include',
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch matters');
      }
      
      return response.json();
    },
    enabled: !!formData.clientId,
  });
  
  // Mutation for uploading a document
  const uploadDocumentMutation = useMutation({
    mutationFn: async (documentData: FormData) => {
      const response = await fetch('/api/documents', {
        method: 'POST',
        body: documentData,
        credentials: 'include',
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to upload document');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/documents'] });
      
      toast({
        title: 'Success',
        description: 'Document has been successfully uploaded',
        variant: 'success',
      });
      
      onSuccess();
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    }
  });
  
  // Handle input changes
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    let parsedValue: string | number | boolean = value;
    
    if (type === 'checkbox') {
      parsedValue = (e.target as HTMLInputElement).checked;
    } else if (name === 'clientId' || name === 'matterId') {
      parsedValue = value ? parseInt(value) : (name === 'matterId' ? undefined : 0);
      
      // Reset matter if client changes
      if (name === 'clientId') {
        setFormData(prev => ({ ...prev, matterId: undefined }));
      }
    }
    
    setFormData(prev => ({ ...prev, [name]: parsedValue }));
    
    // Clear error when field is edited
    if (errors[name]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };
  
  // Handle file selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadedFile(file);
      // Try to set title from filename if it's not already set
      if (!formData.title) {
        const nameWithoutExtension = file.name.replace(/\.[^/.]+$/, '');
        setFormData(prev => ({ ...prev, title: nameWithoutExtension }));
      }
      
      // Clear file error if it exists
      if (errors.file) {
        setErrors(prev => {
          const newErrors = { ...prev };
          delete newErrors.file;
          return newErrors;
        });
      }
    }
  };
  
  // Handle file drop
  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    
    const file = e.dataTransfer.files?.[0];
    if (file) {
      setUploadedFile(file);
      // Try to set title from filename if it's not already set
      if (!formData.title) {
        const nameWithoutExtension = file.name.replace(/\.[^/.]+$/, '');
        setFormData(prev => ({ ...prev, title: nameWithoutExtension }));
      }
      
      // Clear file error if it exists
      if (errors.file) {
        setErrors(prev => {
          const newErrors = { ...prev };
          delete newErrors.file;
          return newErrors;
        });
      }
    }
  };
  
  // Handle drag events
  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };
  
  const handleDragLeave = () => {
    setIsDragging(false);
  };
  
  // Remove uploaded file
  const handleRemoveFile = () => {
    setUploadedFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };
  
  // Validate form
  const validateForm = () => {
    try {
      documentSchema.parse(formData);
      
      // Additional validation for file
      if (!uploadedFile) {
        setErrors(prev => ({ ...prev, file: 'Document file is required' }));
        return false;
      }
      
      setErrors({});
      return true;
    } catch (error) {
      if (error instanceof z.ZodError) {
        const newErrors: Record<string, string> = {};
        error.errors.forEach(err => {
          const path = err.path.join('.');
          newErrors[path] = err.message;
        });
        setErrors(newErrors);
      }
      return false;
    }
  };
  
  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      const formDataToSend = new FormData();
      
      // Append document metadata
      Object.entries(formData).forEach(([key, value]) => {
        if (value !== undefined && key !== 'file') {
          formDataToSend.append(key, value.toString());
        }
      });
      
      // Append file
      if (uploadedFile) {
        formDataToSend.append('file', uploadedFile);
      }
      
      uploadDocumentMutation.mutate(formDataToSend);
    }
  };
  
  // Format file size
  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return bytes + ' bytes';
    else if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
    else return (bytes / 1048576).toFixed(1) + ' MB';
  };
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
      <h2 className="text-2xl font-bold mb-6">{t('documents.uploadDocumentTitle')}</h2>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Document Info */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              {t('documents.documentTitle')} *
            </label>
            <input
              type="text"
              name="title"
              value={formData.title}
              onChange={handleChange}
              className={`w-full rounded-md border ${errors.title ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'} px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700`}
            />
            {errors.title && <p className="mt-1 text-sm text-red-500">{errors.title}</p>}
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              {t('documents.status')} *
            </label>
            <select
              name="status"
              value={formData.status}
              onChange={handleChange}
              className={`w-full rounded-md border ${errors.status ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'} px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700`}
            >
              {Object.values(documentStatusEnum.enumValues).map(status => (
                <option key={status} value={status}>
                  {t(`documents.status.${status.toLowerCase()}`)}
                </option>
              ))}
            </select>
            {errors.status && <p className="mt-1 text-sm text-red-500">{errors.status}</p>}
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              {t('documents.client')} *
            </label>
            <select
              name="clientId"
              value={formData.clientId || ''}
              onChange={handleChange}
              className={`w-full rounded-md border ${errors.clientId ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'} px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700`}
            >
              <option value="">{t('documents.selectClient')}</option>
              {isLoadingClients ? (
                <option disabled>{t('common.loading')}</option>
              ) : (
                clients?.map(client => (
                  <option key={client.id} value={client.id}>
                    {client.firstName} {client.lastName}
                  </option>
                ))
              )}
            </select>
            {errors.clientId && <p className="mt-1 text-sm text-red-500">{errors.clientId}</p>}
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              {t('documents.matter')}
            </label>
            <select
              name="matterId"
              value={formData.matterId || ''}
              onChange={handleChange}
              disabled={!formData.clientId || isLoadingMatters}
              className={`w-full rounded-md border ${errors.matterId ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'} px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 ${(!formData.clientId || isLoadingMatters) ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              <option value="">{t('documents.selectMatter')}</option>
              {isLoadingMatters ? (
                <option disabled>{t('common.loading')}</option>
              ) : (
                matters?.map(matter => (
                  <option key={matter.id} value={matter.id}>
                    {matter.title}
                  </option>
                ))
              )}
            </select>
            {errors.matterId && <p className="mt-1 text-sm text-red-500">{errors.matterId}</p>}
          </div>
        </div>
        
        {/* Signature checkbox */}
        <div className="flex items-center">
          <input
            type="checkbox"
            id="needsSignature"
            name="needsSignature"
            checked={formData.needsSignature}
            onChange={handleChange}
            className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
          />
          <label htmlFor="needsSignature" className="ml-2 block text-sm text-gray-700 dark:text-gray-300">
            {t('documents.needsSignature')}
          </label>
        </div>
        
        {/* File upload area */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            {t('documents.documentFile')} *
          </label>
          
          {uploadedFile ? (
            <div className="flex items-center justify-between p-4 border border-gray-300 dark:border-gray-600 rounded-md bg-gray-50 dark:bg-gray-700">
              <div className="flex items-center">
                <FileText className="h-8 w-8 text-blue-500 mr-3" />
                <div>
                  <p className="text-sm font-medium text-gray-700 dark:text-gray-300">{uploadedFile.name}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">{formatFileSize(uploadedFile.size)}</p>
                </div>
              </div>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={handleRemoveFile}
                className="text-gray-500 hover:text-red-500"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          ) : (
            <div
              className={`border-2 border-dashed rounded-md p-6 flex flex-col items-center justify-center space-y-2 cursor-pointer ${
                isDragging
                  ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                  : 'border-gray-300 dark:border-gray-600'
              } ${errors.file ? 'border-red-500' : ''}`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
            >
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                className="hidden"
                accept=".pdf,.doc,.docx,.txt,.jpg,.jpeg,.png"
              />
              <Upload className="h-10 w-10 text-gray-400" />
              <div className="text-center">
                <p className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  {t('documents.dragDropFiles')}
                </p>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                  {t('documents.supportedFileTypes')}
                </p>
              </div>
            </div>
          )}
          
          {errors.file && <p className="mt-1 text-sm text-red-500">{errors.file}</p>}
        </div>
        
        {/* Submit buttons */}
        <div className="flex justify-end space-x-3">
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
          >
            {t('common.cancel')}
          </Button>
          
          <Button
            type="submit"
            className="bg-blue-600 hover:bg-blue-700 text-white font-semibold"
            disabled={uploadDocumentMutation.isPending}
          >
            {uploadDocumentMutation.isPending ? (
              <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> {t('common.processing')}</>
            ) : (
              <><Check className="mr-2 h-4 w-4" /> {t('documents.upload')}</>
            )}
          </Button>
        </div>
      </form>
    </div>
  );
};