import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { 
  Loader2, 
  FileText, 
  Download, 
  Edit, 
  Trash2, 
  ArrowLeft, 
  Clock, 
  User, 
  Briefcase,
  File,
  Pen,
  CheckSquare,
  RefreshCw,
  Cpu
} from 'lucide-react';
import { Button } from './ui/button';
import { formatDate } from '../lib/utils';
import { useToast } from '../hooks/use-toast';
import { documentStatusEnum } from '../shared/schema';
import { DocumentAnalysis } from './DocumentAnalysis';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';

interface Document {
  id: number;
  title: string;
  fileName?: string;
  fileUrl?: string;
  fileType?: string;
  fileSize?: number;
  status: string;
  needsSignature: boolean;
  createdAt: string;
  updatedAt: string;
  client: {
    id: number;
    firstName: string;
    lastName: string;
    email: string;
  };
  matter?: {
    id: number;
    title: string;
    type: string;
  };
  createdBy: {
    id: number;
    firstName: string;
    lastName: string;
  };
}

interface DocumentDetailProps {
  documentId: number;
  onBack: () => void;
  onEdit: (id: number) => void;
  onRequestSignature?: (id: number) => void;
}

export const DocumentDetail: React.FC<DocumentDetailProps> = ({ 
  documentId, 
  onBack, 
  onEdit,
  onRequestSignature
}) => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedStatus, setSelectedStatus] = useState<string | null>(null);
  
  // Fetch document details
  const { data: document, isLoading, error } = useQuery<Document>({
    queryKey: ['/api/documents', documentId],
    queryFn: async () => {
      const response = await fetch(`/api/documents/${documentId}`, {
        credentials: 'include',
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch document details');
      }
      
      return response.json();
    },
  });
  
  // Status update mutation
  const updateStatusMutation = useMutation({
    mutationFn: async (status: string) => {
      const response = await fetch(`/api/documents/${documentId}/status`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status }),
        credentials: 'include',
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to update document status');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/documents', documentId] });
      queryClient.invalidateQueries({ queryKey: ['/api/documents'] });
      toast({
        title: 'Success',
        description: 'Document status has been updated',
        variant: 'success',
      });
      setSelectedStatus(null);
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    }
  });
  
  // Delete document mutation
  const deleteDocumentMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch(`/api/documents/${documentId}`, {
        method: 'DELETE',
        credentials: 'include',
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to delete document');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/documents'] });
      toast({
        title: 'Success',
        description: 'Document has been successfully deleted',
        variant: 'success',
      });
      onBack();
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    }
  });
  
  // Handle status change
  const handleStatusChange = (status: string) => {
    if (status !== document?.status) {
      updateStatusMutation.mutate(status);
    }
  };
  
  // Handle delete confirmation
  const handleDelete = () => {
    if (window.confirm(t('documents.deleteConfirmation'))) {
      deleteDocumentMutation.mutate();
    }
  };
  
  // Format file size
  const formatFileSize = (bytes?: number): string => {
    if (!bytes) return '';
    if (bytes < 1024) return bytes + ' bytes';
    else if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
    else return (bytes / 1048576).toFixed(1) + ' MB';
  };
  
  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
      </div>
    );
  }
  
  if (error || !document) {
    return (
      <div className="flex h-64 flex-col items-center justify-center text-center">
        <p className="text-lg font-medium text-red-500 mb-4">
          {t('documents.errorLoadingDetail')}
        </p>
        <p className="text-gray-500 dark:text-gray-400 mb-6">
          {(error as Error)?.message || t('documents.documentNotFound')}
        </p>
        <Button onClick={onBack} variant="outline">
          <ArrowLeft className="h-4 w-4 mr-2" />
          {t('common.back')}
        </Button>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      {/* Header with actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center">
          <Button variant="ghost" onClick={onBack} className="mr-2 p-2">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-2xl font-bold">{document.title}</h1>
        </div>
        
        <div className="flex space-x-2">
          <div className="dropdown dropdown-end relative">
            <Button className={`${
              selectedStatus ? 'bg-blue-600 text-white' : 'border-gray-300 bg-white text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700'
            }`}>
              <RefreshCw className="h-4 w-4 mr-2" />
              {t('documents.changeStatus')}
            </Button>
            <div className="dropdown-content bg-white dark:bg-gray-800 shadow-xl rounded-md p-2 w-40 mt-1 absolute right-0 z-10">
              <div className="flex flex-col space-y-1">
                {Object.values(documentStatusEnum.enumValues).map(status => (
                  <button 
                    key={status}
                    className={`text-left px-3 py-1 text-sm rounded ${
                      document.status === status 
                        ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300' 
                        : 'hover:bg-gray-100 dark:hover:bg-gray-700'
                    }`}
                    onClick={() => handleStatusChange(status)}
                    disabled={updateStatusMutation.isPending}
                  >
                    {t(`documents.status.${status.toLowerCase()}`)}
                  </button>
                ))}
              </div>
            </div>
          </div>
          
          {document.fileUrl && (
            <Button variant="outline">
              <Download className="h-4 w-4 mr-2" />
              {t('documents.download')}
            </Button>
          )}
          
          {document.needsSignature && document.status === 'Pending Signature' && onRequestSignature && (
            <Button className="bg-green-600 hover:bg-green-700 text-white" onClick={() => onRequestSignature(document.id)}>
              <Pen className="h-4 w-4 mr-2" />
              {t('documents.requestSignature')}
            </Button>
          )}
          
          <Button variant="outline" onClick={() => onEdit(document.id)}>
            <Edit className="h-4 w-4 mr-2" />
            {t('common.edit')}
          </Button>
          
          <Button variant="outline" className="text-red-600 border-red-600 hover:bg-red-50 dark:hover:bg-red-900" onClick={handleDelete}>
            <Trash2 className="h-4 w-4 mr-2" />
            {t('common.delete')}
          </Button>
        </div>
      </div>
      
      {/* Document status */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium mr-3
              ${document.status === 'Draft' ? 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300' : ''}
              ${document.status === 'Pending Review' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300' : ''}
              ${document.status === 'Pending Signature' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300' : ''}
              ${document.status === 'Signed' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300' : ''}
              ${document.status === 'Final' ? 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300' : ''}
              ${document.status === 'Archived' ? 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300' : ''}
            `}>
              {t(`documents.status.${document.status.toLowerCase()}`)}
            </span>
            
            {document.needsSignature && (
              <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-50 text-blue-700 dark:bg-blue-900 dark:text-blue-300">
                <Pen className="h-3 w-3 mr-1" />
                {t('documents.requiresSignature')}
              </span>
            )}
          </div>
          
          <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
            <Clock className="h-4 w-4 mr-1" />
            {t('documents.updated')}: {formatDate(new Date(document.updatedAt))}
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main document information */}
        <div className="lg:col-span-2 space-y-6">
          {/* Document preview placeholder */}
          {document.fileUrl ? (
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow overflow-hidden">
              <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
                <h2 className="text-lg font-semibold">{t('documents.preview')}</h2>
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  {t('documents.download')}
                </Button>
              </div>
              <div className="h-96 bg-gray-100 dark:bg-gray-700 p-4 flex items-center justify-center">
                {document.fileType?.includes('image') ? (
                  <img 
                    src={document.fileUrl} 
                    alt={document.title} 
                    className="max-h-full object-contain" 
                  />
                ) : (
                  <div className="text-center p-8">
                    <FileText className="h-16 w-16 text-gray-400 dark:text-gray-500 mx-auto mb-4" />
                    <p className="text-gray-500 dark:text-gray-400">{t('documents.previewNotAvailable')}</p>
                    <Button variant="outline" size="sm" className="mt-4">
                      <Download className="h-4 w-4 mr-2" />
                      {t('documents.downloadToView')}
                    </Button>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6 flex flex-col items-center justify-center h-64">
              <FileText className="h-16 w-16 text-gray-300 dark:text-gray-600 mb-4" />
              <p className="text-gray-500 dark:text-gray-400 text-center">
                {t('documents.noFileUploaded')}
              </p>
              <Button variant="outline" size="sm" onClick={() => onEdit(document.id)} className="mt-4">
                <Edit className="h-4 w-4 mr-2" />
                {t('documents.uploadFile')}
              </Button>
            </div>
          )}
          
          {/* Document activity log placeholder */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
            <h2 className="text-lg font-semibold mb-4">{t('documents.activityLog')}</h2>
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <div className="h-8 w-8 rounded-full bg-blue-500 flex items-center justify-center">
                    <FileText className="h-4 w-4 text-white" />
                  </div>
                </div>
                <div className="ml-3">
                  <p className="text-sm">
                    <span className="font-medium text-gray-900 dark:text-white">
                      {document.createdBy.firstName} {document.createdBy.lastName}
                    </span>
                    {' '}{t('documents.created')}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {formatDate(new Date(document.createdAt))}
                  </p>
                </div>
              </div>
              
              {document.updatedAt !== document.createdAt && (
                <div className="flex items-start">
                  <div className="flex-shrink-0">
                    <div className="h-8 w-8 rounded-full bg-green-500 flex items-center justify-center">
                      <Edit className="h-4 w-4 text-white" />
                    </div>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm">
                      <span className="font-medium text-gray-900 dark:text-white">
                        {document.createdBy.firstName} {document.createdBy.lastName}
                      </span>
                      {' '}{t('documents.updated')}
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {formatDate(new Date(document.updatedAt))}
                    </p>
                  </div>
                </div>
              )}
              
              {document.status === 'Signed' && (
                <div className="flex items-start">
                  <div className="flex-shrink-0">
                    <div className="h-8 w-8 rounded-full bg-green-500 flex items-center justify-center">
                      <CheckSquare className="h-4 w-4 text-white" />
                    </div>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm">
                      <span className="font-medium text-gray-900 dark:text-white">
                        {document.client.firstName} {document.client.lastName}
                      </span>
                      {' '}{t('documents.signed')}
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {formatDate(new Date(document.updatedAt))}
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
        
        {/* Document metadata sidebar */}
        <div className="space-y-6">
          {/* File information */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
            <h2 className="text-lg font-semibold mb-4">{t('documents.fileInfo')}</h2>
            
            {document.fileName ? (
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="flex-shrink-0 h-10 w-10 bg-gray-100 dark:bg-gray-700 rounded-md flex items-center justify-center">
                    <File className="h-5 w-5 text-gray-500 dark:text-gray-400" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white">{document.fileName}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {document.fileType} {document.fileSize ? `• ${formatFileSize(document.fileSize)}` : ''}
                    </p>
                  </div>
                </div>
                
                <div className="text-sm">
                  <div className="flex justify-between py-2 border-b border-gray-200 dark:border-gray-700">
                    <span className="text-gray-500 dark:text-gray-400">{t('documents.uploaded')}</span>
                    <span className="font-medium">{formatDate(new Date(document.createdAt))}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-gray-200 dark:border-gray-700">
                    <span className="text-gray-500 dark:text-gray-400">{t('documents.lastModified')}</span>
                    <span className="font-medium">{formatDate(new Date(document.updatedAt))}</span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-4">
                <p className="text-gray-500 dark:text-gray-400 text-sm">
                  {t('documents.noFileUploaded')}
                </p>
              </div>
            )}
          </div>
          
          {/* Related information */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
            <h2 className="text-lg font-semibold mb-4">{t('documents.relatedInfo')}</h2>
            
            <div className="space-y-4">
              {/* Client information */}
              <div className="flex gap-3">
                <User className="h-5 w-5 text-gray-400 mt-0.5" />
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{t('documents.client')}</p>
                  <p className="font-medium">
                    {document.client.firstName} {document.client.lastName}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {document.client.email}
                  </p>
                </div>
              </div>
              
              {/* Matter information */}
              {document.matter && (
                <div className="flex gap-3">
                  <Briefcase className="h-5 w-5 text-gray-400 mt-0.5" />
                  <div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{t('documents.matter')}</p>
                    <p className="font-medium">{document.matter.title}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {document.matter.type}
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* AI Analysis Section */}
        <div className="mt-8">
          <Tabs defaultValue="document" className="w-full">
            <TabsList className="grid grid-cols-2">
              <TabsTrigger value="document">
                <FileText className="h-4 w-4 mr-2" />
                {t('documents.documentInfo')}
              </TabsTrigger>
              <TabsTrigger value="analysis">
                <Cpu className="h-4 w-4 mr-2" />
                {t('documentAnalysis.title')}
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="document">
              {/* Document Info Content (Current Implementation) */}
              {/* This tab shows the current document details */}
            </TabsContent>
            
            <TabsContent value="analysis" className="space-y-4">
              {/* Document Analysis Content */}
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
                <DocumentAnalysis 
                  document={document} 
                  otherDocuments={[]} // We'd need to fetch other documents from the same client/matter
                />
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};