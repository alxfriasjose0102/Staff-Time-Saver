import React, { useRef, useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Trash2, Download, Check } from 'lucide-react';
import { Button } from './ui/button';

interface Point {
  x: number;
  y: number;
}

interface SignaturePadProps {
  onChange?: (dataUrl: string | null) => void;
  initialSignature?: string;
  width?: number;
  height?: number;
  disabled?: boolean;
}

export const SignaturePad: React.FC<SignaturePadProps> = ({
  onChange,
  initialSignature,
  width = 400,
  height = 200,
  disabled = false,
}) => {
  const { t } = useTranslation();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [hasSignature, setHasSignature] = useState(false);
  const [lastPoint, setLastPoint] = useState<Point | null>(null);

  // Initialize canvas when component mounts
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const context = canvas.getContext('2d');
    if (!context) return;

    // Set canvas dimensions with higher resolution for better quality
    canvas.width = width * 2;
    canvas.height = height * 2;
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;
    context.scale(2, 2);

    // Set up canvas for drawing
    context.lineWidth = 2;
    context.lineCap = 'round';
    context.lineJoin = 'round';
    context.strokeStyle = '#000000';

    // Clear canvas
    context.fillStyle = '#ffffff';
    context.fillRect(0, 0, width, height);

    // Load initial signature if provided
    if (initialSignature) {
      const img = new Image();
      img.onload = () => {
        context.drawImage(img, 0, 0, width, height);
        setHasSignature(true);
      };
      img.src = initialSignature;
    }
  }, [initialSignature, width, height]);

  // Get coordinates relative to canvas
  const getCoordinates = (event: MouseEvent | TouchEvent): Point | null => {
    const canvas = canvasRef.current;
    if (!canvas) return null;

    const rect = canvas.getBoundingClientRect();

    let clientX, clientY;
    if ('touches' in event) {
      // Touch event
      if (event.touches.length < 1) return null;
      clientX = event.touches[0].clientX;
      clientY = event.touches[0].clientY;
    } else {
      // Mouse event
      clientX = event.clientX;
      clientY = event.clientY;
    }

    return {
      x: clientX - rect.left,
      y: clientY - rect.top,
    };
  };

  // Start drawing
  const handleStart = (event: React.MouseEvent | React.TouchEvent) => {
    if (disabled) return;

    event.preventDefault();
    
    const coordinates = getCoordinates(event.nativeEvent);
    if (!coordinates) return;

    setIsDrawing(true);
    setLastPoint(coordinates);
    setHasSignature(true);
  };

  // Continue drawing
  const handleMove = (event: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing || disabled) return;

    event.preventDefault();
    
    const coordinates = getCoordinates(event.nativeEvent);
    if (!coordinates || !lastPoint) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const context = canvas.getContext('2d');
    if (!context) return;

    context.beginPath();
    context.moveTo(lastPoint.x, lastPoint.y);
    context.lineTo(coordinates.x, coordinates.y);
    context.stroke();

    setLastPoint(coordinates);
  };

  // Stop drawing
  const handleEnd = (event: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing || disabled) return;

    event.preventDefault();
    
    setIsDrawing(false);
    updateSignatureData();
  };

  // Clear canvas
  const handleClear = () => {
    if (disabled) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const context = canvas.getContext('2d');
    if (!context) return;

    context.fillStyle = '#ffffff';
    context.fillRect(0, 0, canvas.width, canvas.height);
    
    setHasSignature(false);
    
    if (onChange) {
      onChange(null);
    }
  };

  // Get signature as PNG data URL
  const updateSignatureData = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const dataUrl = canvas.toDataURL('image/png');
    
    if (onChange) {
      onChange(dataUrl);
    }
  };

  // Download signature as PNG
  const handleDownload = () => {
    if (!hasSignature) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const dataUrl = canvas.toDataURL('image/png');
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = 'signature.png';
    link.click();
  };

  return (
    <div className="space-y-4">
      <div 
        className={`relative border-2 ${hasSignature ? 'border-blue-500' : 'border-gray-300'} rounded-md overflow-hidden ${disabled ? 'opacity-60' : ''}`}
        style={{ width: `${width}px`, height: `${height}px` }}
      >
        <canvas
          ref={canvasRef}
          onMouseDown={handleStart}
          onMouseMove={handleMove}
          onMouseUp={handleEnd}
          onMouseLeave={handleEnd}
          onTouchStart={handleStart}
          onTouchMove={handleMove}
          onTouchEnd={handleEnd}
          className="cursor-crosshair bg-white"
        />
        
        {!hasSignature && !disabled && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <p className="text-gray-400 text-sm font-medium">
              {t('signatures.signHere')}
            </p>
          </div>
        )}

        {hasSignature && !disabled && (
          <div className="absolute bottom-2 right-2">
            <div className="flex space-x-1">
              <button
                type="button"
                onClick={handleClear}
                className="p-1 rounded-full bg-white bg-opacity-80 hover:bg-opacity-100 text-red-500 shadow"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="flex justify-between">
        {!disabled && (
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={handleClear}
            disabled={!hasSignature}
          >
            <Trash2 className="h-4 w-4 mr-2" />
            {t('signatures.clear')}
          </Button>
        )}

        <div className="flex space-x-2">
          {hasSignature && (
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={handleDownload}
            >
              <Download className="h-4 w-4 mr-2" />
              {t('signatures.download')}
            </Button>
          )}

          {!disabled && hasSignature && (
            <Button
              type="button"
              onClick={updateSignatureData}
              size="sm"
            >
              <Check className="h-4 w-4 mr-2" />
              {t('signatures.save')}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};