import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { DocumentAnalysisResult, DocumentMetadata, compareDocuments, analyzeLegalDocument, extractDocumentMetadata } from '@/lib/openai';
import { useTranslation } from 'react-i18next';

export const DocumentAnalyzer: React.FC = () => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [documentText1, setDocumentText1] = useState('');
  const [documentText2, setDocumentText2] = useState('');
  const [documentName1, setDocumentName1] = useState('');
  const [documentName2, setDocumentName2] = useState('');
  const [analysisResult, setAnalysisResult] = useState<DocumentAnalysisResult | null>(null);
  const [metadataResult, setMetadataResult] = useState<DocumentMetadata | null>(null);
  const [comparisonResult, setComparisonResult] = useState<any | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisProgress, setAnalysisProgress] = useState(0);
  const [activeTab, setActiveTab] = useState('analysis');

  const handleAnalyzeDocument = async () => {
    if (!documentText1) {
      toast({
        title: t('documents.missingDocumentText'),
        description: t('documents.pleaseEnterDocumentText'),
        variant: 'destructive',
      });
      return;
    }

    try {
      setIsAnalyzing(true);
      setAnalysisProgress(10);

      // Simulate progress
      const progressInterval = setInterval(() => {
        setAnalysisProgress((prev) => Math.min(prev + 5, 95));
      }, 300);

      // Analyze document
      const result = await analyzeLegalDocument(documentText1, documentName1);
      setAnalysisResult(result);
      
      // Extract metadata
      setAnalysisProgress(85);
      const metadata = await extractDocumentMetadata(documentText1, documentName1);
      setMetadataResult(metadata);

      setAnalysisProgress(100);
      clearInterval(progressInterval);
      
      toast({
        title: t('documents.analysisComplete'),
        description: t('documents.documentSuccessfullyAnalyzed'),
      });
    } catch (error) {
      console.error('Error analyzing document:', error);
      toast({
        title: t('documents.analysisError'),
        description: t('documents.errorAnalyzingDocument'),
        variant: 'destructive',
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleCompareDocuments = async () => {
    if (!documentText1 || !documentText2) {
      toast({
        title: t('documents.missingDocumentText'),
        description: t('documents.pleaseEnterBothDocuments'),
        variant: 'destructive',
      });
      return;
    }

    try {
      setIsAnalyzing(true);
      setAnalysisProgress(10);

      // Simulate progress
      const progressInterval = setInterval(() => {
        setAnalysisProgress((prev) => Math.min(prev + 3, 90));
      }, 300);

      // Compare documents
      const result = await compareDocuments(
        documentText1,
        documentText2,
        documentName1 || 'Document 1',
        documentName2 || 'Document 2'
      );
      setComparisonResult(result);

      setAnalysisProgress(100);
      clearInterval(progressInterval);
      
      toast({
        title: t('documents.comparisonComplete'),
        description: t('documents.documentsSuccessfullyCompared'),
      });
    } catch (error) {
      console.error('Error comparing documents:', error);
      toast({
        title: t('documents.comparisonError'),
        description: t('documents.errorComparingDocuments'),
        variant: 'destructive',
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getSeverityBadgeVariant = (severity: string) => {
    switch (severity.toLowerCase()) {
      case 'high':
        return 'destructive';
      case 'medium':
        return 'default';
      case 'low':
        return 'secondary';
      default:
        return 'outline';
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>{t('documents.documentAnalyzer')}</CardTitle>
        <CardDescription>
          {t('documents.documentAnalyzerDescription')}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="analysis" onValueChange={setActiveTab} value={activeTab}>
          <TabsList className="mb-4">
            <TabsTrigger value="analysis">{t('documents.analyze')}</TabsTrigger>
            <TabsTrigger value="compare">{t('documents.compare')}</TabsTrigger>
            {analysisResult && <TabsTrigger value="results">{t('documents.results')}</TabsTrigger>}
            {comparisonResult && <TabsTrigger value="comparison">{t('documents.comparisonResults')}</TabsTrigger>}
          </TabsList>
          
          <TabsContent value="analysis">
            <div className="mb-4">
              <label className="block text-sm font-medium mb-1" htmlFor="documentName">
                {t('documents.documentName')} ({t('common.optional')})
              </label>
              <Input
                id="documentName"
                value={documentName1}
                onChange={(e) => setDocumentName1(e.target.value)}
                className="mb-3"
                placeholder={t('documents.documentNamePlaceholder')}
              />
              
              <label className="block text-sm font-medium mb-1" htmlFor="documentText">
                {t('documents.documentText')} <span className="text-red-600">*</span>
              </label>
              <Textarea
                id="documentText"
                value={documentText1}
                onChange={(e) => setDocumentText1(e.target.value)}
                className="min-h-[250px]"
                placeholder={t('documents.documentTextPlaceholder')}
              />
            </div>
            
            <Button
              onClick={handleAnalyzeDocument}
              disabled={isAnalyzing || !documentText1}
              className="w-full"
            >
              {isAnalyzing ? t('common.analyzing') : t('documents.analyzeDocument')}
            </Button>
            
            {isAnalyzing && (
              <div className="mt-4">
                <div className="flex justify-between mb-1">
                  <span className="text-sm">{t('common.progress')}</span>
                  <span className="text-sm">{analysisProgress}%</span>
                </div>
                <Progress value={analysisProgress} className="h-2" />
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="compare">
            <div className="grid gap-6 md:grid-cols-2">
              <div>
                <label className="block text-sm font-medium mb-1" htmlFor="documentName1">
                  {t('documents.document')} 1 {t('documents.name')} ({t('common.optional')})
                </label>
                <Input
                  id="documentName1"
                  value={documentName1}
                  onChange={(e) => setDocumentName1(e.target.value)}
                  className="mb-3"
                  placeholder={t('documents.documentNamePlaceholder')}
                />
                
                <label className="block text-sm font-medium mb-1" htmlFor="documentText1">
                  {t('documents.document')} 1 {t('documents.text')} <span className="text-red-600">*</span>
                </label>
                <Textarea
                  id="documentText1"
                  value={documentText1}
                  onChange={(e) => setDocumentText1(e.target.value)}
                  className="min-h-[250px]"
                  placeholder={t('documents.documentTextPlaceholder')}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1" htmlFor="documentName2">
                  {t('documents.document')} 2 {t('documents.name')} ({t('common.optional')})
                </label>
                <Input
                  id="documentName2"
                  value={documentName2}
                  onChange={(e) => setDocumentName2(e.target.value)}
                  className="mb-3"
                  placeholder={t('documents.documentNamePlaceholder')}
                />
                
                <label className="block text-sm font-medium mb-1" htmlFor="documentText2">
                  {t('documents.document')} 2 {t('documents.text')} <span className="text-red-600">*</span>
                </label>
                <Textarea
                  id="documentText2"
                  value={documentText2}
                  onChange={(e) => setDocumentText2(e.target.value)}
                  className="min-h-[250px]"
                  placeholder={t('documents.documentTextPlaceholder')}
                />
              </div>
            </div>
            
            <Button
              onClick={handleCompareDocuments}
              disabled={isAnalyzing || !documentText1 || !documentText2}
              className="w-full mt-4"
            >
              {isAnalyzing ? t('common.comparing') : t('documents.compareDocuments')}
            </Button>
            
            {isAnalyzing && (
              <div className="mt-4">
                <div className="flex justify-between mb-1">
                  <span className="text-sm">{t('common.progress')}</span>
                  <span className="text-sm">{analysisProgress}%</span>
                </div>
                <Progress value={analysisProgress} className="h-2" />
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="results">
            {analysisResult && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-2">{t('documents.documentSummary')}</h3>
                  <p className="text-sm text-gray-700 dark:text-gray-300">{analysisResult.summary}</p>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium mb-2">{t('documents.keyPoints')}</h3>
                  <ul className="list-disc pl-5 space-y-1">
                    {analysisResult.keyPoints.map((point, index) => (
                      <li key={index} className="text-sm">{point}</li>
                    ))}
                  </ul>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium mb-2">{t('documents.legalRisks')}</h3>
                  <Accordion type="single" collapsible className="w-full">
                    {analysisResult.legalRisks.map((risk, index) => (
                      <AccordionItem key={index} value={`risk-${index}`}>
                        <AccordionTrigger className="text-left">
                          <div className="flex items-center">
                            <span className="mr-2">{risk.risk}</span>
                            <Badge variant={getSeverityBadgeVariant(risk.severity)}>
                              {risk.severity}
                            </Badge>
                          </div>
                        </AccordionTrigger>
                        <AccordionContent>
                          <p className="text-sm">{risk.suggestion}</p>
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium mb-2">{t('documents.nextSteps')}</h3>
                  <ul className="list-disc pl-5 space-y-1">
                    {analysisResult.nextSteps.map((step, index) => (
                      <li key={index} className="text-sm">{step}</li>
                    ))}
                  </ul>
                </div>
                
                {analysisResult.relevantCaseLaw && analysisResult.relevantCaseLaw.length > 0 && (
                  <div>
                    <h3 className="text-lg font-medium mb-2">{t('documents.relevantCaseLaw')}</h3>
                    <ul className="list-disc pl-5 space-y-1">
                      {analysisResult.relevantCaseLaw.map((law, index) => (
                        <li key={index} className="text-sm">{law}</li>
                      ))}
                    </ul>
                  </div>
                )}
                
                <div>
                  <h3 className="text-lg font-medium">{t('documents.confidenceScore')}</h3>
                  <div className="mt-2">
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">{t('common.confidence')}</span>
                      <span className="text-sm">{Math.round(analysisResult.confidenceScore * 100)}%</span>
                    </div>
                    <Progress value={analysisResult.confidenceScore * 100} className="h-2" />
                  </div>
                </div>
              </div>
            )}
            
            {metadataResult && (
              <div className="mt-8 pt-8 border-t">
                <h3 className="text-lg font-medium mb-4">{t('documents.documentMetadata')}</h3>
                
                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <p className="text-sm font-medium mb-1">{t('documents.documentType')}</p>
                    <p className="text-sm text-gray-700 dark:text-gray-300">{metadataResult.documentType}</p>
                  </div>
                  
                  {metadataResult.effectiveDate && (
                    <div>
                      <p className="text-sm font-medium mb-1">{t('documents.effectiveDate')}</p>
                      <p className="text-sm text-gray-700 dark:text-gray-300">{metadataResult.effectiveDate}</p>
                    </div>
                  )}
                  
                  {metadataResult.expirationDate && (
                    <div>
                      <p className="text-sm font-medium mb-1">{t('documents.expirationDate')}</p>
                      <p className="text-sm text-gray-700 dark:text-gray-300">{metadataResult.expirationDate}</p>
                    </div>
                  )}
                  
                  {metadataResult.jurisdiction && (
                    <div>
                      <p className="text-sm font-medium mb-1">{t('documents.jurisdiction')}</p>
                      <p className="text-sm text-gray-700 dark:text-gray-300">{metadataResult.jurisdiction}</p>
                    </div>
                  )}
                  
                  {metadataResult.governingLaw && (
                    <div>
                      <p className="text-sm font-medium mb-1">{t('documents.governingLaw')}</p>
                      <p className="text-sm text-gray-700 dark:text-gray-300">{metadataResult.governingLaw}</p>
                    </div>
                  )}
                </div>
                
                <div className="mt-4">
                  <p className="text-sm font-medium mb-1">{t('documents.parties')}</p>
                  <ul className="list-disc pl-5 space-y-1">
                    {metadataResult.parties.map((party, index) => (
                      <li key={index} className="text-sm">{party}</li>
                    ))}
                  </ul>
                </div>
                
                <div className="mt-4">
                  <p className="text-sm font-medium mb-1">{t('documents.keyProvisions')}</p>
                  <ul className="list-disc pl-5 space-y-1">
                    {metadataResult.keyProvisions.map((provision, index) => (
                      <li key={index} className="text-sm">{provision}</li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="comparison">
            {comparisonResult && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-2">{t('documents.similarities')}</h3>
                  <ul className="list-disc pl-5 space-y-1">
                    {comparisonResult.similarities.map((similarity, index) => (
                      <li key={index} className="text-sm">{similarity}</li>
                    ))}
                  </ul>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium mb-2">{t('documents.differences')}</h3>
                  <ul className="list-disc pl-5 space-y-1">
                    {comparisonResult.differences.map((difference, index) => (
                      <li key={index} className="text-sm">{difference}</li>
                    ))}
                  </ul>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium mb-2">{t('documents.recommendations')}</h3>
                  <ul className="list-disc pl-5 space-y-1">
                    {comparisonResult.recommendations.map((recommendation, index) => (
                      <li key={index} className="text-sm">{recommendation}</li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="flex justify-between">
        {analysisResult && activeTab === 'results' && (
          <Button variant="outline" onClick={() => setActiveTab('analysis')}>
            {t('common.analyze')} {t('common.another')}
          </Button>
        )}
        {comparisonResult && activeTab === 'comparison' && (
          <Button variant="outline" onClick={() => setActiveTab('compare')}>
            {t('common.compare')} {t('common.other')}
          </Button>
        )}
      </CardFooter>
    </Card>
  );
};