import React from "react";

export interface ToastProps {
  id?: string;
  title?: string;
  description?: string;
  variant?: "default" | "destructive" | "success";
  onClose?: () => void;
}

export const Toast: React.FC<ToastProps> = ({
  title,
  description,
  variant = "default",
  onClose,
}) => {
  const variantClasses = {
    default: "bg-white border-gray-200",
    destructive: "bg-red-50 border-red-200 text-red-900",
    success: "bg-green-50 border-green-200 text-green-900",
  };

  return (
    <div
      className={`rounded-md border p-4 shadow-md ${variantClasses[variant]} transition-all duration-300 ease-in-out`}
      role="alert"
    >
      <div className="flex items-start gap-4">
        <div className="flex-1">
          {title && <h3 className="font-medium mb-1">{title}</h3>}
          {description && <p className="text-sm opacity-90">{description}</p>}
        </div>
        {onClose && (
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-500"
            aria-label="Close toast"
          >
            <span className="text-lg">×</span>
          </button>
        )}
      </div>
    </div>
  );
};

// Simple toast manager
const TOAST_DURATION = 5000; // 5 seconds
let toasts: {
  id: string;
  props: ToastProps;
  timeoutId?: NodeJS.Timeout;
}[] = [];
let listeners: (() => void)[] = [];

function notifyListeners() {
  listeners.forEach((listener) => listener());
}

export function toast(props: ToastProps) {
  const id = Math.random().toString(36).substring(2, 9);
  
  const newToast = {
    id,
    props,
    timeoutId: setTimeout(() => {
      dismissToast(id);
    }, TOAST_DURATION),
  };
  
  toasts = [...toasts, newToast];
  notifyListeners();
  
  return id;
}

export function dismissToast(id: string) {
  const toast = toasts.find((t) => t.id === id);
  if (toast?.timeoutId) {
    clearTimeout(toast.timeoutId);
  }
  
  toasts = toasts.filter((t) => t.id !== id);
  notifyListeners();
}

export function useToasts() {
  const [state, setState] = React.useState(toasts);
  
  React.useEffect(() => {
    const listener = () => setState([...toasts]);
    listeners.push(listener);
    
    return () => {
      listeners = listeners.filter((l) => l !== listener);
    };
  }, []);
  
  return state;
}