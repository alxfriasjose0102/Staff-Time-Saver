import * as React from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { format } from "date-fns";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

export type CalendarProps = React.HTMLAttributes<HTMLDivElement> & {
  mode?: "single" | "range" | "multiple";
  selected?: Date | Date[] | null;
  disabled?: boolean | ((date: Date) => boolean);
  onSelect?: (date: Date | undefined) => void;
  month?: Date;
  onMonthChange?: (date: Date) => void;
  initialFocus?: boolean;
};

function Calendar({
  className,
  mode = "single",
  selected,
  disabled,
  onSelect,
  month = new Date(),
  onMonthChange,
  initialFocus,
  ...props
}: CalendarProps) {
  const [currentMonth, setCurrentMonth] = React.useState(month);
  
  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    
    const days = [];
    // Get the day of the week for the first day (0 is Sunday)
    const firstDayIndex = firstDay.getDay();
    
    // Fill in days from previous month
    for (let i = 0; i < firstDayIndex; i++) {
      const prevMonthDay = new Date(year, month, -firstDayIndex + i + 1);
      days.push({ date: prevMonthDay, isCurrentMonth: false });
    }
    
    // Fill in days from current month
    for (let i = 1; i <= lastDay.getDate(); i++) {
      const day = new Date(year, month, i);
      days.push({ date: day, isCurrentMonth: true });
    }
    
    return days;
  };
  
  const isSelected = (date: Date) => {
    if (!selected) return false;
    
    if (Array.isArray(selected)) {
      return selected.some(selectedDate => 
        selectedDate.getDate() === date.getDate() && 
        selectedDate.getMonth() === date.getMonth() && 
        selectedDate.getFullYear() === date.getFullYear()
      );
    }
    
    return selected.getDate() === date.getDate() && 
           selected.getMonth() === date.getMonth() && 
           selected.getFullYear() === date.getFullYear();
  };
  
  const isDisabled = (date: Date) => {
    if (!disabled) return false;
    if (typeof disabled === "function") return disabled(date);
    return disabled;
  };
  
  const handlePreviousMonth = () => {
    const prevMonth = new Date(currentMonth);
    prevMonth.setMonth(prevMonth.getMonth() - 1);
    setCurrentMonth(prevMonth);
    onMonthChange?.(prevMonth);
  };
  
  const handleNextMonth = () => {
    const nextMonth = new Date(currentMonth);
    nextMonth.setMonth(nextMonth.getMonth() + 1);
    setCurrentMonth(nextMonth);
    onMonthChange?.(nextMonth);
  };
  
  const handleSelectDate = (date: Date) => {
    if (isDisabled(date)) return;
    onSelect?.(date);
  };
  
  const days = getDaysInMonth(currentMonth);
  
  return (
    <div className={cn("p-3", className)} {...props}>
      <div className="flex items-center justify-between mb-4">
        <Button
          variant="outline"
          size="icon"
          onClick={handlePreviousMonth}
          className="h-7 w-7"
        >
          <ChevronLeft className="h-4 w-4" />
          <span className="sr-only">Previous month</span>
        </Button>
        <div className="font-medium">
          {format(currentMonth, "MMMM yyyy")}
        </div>
        <Button
          variant="outline"
          size="icon"
          onClick={handleNextMonth}
          className="h-7 w-7"
        >
          <ChevronRight className="h-4 w-4" />
          <span className="sr-only">Next month</span>
        </Button>
      </div>
      <div className="grid grid-cols-7 gap-2 mb-2">
        {["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"].map((day) => (
          <div key={day} className="text-center text-sm text-muted-foreground">
            {day}
          </div>
        ))}
      </div>
      <div className="grid grid-cols-7 gap-2">
        {days.map(({ date, isCurrentMonth }, i) => (
          <Button
            key={i}
            variant={isSelected(date) ? "default" : "ghost"}
            className={cn(
              "h-9 w-9 p-0 font-normal",
              !isCurrentMonth && "text-muted-foreground opacity-50",
              isSelected(date) && "bg-primary text-primary-foreground hover:bg-primary hover:text-primary-foreground",
              isDisabled(date) && "opacity-50 cursor-not-allowed"
            )}
            onClick={() => handleSelectDate(date)}
            disabled={isDisabled(date)}
          >
            {date.getDate()}
          </Button>
        ))}
      </div>
    </div>
  );
}

Calendar.displayName = "Calendar";

export { Calendar };