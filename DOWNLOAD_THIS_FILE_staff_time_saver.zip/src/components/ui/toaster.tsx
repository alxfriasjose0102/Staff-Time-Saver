import React from "react";
import { ToastProps, Toast, useToasts, dismissToast } from "./toast";

export const Toaster: React.FC = () => {
  const toasts = useToasts();

  if (toasts.length === 0) {
    return null;
  }

  return (
    <div
      className="fixed bottom-0 right-0 z-50 p-4 w-full max-w-sm space-y-4 pointer-events-none"
      aria-live="polite"
    >
      {toasts.map((toast) => (
        <div key={toast.id} className="pointer-events-auto transform transition-all duration-300">
          <Toast
            id={toast.id}
            title={toast.props.title}
            description={toast.props.description}
            variant={toast.props.variant}
            onClose={() => dismissToast(toast.id)}
          />
        </div>
      ))}
    </div>
  );
};