import * as React from "react";
import { cn } from "@/lib/utils";

const PopoverContext = React.createContext<{
  open: boolean;
  setOpen: React.Dispatch<React.SetStateAction<boolean>>;
  onOpenChange?: (open: boolean) => void;
} | null>(null);

export interface PopoverProps extends React.HTMLAttributes<HTMLDivElement> {
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  children: React.ReactNode;
}

function Popover({
  className,
  open,
  onOpenChange,
  children,
  ...props
}: PopoverProps) {
  const [internalOpen, setInternalOpen] = React.useState(open || false);
  
  const isControlled = open !== undefined;
  const isOpen = isControlled ? open : internalOpen;
  
  const handleOpenChange = React.useCallback((value: boolean) => {
    if (!isControlled) {
      setInternalOpen(value);
    }
    onOpenChange?.(value);
  }, [isControlled, onOpenChange]);

  return (
    <PopoverContext.Provider
      value={{
        open: isOpen,
        setOpen: setInternalOpen,
        onOpenChange: handleOpenChange,
      }}
    >
      <div
        className={cn("relative", className)}
        {...props}
      >
        {children}
      </div>
    </PopoverContext.Provider>
  );
}

export interface PopoverTriggerProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  asChild?: boolean;
}

function PopoverTrigger({
  asChild = false,
  children,
  className,
  ...props
}: PopoverTriggerProps) {
  const context = React.useContext(PopoverContext);
  
  if (!context) {
    throw new Error("PopoverTrigger must be used within a Popover");
  }
  
  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    if (props.onClick) {
      props.onClick(e);
    }
    context.onOpenChange?.(!context.open);
  };
  
  if (asChild && React.isValidElement(children)) {
    return React.cloneElement(
      children as React.ReactElement<any>,
      {
        ...props,
        onClick: handleClick,
      }
    );
  }
  
  return (
    <button
      type="button"
      className={className}
      {...props}
      onClick={handleClick}
    >
      {children}
    </button>
  );
}

export interface PopoverContentProps
  extends React.HTMLAttributes<HTMLDivElement> {
  align?: "start" | "center" | "end";
}

function PopoverContent({
  align = "center",
  className,
  children,
  ...props
}: PopoverContentProps) {
  const context = React.useContext(PopoverContext);
  
  if (!context) {
    throw new Error("PopoverContent must be used within a Popover");
  }
  
  if (!context.open) {
    return null;
  }
  
  return (
    <div
      className={cn(
        "absolute z-50 bg-popover text-popover-foreground shadow-md rounded-md border animate-in data-[side=bottom]:slide-in-from-top-2",
        {
          "left-0": align === "start",
          "left-1/2 -translate-x-1/2": align === "center",
          "right-0": align === "end",
        },
        "w-72 top-full mt-2",
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
}

export { Popover, PopoverTrigger, PopoverContent };