import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { Search, Loader2, Filter, User, ArrowUpDown, MoreHorizontal, FileText, UserPlus } from 'lucide-react';
import { Button } from './ui/button';
import { RoleBasedAccess } from './RoleBasedAccess';
import { permissions } from '../shared/schema';

interface Client {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  company?: string;
  createdAt: string;
  assigned_attorney?: {
    id: number;
    firstName: string;
    lastName: string;
    email: string;
    role: string;
  };
}

interface ClientListProps {
  onViewClient: (id: number) => void;
  onNewClient: () => void;
}

export const ClientList: React.FC<ClientListProps> = ({ onViewClient, onNewClient }) => {
  const { t } = useTranslation();
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState<'name' | 'company' | 'createdAt'>('createdAt');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  
  // Fetch clients
  const { data: clients, isLoading, error } = useQuery<Client[]>({
    queryKey: ['/api/clients'],
    queryFn: async () => {
      const response = await fetch('/api/clients', {
        credentials: 'include',
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch clients');
      }
      
      return response.json();
    },
  });
  
  // Handle search input change
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };
  
  // Toggle sort order or change sort column
  const handleSort = (column: 'name' | 'company' | 'createdAt') => {
    if (sortBy === column) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(column);
      setSortOrder('asc');
    }
  };
  
  // Filter and sort clients
  const filteredAndSortedClients = React.useMemo(() => {
    if (!clients) return [];
    
    let result = [...clients];
    
    // Filter by search term
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      result = result.filter(
        client =>
          client.firstName.toLowerCase().includes(term) ||
          client.lastName.toLowerCase().includes(term) ||
          client.email.toLowerCase().includes(term) ||
          (client.company && client.company.toLowerCase().includes(term))
      );
    }
    
    // Sort by selected column
    result.sort((a, b) => {
      let compareA, compareB;
      
      if (sortBy === 'name') {
        compareA = `${a.lastName} ${a.firstName}`.toLowerCase();
        compareB = `${b.lastName} ${b.firstName}`.toLowerCase();
      } else if (sortBy === 'company') {
        compareA = (a.company || '').toLowerCase();
        compareB = (b.company || '').toLowerCase();
      } else {
        // createdAt
        compareA = new Date(a.createdAt).getTime();
        compareB = new Date(b.createdAt).getTime();
      }
      
      if (compareA < compareB) return sortOrder === 'asc' ? -1 : 1;
      if (compareA > compareB) return sortOrder === 'asc' ? 1 : -1;
      return 0;
    });
    
    return result;
  }, [clients, searchTerm, sortBy, sortOrder]);
  
  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="flex h-64 flex-col items-center justify-center text-center">
        <p className="text-lg font-medium text-red-500 mb-4">
          {t('clients.errorLoading')}
        </p>
        <p className="text-gray-500 dark:text-gray-400">
          {(error as Error).message}
        </p>
      </div>
    );
  }
  
  if (clients && clients.length === 0) {
    return (
      <div className="flex h-64 flex-col items-center justify-center text-center">
        <User className="h-12 w-12 text-gray-400 mb-4" />
        <p className="text-lg font-medium text-gray-500 dark:text-gray-400 mb-4">
          {t('clients.noClientsYet')}
        </p>
        <RoleBasedAccess 
          permission={permissions.CREATE_CLIENT}
          fallback={<p className="text-sm text-gray-400">{t('common.noPermission')}</p>}
        >
          <Button onClick={onNewClient}>
            <UserPlus className="h-4 w-4 mr-2" />
            {t('clients.addFirstClient')}
          </Button>
        </RoleBasedAccess>
      </div>
    );
  }
  
  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row justify-between gap-4">
        {/* Search bar */}
        <div className="relative max-w-md">
          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
            <Search className="h-4 w-4 text-gray-400" />
          </div>
          <input
            type="text"
            className="bg-white dark:bg-gray-800 text-gray-900 dark:text-white text-sm rounded-lg border border-gray-300 dark:border-gray-600 block w-full pl-10 p-2.5 focus:ring-blue-500 focus:border-blue-500"
            placeholder={t('clients.searchPlaceholder')}
            value={searchTerm}
            onChange={handleSearchChange}
          />
        </div>
        
        {/* Actions */}
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Filter className="h-4 w-4 mr-2" />
            {t('common.filter')}
          </Button>
          <RoleBasedAccess permission={permissions.CREATE_CLIENT}>
            <Button onClick={onNewClient}>
              <UserPlus className="h-4 w-4 mr-2" />
              {t('clients.newClient')}
            </Button>
          </RoleBasedAccess>
        </div>
      </div>
      
      {/* Results count */}
      <p className="text-sm text-gray-500 dark:text-gray-400">
        {t('clients.showingResults', { count: filteredAndSortedClients.length, total: clients?.length || 0 })}
      </p>
      
      {/* Clients table */}
      <div className="overflow-x-auto bg-white dark:bg-gray-800 rounded-lg shadow">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
          <thead className="bg-gray-50 dark:bg-gray-700">
            <tr>
              <th 
                scope="col" 
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider cursor-pointer"
                onClick={() => handleSort('name')}
              >
                <div className="flex items-center">
                  {t('clients.name')}
                  <ArrowUpDown className="h-4 w-4 ml-1" />
                </div>
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                {t('clients.email')}
              </th>
              <th 
                scope="col" 
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider cursor-pointer"
                onClick={() => handleSort('company')}
              >
                <div className="flex items-center">
                  {t('clients.company')}
                  <ArrowUpDown className="h-4 w-4 ml-1" />
                </div>
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                {t('clients.assignedAttorney')}
              </th>
              <th 
                scope="col" 
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider cursor-pointer"
                onClick={() => handleSort('createdAt')}
              >
                <div className="flex items-center">
                  {t('clients.createdAt')}
                  <ArrowUpDown className="h-4 w-4 ml-1" />
                </div>
              </th>
              <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                {t('common.actions')}
              </th>
            </tr>
          </thead>
          <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
            {filteredAndSortedClients.map(client => (
              <tr 
                key={client.id} 
                className="hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer transition-colors"
                onClick={() => onViewClient(client.id)}
              >
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 h-8 w-8 bg-blue-100 dark:bg-blue-800 rounded-full flex items-center justify-center">
                      <span className="text-xs font-medium text-blue-800 dark:text-blue-100">
                        {client.firstName[0]}{client.lastName[0]}
                      </span>
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-gray-900 dark:text-white">
                        {client.firstName} {client.lastName}
                      </div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                  {client.email}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                  {client.company || '-'}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                  {client.assigned_attorney ? (
                    <div className="flex items-center">
                      <div className="w-6 h-6 rounded-full bg-blue-50 dark:bg-blue-900/30 flex items-center justify-center mr-2">
                        <User className="w-3 h-3 text-blue-600 dark:text-blue-400" />
                      </div>
                      <span>{client.assigned_attorney.firstName} {client.assigned_attorney.lastName}</span>
                    </div>
                  ) : (
                    <span className="text-gray-400 dark:text-gray-500">
                      {t('clients.noAttorney')}
                    </span>
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                  {new Date(client.createdAt).toLocaleDateString()}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm">
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className="text-gray-600 dark:text-gray-300 hover:text-blue-700 dark:hover:text-blue-400"
                    onClick={(e) => {
                      e.stopPropagation();
                      onViewClient(client.id);
                    }}
                  >
                    <FileText className="h-4 w-4 mr-1" />
                    {t('common.view')}
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-gray-600 dark:text-gray-300 hover:text-gray-800 dark:hover:text-gray-100 ml-2"
                    onClick={(e) => {
                      e.stopPropagation();
                      // Handle additional actions menu
                    }}
                  >
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};