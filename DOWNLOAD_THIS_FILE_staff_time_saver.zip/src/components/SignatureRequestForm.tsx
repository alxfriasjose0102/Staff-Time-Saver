import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useMutation, useQuery } from '@tanstack/react-query';
import { z } from 'zod';
import { Loader2, Send, FileText, User } from 'lucide-react';
import { Button } from './ui/button';
import { useToast } from '../hooks/use-toast';

const signatureRequestSchema = z.object({
  documentId: z.number(),
  recipientEmail: z.string().email('Invalid email address'),
  message: z.string().optional(),
  expiresAt: z.string().optional(),
});

type SignatureRequestData = z.infer<typeof signatureRequestSchema>;

interface Document {
  id: number;
  title: string;
  fileName?: string;
  status: string;
  client: {
    id: number;
    firstName: string;
    lastName: string;
    email: string;
  };
}

interface SignatureRequestFormProps {
  documentId: number;
  onCancel: () => void;
  onSuccess: () => void;
}

export const SignatureRequestForm: React.FC<SignatureRequestFormProps> = ({
  documentId,
  onCancel,
  onSuccess,
}) => {
  const { t } = useTranslation();
  const { toast } = useToast();

  const [formData, setFormData] = useState<SignatureRequestData>({
    documentId,
    recipientEmail: '',
    message: '',
    expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 7 days from now
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  // Get document details
  const { data: document, isLoading: isLoadingDocument } = useQuery<Document>({
    queryKey: ['/api/documents', documentId],
    queryFn: async () => {
      const response = await fetch(`/api/documents/${documentId}`, {
        credentials: 'include',
      });

      if (!response.ok) {
        throw new Error('Failed to fetch document details');
      }

      return response.json();
    },
  });

  // Send signature request mutation
  const sendSignatureRequestMutation = useMutation({
    mutationFn: async (data: SignatureRequestData) => {
      const response = await fetch('/api/signature-requests', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
        credentials: 'include',
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to send signature request');
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: 'Success',
        description: 'Signature request has been sent successfully',
        variant: 'success',
      });
      onSuccess();
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  // Handle input changes
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));

    // Clear error when field is edited
    if (errors[name]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  // Auto-fill recipient email if client exists
  const handleUseClientEmail = () => {
    if (document?.client?.email) {
      setFormData(prev => ({ ...prev, recipientEmail: document.client.email }));
    }
  };

  // Validate form
  const validateForm = () => {
    try {
      signatureRequestSchema.parse(formData);
      setErrors({});
      return true;
    } catch (error) {
      if (error instanceof z.ZodError) {
        const newErrors: Record<string, string> = {};
        error.errors.forEach(err => {
          const path = err.path.join('.');
          newErrors[path] = err.message;
        });
        setErrors(newErrors);
      }
      return false;
    }
  };

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (validateForm()) {
      sendSignatureRequestMutation.mutate(formData);
    }
  };

  if (isLoadingDocument) {
    return (
      <div className="flex h-40 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
      <h2 className="text-2xl font-bold mb-6">{t('signatures.requestSignatureTitle')}</h2>

      {document && (
        <div className="mb-6 p-4 bg-gray-50 dark:bg-gray-700 rounded-lg flex items-start">
          <FileText className="h-6 w-6 text-blue-500 mr-3 mt-1" />
          <div>
            <p className="font-medium">{document.title}</p>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              {document.fileName || t('documents.noFileName')}
            </p>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              {t('signatures.recipientEmail')} *
            </label>
            <div className="flex gap-2">
              <input
                type="email"
                name="recipientEmail"
                value={formData.recipientEmail}
                onChange={handleChange}
                className={`w-full rounded-md border ${errors.recipientEmail ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'} px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700`}
                placeholder="email@example.com"
              />
              {document?.client?.email && (
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={handleUseClientEmail}
                  className="whitespace-nowrap"
                >
                  <User className="h-4 w-4 mr-1" />
                  {t('signatures.useClientEmail')}
                </Button>
              )}
            </div>
            {errors.recipientEmail && <p className="mt-1 text-sm text-red-500">{errors.recipientEmail}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              {t('signatures.message')}
            </label>
            <textarea
              name="message"
              value={formData.message}
              onChange={handleChange}
              rows={4}
              className="w-full rounded-md border border-gray-300 dark:border-gray-600 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700"
              placeholder={t('signatures.messagePlaceholder')}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              {t('signatures.expiryDate')}
            </label>
            <input
              type="date"
              name="expiresAt"
              value={formData.expiresAt}
              onChange={handleChange}
              min={new Date().toISOString().split('T')[0]}
              className="w-full rounded-md border border-gray-300 dark:border-gray-600 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700"
            />
            <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
              {t('signatures.expiryInfo')}
            </p>
          </div>
        </div>

        <div className="flex justify-end space-x-3 pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
          >
            {t('common.cancel')}
          </Button>

          <Button
            type="submit"
            className="bg-blue-600 hover:bg-blue-700 text-white font-semibold"
            disabled={sendSignatureRequestMutation.isPending}
          >
            {sendSignatureRequestMutation.isPending ? (
              <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> {t('common.processing')}</>
            ) : (
              <><Send className="mr-2 h-4 w-4" /> {t('signatures.send')}</>
            )}
          </Button>
        </div>
      </form>
    </div>
  );
};