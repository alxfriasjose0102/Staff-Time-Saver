import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { 
  Search, 
  Loader2, 
  Filter, 
  FileText, 
  ArrowUpDown, 
  MoreHorizontal, 
  Download,
  Eye,
  Clock,
  Plus
} from 'lucide-react';
import { Button } from './ui/button';
import { formatDate } from '../lib/utils';
import { documentStatusEnum, permissions } from '../shared/schema';
import { RoleBasedAccess, useHasPermission } from './RoleBasedAccess';

interface Document {
  id: number;
  title: string;
  fileName?: string;
  fileType?: string;
  fileSize?: number;
  status: string;
  needsSignature: boolean;
  createdAt: string;
  updatedAt: string;
  client: {
    id: number;
    firstName: string;
    lastName: string;
  };
  matter?: {
    id: number;
    title: string;
  };
}

interface DocumentListProps {
  onViewDocument: (id: number) => void;
  onUploadDocument: () => void;
}

export const DocumentList: React.FC<DocumentListProps> = ({ onViewDocument, onUploadDocument }) => {
  const { t } = useTranslation();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<'title' | 'client' | 'status' | 'createdAt'>('createdAt');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const canReadDocument = useHasPermission(permissions.READ_DOCUMENT);
  
  // Fetch documents
  const { data: documents, isLoading, error } = useQuery<Document[]>({
    queryKey: ['/api/documents'],
    queryFn: async () => {
      const response = await fetch('/api/documents', {
        credentials: 'include',
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch documents');
      }
      
      return response.json();
    },
  });
  
  // Handle search input change
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };
  
  // Toggle sort order or change sort column
  const handleSort = (column: 'title' | 'client' | 'status' | 'createdAt') => {
    if (sortBy === column) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(column);
      setSortOrder('asc');
    }
  };

  // Handle status filter change
  const handleStatusFilterChange = (status: string | null) => {
    setStatusFilter(status);
  };
  
  // Filter and sort documents
  const filteredAndSortedDocuments = React.useMemo(() => {
    if (!documents) return [];
    
    let result = [...documents];
    
    // Filter by search term
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      result = result.filter(
        doc =>
          doc.title.toLowerCase().includes(term) ||
          (doc.fileName && doc.fileName.toLowerCase().includes(term)) ||
          `${doc.client.firstName} ${doc.client.lastName}`.toLowerCase().includes(term) ||
          (doc.matter && doc.matter.title.toLowerCase().includes(term))
      );
    }
    
    // Filter by status if selected
    if (statusFilter) {
      result = result.filter(doc => doc.status === statusFilter);
    }
    
    // Sort by selected column
    result.sort((a, b) => {
      let compareA, compareB;
      
      if (sortBy === 'title') {
        compareA = a.title.toLowerCase();
        compareB = b.title.toLowerCase();
      } else if (sortBy === 'client') {
        compareA = `${a.client.lastName} ${a.client.firstName}`.toLowerCase();
        compareB = `${b.client.lastName} ${b.client.firstName}`.toLowerCase();
      } else if (sortBy === 'status') {
        compareA = a.status;
        compareB = b.status;
      } else {
        // createdAt
        compareA = new Date(a.createdAt).getTime();
        compareB = new Date(b.createdAt).getTime();
      }
      
      if (compareA < compareB) return sortOrder === 'asc' ? -1 : 1;
      if (compareA > compareB) return sortOrder === 'asc' ? 1 : -1;
      return 0;
    });
    
    return result;
  }, [documents, searchTerm, statusFilter, sortBy, sortOrder]);
  
  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="flex h-64 flex-col items-center justify-center text-center">
        <p className="text-lg font-medium text-red-500 mb-4">
          {t('documents.errorLoading')}
        </p>
        <p className="text-gray-500 dark:text-gray-400">
          {(error as Error).message}
        </p>
      </div>
    );
  }
  
  if (documents && documents.length === 0) {
    return (
      <div className="flex h-64 flex-col items-center justify-center text-center">
        <FileText className="h-12 w-12 text-gray-400 mb-4" />
        <p className="text-lg font-medium text-gray-500 dark:text-gray-400 mb-4">
          {t('documents.noDocumentsYet')}
        </p>
        <RoleBasedAccess 
          permission={permissions.CREATE_DOCUMENT}
          fallback={<p className="text-sm text-gray-500">{t('documents.needPermissionToUpload')}</p>}
        >
          <Button onClick={onUploadDocument}>
            <Plus className="h-4 w-4 mr-2" />
            {t('documents.uploadFirstDocument')}
          </Button>
        </RoleBasedAccess>
      </div>
    );
  }
  
  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row justify-between gap-4">
        {/* Search bar */}
        <div className="relative max-w-md">
          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
            <Search className="h-4 w-4 text-gray-400" />
          </div>
          <input
            type="text"
            className="bg-white dark:bg-gray-800 text-gray-900 dark:text-white text-sm rounded-lg border border-gray-300 dark:border-gray-600 block w-full pl-10 p-2.5 focus:ring-blue-500 focus:border-blue-500"
            placeholder={t('documents.searchPlaceholder')}
            value={searchTerm}
            onChange={handleSearchChange}
          />
        </div>
        
        {/* Actions */}
        <div className="flex gap-2">
          <div className="dropdown dropdown-end">
            <Button variant="outline" size="sm" className="inline-flex">
              <Filter className="h-4 w-4 mr-2" />
              {statusFilter ? t(`documents.status.${statusFilter.toLowerCase()}`) : t('common.filter')}
            </Button>
            <div className="dropdown-content bg-white dark:bg-gray-800 shadow-xl rounded-md p-2 w-40 mt-1">
              <div className="flex flex-col space-y-1">
                <button 
                  className="text-left px-3 py-1 text-sm rounded hover:bg-gray-100 dark:hover:bg-gray-700"
                  onClick={() => handleStatusFilterChange(null)}
                >
                  {t('common.all')}
                </button>
                {Object.values(documentStatusEnum.enumValues).map(status => (
                  <button 
                    key={status}
                    className="text-left px-3 py-1 text-sm rounded hover:bg-gray-100 dark:hover:bg-gray-700"
                    onClick={() => handleStatusFilterChange(status)}
                  >
                    {t(`documents.status.${status.toLowerCase()}`)}
                  </button>
                ))}
              </div>
            </div>
          </div>
          <RoleBasedAccess permission={permissions.CREATE_DOCUMENT}>
            <Button onClick={onUploadDocument}>
              <Plus className="h-4 w-4 mr-2" />
              {t('documents.uploadDocument')}
            </Button>
          </RoleBasedAccess>
        </div>
      </div>
      
      {/* Results count */}
      <p className="text-sm text-gray-500 dark:text-gray-400">
        {t('documents.showingResults', { count: filteredAndSortedDocuments.length, total: documents?.length || 0 })}
      </p>
      
      {/* Documents table */}
      <div className="overflow-x-auto bg-white dark:bg-gray-800 rounded-lg shadow">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
          <thead className="bg-gray-50 dark:bg-gray-700">
            <tr>
              <th 
                scope="col" 
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider cursor-pointer"
                onClick={() => handleSort('title')}
              >
                <div className="flex items-center">
                  {t('documents.title')}
                  <ArrowUpDown className="h-4 w-4 ml-1" />
                </div>
              </th>
              <th 
                scope="col" 
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider cursor-pointer"
                onClick={() => handleSort('client')}
              >
                <div className="flex items-center">
                  {t('documents.client')}
                  <ArrowUpDown className="h-4 w-4 ml-1" />
                </div>
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                {t('documents.matter')}
              </th>
              <th 
                scope="col" 
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider cursor-pointer"
                onClick={() => handleSort('status')}
              >
                <div className="flex items-center">
                  {t('documents.status')}
                  <ArrowUpDown className="h-4 w-4 ml-1" />
                </div>
              </th>
              <th 
                scope="col" 
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider cursor-pointer"
                onClick={() => handleSort('createdAt')}
              >
                <div className="flex items-center">
                  {t('documents.createdAt')}
                  <ArrowUpDown className="h-4 w-4 ml-1" />
                </div>
              </th>
              <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                {t('common.actions')}
              </th>
            </tr>
          </thead>
          <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
            {filteredAndSortedDocuments.map(doc => (
              <tr 
                key={doc.id} 
                className="hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer transition-colors"
                onClick={(e) => {
                  if (canReadDocument) {
                    onViewDocument(doc.id);
                  } else {
                    e.preventDefault();
                  }
                }}
              >
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 h-8 w-8 bg-gray-100 dark:bg-gray-700 rounded-md flex items-center justify-center">
                      <FileText className="h-4 w-4 text-gray-500 dark:text-gray-400" />
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-gray-900 dark:text-white">
                        {doc.title}
                      </div>
                      {doc.fileName && (
                        <div className="text-xs text-gray-500 dark:text-gray-400">
                          {doc.fileName}
                        </div>
                      )}
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                  {doc.client.firstName} {doc.client.lastName}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                  {doc.matter ? doc.matter.title : '-'}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                    ${doc.status === 'Draft' ? 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300' : ''}
                    ${doc.status === 'Pending Review' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300' : ''}
                    ${doc.status === 'Pending Signature' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300' : ''}
                    ${doc.status === 'Signed' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300' : ''}
                    ${doc.status === 'Final' ? 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300' : ''}
                    ${doc.status === 'Archived' ? 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300' : ''}
                  `}>
                    {t(`documents.status.${doc.status.toLowerCase()}`)}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-1 text-gray-400" />
                    {formatDate(new Date(doc.createdAt))}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm">
                  <RoleBasedAccess permission={permissions.READ_DOCUMENT}>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      className="text-gray-600 dark:text-gray-300 hover:text-blue-700 dark:hover:text-blue-400"
                      onClick={(e) => {
                        e.stopPropagation();
                        onViewDocument(doc.id);
                      }}
                    >
                      <Eye className="h-4 w-4 mr-1" />
                      {t('common.view')}
                    </Button>
                  </RoleBasedAccess>

                  {doc.fileName && (
                    <RoleBasedAccess permission={permissions.READ_DOCUMENT}>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-gray-600 dark:text-gray-300 hover:text-green-700 dark:hover:text-green-400 ml-2"
                        onClick={(e) => {
                          e.stopPropagation();
                          // Handle download
                        }}
                      >
                        <Download className="h-4 w-4" />
                      </Button>
                    </RoleBasedAccess>
                  )}
                  
                  <RoleBasedAccess permission={permissions.UPDATE_DOCUMENT}>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-gray-600 dark:text-gray-300 hover:text-gray-800 dark:hover:text-gray-100 ml-2"
                      onClick={(e) => {
                        e.stopPropagation();
                        // Handle additional actions menu
                      }}
                    >
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </RoleBasedAccess>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};