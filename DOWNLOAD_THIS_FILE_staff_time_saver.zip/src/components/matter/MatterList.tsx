import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useQuery } from '@tanstack/react-query';
import { Search, FileText, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { matterService } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface MatterListProps {
  onViewMatter: (id: number) => void;
  onNewMatter: () => void;
  clientId?: number; // Optional: to filter matters by client
}

export function MatterList({ onViewMatter, onNewMatter, clientId }: MatterListProps) {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');

  // Fetch all matters or matters for a specific client
  const { data: matters = [], isLoading } = useQuery({
    queryKey: clientId ? ['/api/matters', 'client', clientId] : ['/api/matters'],
    queryFn: async () => {
      try {
        if (clientId) {
          return await matterService.getMattersByClientId(clientId);
        } else {
          return await matterService.getMatters();
        }
      } catch (error) {
        console.error('Error fetching matters:', error);
        return [];
      }
    },
  });

  // Filter matters based on search query
  const filteredMatters = matters.filter((matter) => {
    return (
      matter.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      matter.type.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (matter.description?.toLowerCase().includes(searchQuery.toLowerCase()) ?? false)
    );
  });

  // Function to format a date
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  // Get badge color based on matter type
  const getMatterTypeBadge = (type: string) => {
    switch (type.toLowerCase()) {
      case 'litigation':
        return 'destructive';
      case 'contract':
        return 'secondary';
      case 'corporate':
        return 'default';
      case 'intellectual property':
        return 'default';
      case 'real estate':
        return 'secondary';
      default:
        return 'outline';
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div className="relative w-full max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 dark:text-gray-400" size={18} />
          <Input
            placeholder={t('matters.search')}
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Button onClick={onNewMatter}>
          {t('matters.createNew')}
        </Button>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, index) => (
            <Card key={index} className="animate-pulse">
              <CardHeader className="bg-gray-100 dark:bg-gray-800 h-24" />
              <CardContent className="py-4">
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4 mb-2" />
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/2" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <>
          {filteredMatters.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredMatters.map((matter) => (
                <Card 
                  key={matter.id} 
                  className="overflow-hidden hover:shadow-md transition-shadow cursor-pointer"
                  onClick={() => onViewMatter(matter.id)}
                >
                  <CardHeader className="pb-2">
                    <div className="flex items-center gap-4">
                      <div className="bg-blue-100 dark:bg-blue-900 p-3 rounded-full">
                        <FileText className="h-6 w-6 text-blue-600 dark:text-blue-300" />
                      </div>
                      <div>
                        <CardTitle className="text-xl">{matter.title}</CardTitle>
                        <CardDescription>
                          <Badge variant={getMatterTypeBadge(matter.type)}>
                            {matter.type}
                          </Badge>
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {matter.description && (
                      <p className="text-sm text-gray-600 dark:text-gray-400 line-clamp-2 mb-3">
                        {matter.description}
                      </p>
                    )}
                    <div className="mt-2 pt-2 border-t border-gray-100 dark:border-gray-800">
                      <div className="flex justify-between text-sm text-gray-500 dark:text-gray-400">
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 mr-1" />
                          <span>{formatDate(matter.createdAt)}</span>
                        </div>
                        {matter.client && (
                          <span>
                            {matter.client.firstName} {matter.client.lastName}
                          </span>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <div className="bg-gray-100 dark:bg-gray-800 rounded-full p-4 inline-flex mb-4">
                <FileText className="h-8 w-8 text-gray-500 dark:text-gray-400" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
                {t('matters.noMattersTitle')}
              </h3>
              <p className="text-gray-500 dark:text-gray-400 max-w-md mx-auto mb-6">
                {t('matters.noMattersDescription')}
              </p>
              <Button onClick={onNewMatter}>
                {t('matters.createMatter')}
              </Button>
            </div>
          )}
        </>
      )}
    </div>
  );
}