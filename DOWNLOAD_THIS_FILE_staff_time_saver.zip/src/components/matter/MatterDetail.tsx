import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { 
  ArrowLeft, 
  Edit, 
  Trash2, 
  FileText, 
  Calendar, 
  User, 
  Tag, 
  Clock, 
  CalendarClock, 
  AlertCircle 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { matterService } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface MatterDetailProps {
  matterId: number;
  onBack: () => void;
  onEdit: (id: number) => void;
}

export function MatterDetail({ matterId, onBack, onEdit }: MatterDetailProps) {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('overview');

  // Fetch matter details
  const { 
    data: matter,
    isLoading,
    error
  } = useQuery({
    queryKey: ['/api/matters', matterId],
    queryFn: async () => {
      try {
        return await matterService.getMatterById(matterId);
      } catch (error) {
        toast({
          title: t('matters.fetchDetailError'),
          description: error instanceof Error ? error.message : String(error),
          variant: 'destructive',
        });
        return null;
      }
    },
  });

  // Format dates
  const formatDate = (dateString: string | null) => {
    if (!dateString) return t('common.notSet');
    return new Date(dateString).toLocaleDateString(undefined, { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  // Badge variant based on matter type
  const getMatterTypeBadge = (type: string) => {
    switch (type.toLowerCase()) {
      case 'litigation':
        return 'destructive';
      case 'contract':
        return 'secondary';
      case 'corporate':
        return 'default';
      case 'intellectual property':
        return 'default';
      case 'real estate':
        return 'secondary';
      default:
        return 'outline';
    }
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="flex items-center space-x-4">
          <Button variant="outline" size="sm" onClick={onBack}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            {t('common.back')}
          </Button>
          <Skeleton className="h-8 w-36" />
        </div>
        <Card>
          <CardHeader className="pb-4">
            <Skeleton className="h-8 w-3/4 mb-2" />
            <Skeleton className="h-4 w-1/2" />
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Skeleton className="h-24 w-full" />
              <Skeleton className="h-24 w-full" />
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Error state
  if (error || !matter) {
    return (
      <div className="space-y-4">
        <Button variant="outline" size="sm" onClick={onBack}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          {t('common.back')}
        </Button>
        <Card className="bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800">
          <CardHeader>
            <CardTitle className="text-red-600 dark:text-red-400">
              {t('matters.errorTitle')}
            </CardTitle>
            <CardDescription>
              {error instanceof Error ? error.message : t('matters.fetchDetailError')}
            </CardDescription>
          </CardHeader>
          <CardFooter>
            <Button onClick={onBack} variant="outline">{t('common.goBack')}</Button>
          </CardFooter>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Button variant="outline" size="sm" onClick={onBack}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          {t('common.back')}
        </Button>
        <div className="flex items-center space-x-2">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => onEdit(matterId)}
          >
            <Edit className="mr-2 h-4 w-4" />
            {t('common.edit')}
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            className="text-red-500 border-red-200 hover:bg-red-50 hover:text-red-600 dark:text-red-400 dark:border-red-800 dark:hover:bg-red-900/20 dark:hover:text-red-300"
          >
            <Trash2 className="mr-2 h-4 w-4" />
            {t('common.delete')}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main matter info */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-2">
            <div className="flex items-center space-x-4">
              <div className="bg-blue-100 dark:bg-blue-900 p-4 rounded-full">
                <FileText className="h-6 w-6 text-blue-600 dark:text-blue-300" />
              </div>
              <div>
                <CardTitle className="text-2xl">{matter.title}</CardTitle>
                <CardDescription className="flex items-center mt-1">
                  <Badge variant={getMatterTypeBadge(matter.type)}>
                    {matter.type}
                  </Badge>
                  {matter.status && (
                    <span className="ml-2 text-sm text-gray-500">{matter.status}</span>
                  )}
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="mt-6">
              <TabsList className="mb-4">
                <TabsTrigger value="overview">{t('matters.overview')}</TabsTrigger>
                <TabsTrigger value="documents">{t('matters.documents')}</TabsTrigger>
                <TabsTrigger value="timeline">{t('matters.timeline')}</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-6">
                {matter.description && (
                  <div>
                    <h3 className="text-lg font-medium mb-2">{t('matters.description')}</h3>
                    <p className="text-gray-700 dark:text-gray-300 whitespace-pre-line">
                      {matter.description}
                    </p>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4 mt-6">
                  <div className="flex items-start space-x-3">
                    <Calendar className="h-5 w-5 text-gray-500 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-gray-500">{t('matters.createdAt')}</p>
                      <p className="text-base">{formatDate(matter.createdAt)}</p>
                    </div>
                  </div>

                  {matter.dueDate && (
                    <div className="flex items-start space-x-3">
                      <CalendarClock className="h-5 w-5 text-gray-500 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-gray-500">{t('matters.dueDate')}</p>
                        <p className="text-base">{formatDate(matter.dueDate)}</p>
                      </div>
                    </div>
                  )}

                  {matter.startDate && (
                    <div className="flex items-start space-x-3">
                      <Clock className="h-5 w-5 text-gray-500 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-gray-500">{t('matters.startDate')}</p>
                        <p className="text-base">{formatDate(matter.startDate)}</p>
                      </div>
                    </div>
                  )}

                  {matter.priority && (
                    <div className="flex items-start space-x-3">
                      <AlertCircle className="h-5 w-5 text-gray-500 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-gray-500">{t('matters.priority')}</p>
                        <p className="text-base capitalize">{matter.priority}</p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Client information */}
                {matter.client && (
                  <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
                    <h3 className="font-medium mb-3">{t('matters.client')}</h3>
                    <div className="flex items-start space-x-3">
                      <div className="bg-blue-50 dark:bg-blue-900/30 p-2 rounded-full">
                        <User className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                      </div>
                      <div>
                        <p className="font-medium">
                          {matter.client.firstName} {matter.client.lastName}
                        </p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          {matter.client.email}
                        </p>
                        {matter.client.company && (
                          <p className="text-sm text-gray-500 dark:text-gray-500 mt-1">
                            {matter.client.company}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {/* Assigned Attorney information */}
                {matter.assigned_attorney && (
                  <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
                    <h3 className="font-medium mb-3">{t('matters.assignedAttorney')}</h3>
                    <div className="flex items-start space-x-3">
                      <div className="bg-green-50 dark:bg-green-900/30 p-2 rounded-full">
                        <User className="h-5 w-5 text-green-600 dark:text-green-400" />
                      </div>
                      <div>
                        <p className="font-medium">
                          {matter.assigned_attorney.firstName} {matter.assigned_attorney.lastName}
                        </p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          {matter.assigned_attorney.email}
                        </p>
                        <p className="text-xs text-gray-500 dark:text-gray-500 mt-1 capitalize">
                          {matter.assigned_attorney.role}
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Tags/Categories */}
                {matter.tags && matter.tags.length > 0 && (
                  <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
                    <div className="flex items-center mb-3">
                      <Tag className="h-4 w-4 mr-2 text-gray-500" />
                      <h3 className="font-medium">{t('matters.tags')}</h3>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {matter.tags.map((tag, index) => (
                        <Badge key={index} variant="outline">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="documents">
                {matter.documents && matter.documents.length > 0 ? (
                  <div className="space-y-4">
                    {matter.documents.map((doc) => (
                      <Card key={doc.id} className="overflow-hidden hover:shadow-sm">
                        <CardHeader className="pb-2">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-3">
                              <FileText className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                              <CardTitle className="text-base font-medium">
                                {doc.title || doc.fileName}
                              </CardTitle>
                            </div>
                            <Button size="sm" variant="ghost">
                              {t('common.view')}
                            </Button>
                          </div>
                        </CardHeader>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="py-8 text-center text-gray-500 dark:text-gray-400 border border-dashed border-gray-300 dark:border-gray-700 rounded-md">
                    <p>{t('matters.noDocuments')}</p>
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="mt-2"
                    >
                      {t('matters.uploadDocument')}
                    </Button>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="timeline">
                <div className="py-8 text-center text-gray-500 dark:text-gray-400 border border-dashed border-gray-300 dark:border-gray-700 rounded-md">
                  <p>{t('matters.noTimeline')}</p>
                  <p className="text-sm mt-1">{t('matters.timelineDescription')}</p>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Status and Activity */}
        <Card>
          <CardHeader>
            <CardTitle>{t('matters.status')}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-medium mb-2">{t('matters.currentStatus')}</h3>
                <div className="flex items-center space-x-2">
                  <div className={`w-3 h-3 rounded-full ${
                    matter.status === 'active' ? 'bg-green-500' : 
                    matter.status === 'pending' ? 'bg-yellow-500' : 
                    matter.status === 'closed' ? 'bg-gray-500' : 
                    'bg-blue-500'
                  }`} />
                  <span className="capitalize">{matter.status || t('matters.active')}</span>
                </div>
              </div>

              <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
                <h3 className="text-sm font-medium mb-2">{t('matters.activity')}</h3>
                <div className="space-y-3">
                  <div className="flex items-start space-x-3">
                    <div className="bg-blue-100 dark:bg-blue-900/40 rounded-full p-1.5 mt-0.5">
                      <FileText className="h-3 w-3 text-blue-600 dark:text-blue-300" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">
                        {t('matters.matterCreated')}
                      </p>
                      <p className="text-xs text-gray-500">{formatDate(matter.createdAt)}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-center border-t border-gray-200 dark:border-gray-700 pt-4">
            <Button variant="outline" size="sm" className="w-full">
              {t('matters.addActivity')}
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}