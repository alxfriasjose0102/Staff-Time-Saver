import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useTranslation } from 'react-i18next';
import { useQuery } from '@tanstack/react-query';
import { format } from 'date-fns';
import { Calendar as CalendarIcon } from 'lucide-react';
import { insertMatterSchema, type InsertMatter } from '../../../shared/schema';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { queryClient } from '@/lib/queryClient';
import { matterService, supabase } from '@/lib/supabase';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { useLocation } from 'wouter';

interface MatterFormProps {
  clientId?: number; // Optional: pre-select a client when adding a matter from client detail page
}

export function MatterForm({ clientId }: MatterFormProps = {}) {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Fetch clients for the dropdown
  const { data: clients = [] } = useQuery({
    queryKey: ['/api/clients'],
    queryFn: async () => {
      try {
        const { data, error } = await supabase
          .from('clients')
          .select('id, firstName, lastName, company')
          .order('lastName', { ascending: true });
          
        if (error) throw new Error(error.message);
        return data || [];
      } catch (error) {
        console.error('Error fetching clients:', error);
        return [];
      }
    },
  });

  // Fetch attorneys for assignment dropdown
  const { data: attorneys = [] } = useQuery({
    queryKey: ['/api/users/attorneys'],
    queryFn: async () => {
      try {
        const { data, error } = await supabase
          .from('users')
          .select('id, firstName, lastName')
          .eq('role', 'attorney');
          
        if (error) throw new Error(error.message);
        return data || [];
      } catch (error) {
        console.error('Error fetching attorneys:', error);
        return [];
      }
    },
  });

  // Matter types
  const matterTypes = [
    'Litigation',
    'Contract',
    'Corporate',
    'Real Estate',
    'Intellectual Property',
    'Employment',
    'Family',
    'Criminal',
    'Bankruptcy',
    'Environmental',
    'Immigration',
    'Tax',
    'Other'
  ];
  
  // Priority options
  const priorities = [
    'high',
    'medium',
    'low'
  ];

  // Status options
  const statuses = [
    'active',
    'pending',
    'closed',
    'suspended'
  ];

  // Default values for the form
  const defaultValues: Partial<InsertMatter> = {
    title: '',
    description: '',
    type: '',
    status: 'active',
    priority: 'medium',
    client_id: clientId || undefined,
  };

  // Initialize form with zod validation
  const form = useForm<InsertMatter>({
    resolver: zodResolver(insertMatterSchema),
    defaultValues,
  });

  // Handle form submission
  const onSubmit = async (data: InsertMatter) => {
    setIsSubmitting(true);
    
    try {
      // Format dates for storage
      const formattedData = {
        ...data,
        startDate: data.startDate ? new Date(data.startDate).toISOString() : null,
        dueDate: data.dueDate ? new Date(data.dueDate).toISOString() : null,
      };
      
      // Create matter using the matterService
      const newMatter = await matterService.createMatter(formattedData);
      
      // If an attorney was assigned, update the matter
      if (data.assigned_attorney_id) {
        await supabase
          .from('matters')
          .update({ assigned_attorney_id: data.assigned_attorney_id })
          .eq('id', newMatter.id);
      }
      
      // Invalidate matters query to refresh the list
      queryClient.invalidateQueries({ queryKey: ['/api/matters'] });
      if (data.client_id) {
        queryClient.invalidateQueries({ queryKey: ['/api/matters', 'client', data.client_id] });
      }
      
      toast({
        title: t('matters.createSuccess'),
        description: t('matters.createSuccessDescription'),
      });
      
      // Navigate back to matters list
      setLocation('/matters');
    } catch (error) {
      console.error('Error creating matter:', error);
      toast({
        title: t('matters.createError'),
        description: error instanceof Error ? error.message : String(error),
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle>{t('matters.newMatter')}</CardTitle>
        <CardDescription>{t('matters.newMatterDescription')}</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Title */}
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem className="col-span-full">
                    <FormLabel>{t('matters.title')}</FormLabel>
                    <FormControl>
                      <Input placeholder={t('matters.titlePlaceholder')} {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Client selection */}
              <FormField
                control={form.control}
                name="client_id"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t('matters.client')}</FormLabel>
                    <Select 
                      value={field.value?.toString() || ''} 
                      onValueChange={(value) => field.onChange(Number(value))}
                      disabled={!!clientId} // Disable if client is pre-selected
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder={t('matters.selectClient')} />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {clients.map((client) => (
                          <SelectItem key={client.id} value={client.id.toString()}>
                            {client.firstName} {client.lastName} {client.company ? `(${client.company})` : ''}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Matter Type */}
              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t('matters.type')}</FormLabel>
                    <Select 
                      value={field.value} 
                      onValueChange={field.onChange}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder={t('matters.selectType')} />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {matterTypes.map((type) => (
                          <SelectItem key={type} value={type}>
                            {type}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Status */}
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t('matters.status')}</FormLabel>
                    <Select 
                      value={field.value || 'active'} 
                      onValueChange={field.onChange}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder={t('matters.selectStatus')} />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {statuses.map((status) => (
                          <SelectItem key={status} value={status}>
                            {t(`matters.status_${status}`)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Priority */}
              <FormField
                control={form.control}
                name="priority"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t('matters.priority')}</FormLabel>
                    <Select 
                      value={field.value || 'medium'} 
                      onValueChange={field.onChange}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder={t('matters.selectPriority')} />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {priorities.map((priority) => (
                          <SelectItem key={priority} value={priority}>
                            {t(`matters.priority_${priority}`)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Assigned Attorney */}
              <FormField
                control={form.control}
                name="assigned_attorney_id"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t('matters.assignedAttorney')}</FormLabel>
                    <Select 
                      value={field.value?.toString() || ''} 
                      onValueChange={(value) => field.onChange(value ? Number(value) : undefined)}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder={t('matters.selectAttorney')} />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="">
                          {t('matters.noAttorney')}
                        </SelectItem>
                        {attorneys.map((attorney) => (
                          <SelectItem key={attorney.id} value={attorney.id.toString()}>
                            {attorney.firstName} {attorney.lastName}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Start Date */}
              <FormField
                control={form.control}
                name="startDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>{t('matters.startDate')}</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant={"outline"}
                            className={cn(
                              "w-full pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(new Date(field.value), "PPP")
                            ) : (
                              <span>{t('matters.selectDate')}</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value ? new Date(field.value) : undefined}
                          onSelect={field.onChange}
                          disabled={(date) => date < new Date("1900-01-01")}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Due Date */}
              <FormField
                control={form.control}
                name="dueDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>{t('matters.dueDate')}</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant={"outline"}
                            className={cn(
                              "w-full pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(new Date(field.value), "PPP")
                            ) : (
                              <span>{t('matters.selectDate')}</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value ? new Date(field.value) : undefined}
                          onSelect={field.onChange}
                          disabled={(date) => date < new Date("1900-01-01")}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Description */}
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem className="col-span-full">
                    <FormLabel>{t('matters.description')}</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder={t('matters.descriptionPlaceholder')}
                        className="min-h-32"
                        {...field}
                        value={field.value || ''}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="flex justify-end space-x-4">
              <Button 
                variant="outline" 
                type="button"
                onClick={() => setLocation('/matters')}
              >
                {t('common.cancel')}
              </Button>
              <Button 
                type="submit" 
                disabled={isSubmitting}
              >
                {isSubmitting ? t('common.saving') : t('common.save')}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}