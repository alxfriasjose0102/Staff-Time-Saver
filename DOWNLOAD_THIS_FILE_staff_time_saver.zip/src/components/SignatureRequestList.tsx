import { useState } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { format, isAfter } from 'date-fns';
import { Clock, FileCheck, FileWarning, Send, RefreshCw } from 'lucide-react';
import { apiRequest, queryClient } from '../lib/queryClient';
import { useToast } from '../hooks/use-toast';

// UI components we do have
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Skeleton } from './ui/skeleton';

interface SignatureRequest {
  id: string;
  documentId: number;
  document: {
    id: number;
    title: string;
  };
  recipient: {
    email: string;
  };
  status: 'Pending' | 'Completed' | 'Expired' | 'Canceled';
  expiresAt: string;
  createdAt: string;
  signedAt?: string;
  signatureUrl?: string;
}

interface SignatureRequestListProps {
  onViewSignatureRequest?: (id: string) => void;
  onNewSignatureRequest?: () => void;
}

export const SignatureRequestList: React.FC<SignatureRequestListProps> = ({
  onViewSignatureRequest,
  onNewSignatureRequest,
}) => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [selectedRequest, setSelectedRequest] = useState<string | null>(null);
  const [cancelConfirmOpen, setCancelConfirmOpen] = useState(false);

  // Fetch signature requests
  const {
    data: signatureRequests,
    isLoading,
    error,
  } = useQuery<SignatureRequest[]>({
    queryKey: ['/api/signature-requests'],
    staleTime: 60 * 1000, // 1 minute
  });

  // Cancel signature request mutation
  const cancelMutation = useMutation({
    mutationFn: async (requestId: string) => {
      const res = await apiRequest('PATCH', `/api/signature-requests/${requestId}/cancel`);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: t('signatures.cancelSuccess'),
        description: t('signatures.cancelSuccessDescription'),
      });
      setCancelConfirmOpen(false);
      queryClient.invalidateQueries({ queryKey: ['/api/signature-requests'] });
    },
    onError: (error: Error) => {
      toast({
        title: t('signatures.cancelError'),
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  // Resend signature request mutation
  const resendMutation = useMutation({
    mutationFn: async (requestId: string) => {
      const res = await apiRequest('POST', `/api/signature-requests/${requestId}/resend`);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: t('signatures.resendSuccess'),
        description: t('signatures.resendSuccessDescription'),
      });
      queryClient.invalidateQueries({ queryKey: ['/api/signature-requests'] });
    },
    onError: (error: Error) => {
      toast({
        title: t('signatures.resendError'),
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  // Handle cancel request
  const handleCancelRequest = (requestId: string) => {
    setSelectedRequest(requestId);
    setCancelConfirmOpen(true);
  };

  // Handle resend request
  const handleResendRequest = (requestId: string) => {
    resendMutation.mutate(requestId);
  };

  // Confirm cancel
  const confirmCancel = () => {
    if (selectedRequest) {
      cancelMutation.mutate(selectedRequest);
    }
  };

  // Format and check if a signature request is about to expire (less than 48 hours)
  const isAboutToExpire = (expiresAt: string) => {
    const expiryDate = new Date(expiresAt);
    const now = new Date();
    const hoursLeft = Math.ceil((expiryDate.getTime() - now.getTime()) / (1000 * 60 * 60));
    return hoursLeft > 0 && hoursLeft < 48;
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="w-full border rounded-lg shadow-sm">
        <div className="p-4 border-b">
          <h3 className="text-lg font-semibold">{t('signatures.title')}</h3>
          <p className="text-sm text-gray-500">{t('signatures.description')}</p>
        </div>
        <div className="p-4">
          <div className="space-y-4">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-24 w-full" />
            <Skeleton className="h-24 w-full" />
            <Skeleton className="h-24 w-full" />
          </div>
        </div>
      </div>
    );
  }

  // Error state
  if (error) {
    return (
      <div className="w-full border rounded-lg shadow-sm">
        <div className="p-4 border-b">
          <h3 className="text-lg font-semibold">{t('signatures.title')}</h3>
          <p className="text-sm text-gray-500">{t('signatures.description')}</p>
        </div>
        <div className="p-4">
          <div className="p-4 text-center">
            <FileWarning className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">{t('errors.loadingFailed')}</h3>
            <p className="text-gray-500 mb-4">{t('errors.tryAgain')}</p>
            <Button 
              variant="outline" 
              onClick={() => queryClient.invalidateQueries({ queryKey: ['/api/signature-requests'] })}
            >
              {t('actions.retry')}
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const renderStatusBadge = (status: string) => {
    switch (status) {
      case 'Pending':
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">{t('signatures.statusPending')}</Badge>;
      case 'Completed':
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">{t('signatures.statusCompleted')}</Badge>;
      case 'Expired':
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">{t('signatures.statusExpired')}</Badge>;
      case 'Canceled':
        return <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">{t('signatures.statusCanceled')}</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="w-full border rounded-lg shadow-sm">
      <div className="p-4 border-b flex flex-row items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">{t('signatures.title')}</h3>
          <p className="text-sm text-gray-500">{t('signatures.description')}</p>
        </div>
        {onNewSignatureRequest && (
          <Button onClick={onNewSignatureRequest}>
            <Send className="mr-2 h-4 w-4" />
            {t('signatures.requestNew')}
          </Button>
        )}
      </div>
      <div className="p-4">
        {signatureRequests && signatureRequests.length > 0 ? (
          <div className="space-y-4">
            {signatureRequests.map((request) => (
              <div key={request.id} className="border rounded p-3 hover:bg-gray-50 flex flex-col md:flex-row justify-between">
                <div className="space-y-2">
                  <div className="font-medium">{request.document.title}</div>
                  <div className="text-sm">{request.recipient.email}</div>
                  <div>{renderStatusBadge(request.status)}</div>
                  <div className="text-sm">
                    {request.status === 'Pending' ? (
                      <div className="flex items-center">
                        {isAboutToExpire(request.expiresAt) && (
                          <Clock className="h-4 w-4 text-yellow-600 mr-1" />
                        )}
                        <span
                          className={
                            isAboutToExpire(request.expiresAt)
                              ? 'text-yellow-600'
                              : isAfter(new Date(request.expiresAt), new Date())
                              ? ''
                              : 'text-red-600'
                          }
                        >
                          {format(new Date(request.expiresAt), 'MMM d, yyyy')}
                        </span>
                      </div>
                    ) : request.status === 'Completed' ? (
                      <div className="flex items-center">
                        <FileCheck className="h-4 w-4 text-green-600 mr-1" />
                        <span>
                          {request.signedAt 
                            ? format(new Date(request.signedAt), 'MMM d, yyyy') 
                            : t('signatures.signed')}
                        </span>
                      </div>
                    ) : (
                      <span className="text-gray-500">-</span>
                    )}
                  </div>
                </div>
                <div className="mt-3 md:mt-0 flex items-center space-x-2">
                  {request.status === 'Pending' ? (
                    <>
                      {onViewSignatureRequest && (
                        <Button variant="outline" size="sm" onClick={() => onViewSignatureRequest(request.id)}>
                          {t('actions.view')}
                        </Button>
                      )}
                      <Button variant="outline" size="sm" onClick={() => handleResendRequest(request.id)}>
                        {t('signatures.resend')}
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="text-red-600 hover:bg-red-50"
                        onClick={() => handleCancelRequest(request.id)}
                      >
                        {t('signatures.cancel')}
                      </Button>
                    </>
                  ) : onViewSignatureRequest ? (
                    <Button variant="outline" size="sm" onClick={() => onViewSignatureRequest(request.id)}>
                      {t('actions.view')}
                    </Button>
                  ) : null}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-8 text-center">
            <Send className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">{t('signatures.noRequests')}</h3>
            <p className="text-gray-500 mb-4">{t('signatures.startByRequesting')}</p>
            {onNewSignatureRequest && (
              <Button onClick={onNewSignatureRequest}>
                {t('signatures.requestNew')}
              </Button>
            )}
          </div>
        )}
      </div>
      <div className="flex justify-between border-t p-4">
        <div className="text-xs text-gray-500">
          {signatureRequests?.length 
            ? t('signatures.requestCount', { count: signatureRequests.length }) 
            : t('signatures.noRequestsYet')}
        </div>
        <Button variant="outline" size="sm" onClick={() => queryClient.invalidateQueries({ queryKey: ['/api/signature-requests'] })}>
          <RefreshCw className="h-4 w-4 mr-1" />
          {t('actions.refresh')}
        </Button>
      </div>

      {/* Cancel Confirmation Modal (simplified) */}
      {cancelConfirmOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h3 className="text-lg font-semibold mb-2">{t('signatures.cancelConfirm')}</h3>
            <p className="mb-6 text-gray-500">{t('signatures.cancelWarning')}</p>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setCancelConfirmOpen(false)}>
                {t('actions.cancel')}
              </Button>
              <Button 
                className="bg-red-500 hover:bg-red-600 text-white"
                onClick={confirmCancel}
                disabled={cancelMutation.isPending}
              >
                {cancelMutation.isPending ? t('signatures.canceling') : t('signatures.confirmCancel')}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};