import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useTranslation } from 'react-i18next';
import { useQuery } from '@tanstack/react-query';
import { useState } from 'react';
import { insertClientSchema, type InsertClient } from '../../shared/schema';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { queryClient } from '@/lib/queryClient';
import { clientService, supabase } from '@/lib/supabase';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useLocation } from 'wouter';

export function ClientIntakeForm() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  // Get list of attorneys for assignment dropdown
  const { data: attorneys, isLoading: isLoadingAttorneys } = useQuery({
    queryKey: ['/api/users/attorneys'],
    queryFn: async () => {
      try {
        // Fetch attorneys from Supabase
        const { data, error } = await supabase
          .from('users')
          .select('id, firstName, lastName')
          .eq('role', 'attorney');
          
        if (error) throw new Error(error.message);
        return data || [];
      } catch (error) {
        console.error('Error fetching attorneys:', error);
        return [];
      }
    },
  });

  // Default values for the form
  const defaultValues: Partial<InsertClient> = {
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    company: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    notes: '',
  };

  // Initialize form with zod validation
  const form = useForm<InsertClient>({
    resolver: zodResolver(insertClientSchema),
    defaultValues,
  });

  // Create client mutation - Using direct API calls instead
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedAttorneyId, setSelectedAttorneyId] = useState<number | undefined>(undefined);

  const onSubmit = async (data: InsertClient) => {
    setIsSubmitting(true);
    try {
      // First, create the client using the form data
      const newClient = await clientService.createClient(data);
      
      // Get the attorney ID if one was selected from state
      // We're using a separate state variable to track this outside of the form schema
      
      // If an attorney was selected, update the client record to assign the attorney
      if (selectedAttorneyId && newClient?.id) {
        await supabase
          .from('clients')
          .update({ assigned_attorney_id: selectedAttorneyId })
          .eq('id', newClient.id);
      }
      
      // Invalidate clients query to refresh the list
      queryClient.invalidateQueries({ queryKey: ['/api/clients'] });
      toast({
        title: t('clients.createSuccess'),
        description: t('clients.createSuccessDescription'),
      });
      
      // Navigate to clients list
      setLocation('/clients');
    } catch (error) {
      toast({
        title: t('clients.createError'),
        description: error instanceof Error ? error.message : String(error),
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle>{t('clients.newClient')}</CardTitle>
        <CardDescription>{t('clients.newClientDescription')}</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* First Name */}
              <FormField
                control={form.control}
                name="firstName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t('clients.firstName')}</FormLabel>
                    <FormControl>
                      <Input placeholder={t('clients.firstNamePlaceholder')} {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Last Name */}
              <FormField
                control={form.control}
                name="lastName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t('clients.lastName')}</FormLabel>
                    <FormControl>
                      <Input placeholder={t('clients.lastNamePlaceholder')} {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Email */}
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t('clients.email')}</FormLabel>
                    <FormControl>
                      <Input 
                        type="email" 
                        placeholder={t('clients.emailPlaceholder')} 
                        {...field} 
                        value={field.value || ''}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Phone */}
              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t('clients.phone')}</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder={t('clients.phonePlaceholder')} 
                        {...field} 
                        value={field.value || ''}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Company */}
              <FormField
                control={form.control}
                name="company"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t('clients.company')}</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder={t('clients.companyPlaceholder')} 
                        {...field} 
                        value={field.value || ''}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Assigned Attorney - Using Supabase directly */}
              {attorneys && attorneys.length > 0 && (
                <div className="w-full">
                  <p className="text-sm font-medium mb-2">{t('clients.assignedAttorney')}</p>
                  <select 
                    className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                    onChange={(e) => {
                      // Get the attorney data from the form submission
                      const attorneyId = e.target.value ? Number(e.target.value) : undefined;
                      
                      // When a client is created, we'll handle the attorney assignment separately
                      // through a direct Supabase call in the onSubmit handler
                      setSelectedAttorneyId(attorneyId);
                    }}
                  >
                    <option value="">{t('clients.selectAttorney')}</option>
                    {attorneys.map((attorney) => (
                      <option key={attorney.id} value={attorney.id}>
                        {attorney.firstName} {attorney.lastName}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Address */}
              <FormField
                control={form.control}
                name="address"
                render={({ field }) => (
                  <FormItem className="col-span-full">
                    <FormLabel>{t('clients.address')}</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder={t('clients.addressPlaceholder')} 
                        {...field} 
                        value={field.value || ''}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* City */}
              <FormField
                control={form.control}
                name="city"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t('clients.city')}</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder={t('clients.cityPlaceholder')} 
                        {...field} 
                        value={field.value || ''}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* State */}
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="state"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('clients.state')}</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder={t('clients.statePlaceholder')} 
                          {...field} 
                          value={field.value || ''}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Zip Code */}
                <FormField
                  control={form.control}
                  name="zipCode"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('clients.zipCode')}</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder={t('clients.zipCodePlaceholder')} 
                          {...field} 
                          value={field.value || ''}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Notes */}
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem className="col-span-full">
                    <FormLabel>{t('clients.notes')}</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder={t('clients.notesPlaceholder')}
                        className="min-h-32"
                        {...field}
                        value={field.value || ''}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="flex justify-end space-x-4">
              <Button 
                variant="outline" 
                type="button"
                onClick={() => setLocation('/clients')}
              >
                {t('common.cancel')}
              </Button>
              <Button 
                type="submit" 
                disabled={isSubmitting}
              >
                {isSubmitting ? t('common.saving') : t('common.save')}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}