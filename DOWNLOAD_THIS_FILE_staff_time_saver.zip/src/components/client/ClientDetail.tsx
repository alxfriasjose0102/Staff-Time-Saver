import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { ArrowLeft, Edit, Trash2, User, Mail, Phone, Building, MapPin, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { clientService } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface ClientDetailProps {
  clientId: number;
  onBack: () => void;
  onEdit: (id: number) => void;
}

export function ClientDetail({ clientId, onBack, onEdit }: ClientDetailProps) {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('overview');

  // Fetch client details
  const { 
    data: client,
    isLoading,
    error
  } = useQuery({
    queryKey: ['/api/clients', clientId],
    queryFn: async () => {
      try {
        return await clientService.getClientById(clientId);
      } catch (error) {
        toast({
          title: t('clients.fetchDetailError'),
          description: error instanceof Error ? error.message : String(error),
          variant: 'destructive',
        });
        return null;
      }
    },
  });

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="flex items-center space-x-4">
          <Button variant="outline" size="sm" onClick={onBack}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            {t('common.back')}
          </Button>
          <Skeleton className="h-8 w-36" />
        </div>
        <Card>
          <CardHeader className="pb-4">
            <Skeleton className="h-8 w-3/4 mb-2" />
            <Skeleton className="h-4 w-1/2" />
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Skeleton className="h-24 w-full" />
              <Skeleton className="h-24 w-full" />
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (error || !client) {
    return (
      <div className="space-y-4">
        <Button variant="outline" size="sm" onClick={onBack}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          {t('common.back')}
        </Button>
        <Card className="bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800">
          <CardHeader>
            <CardTitle className="text-red-600 dark:text-red-400">
              {t('clients.errorTitle')}
            </CardTitle>
            <CardDescription>
              {error instanceof Error ? error.message : t('clients.fetchDetailError')}
            </CardDescription>
          </CardHeader>
          <CardFooter>
            <Button onClick={onBack} variant="outline">{t('common.goBack')}</Button>
          </CardFooter>
        </Card>
      </div>
    );
  }

  // Format the client name
  const clientName = `${client.firstName} ${client.lastName}`;
  const formattedDate = new Date(client.createdAt).toLocaleDateString(undefined, { 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Button variant="outline" size="sm" onClick={onBack}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          {t('common.back')}
        </Button>
        <div className="flex items-center space-x-2">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => onEdit(clientId)}
          >
            <Edit className="mr-2 h-4 w-4" />
            {t('common.edit')}
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            className="text-red-500 border-red-200 hover:bg-red-50 hover:text-red-600 dark:text-red-400 dark:border-red-800 dark:hover:bg-red-900/20 dark:hover:text-red-300"
          >
            <Trash2 className="mr-2 h-4 w-4" />
            {t('common.delete')}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main client info */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-2">
            <div className="flex items-center space-x-4">
              <div className="bg-blue-100 dark:bg-blue-900 p-4 rounded-full">
                <User className="h-6 w-6 text-blue-600 dark:text-blue-300" />
              </div>
              <div>
                <CardTitle className="text-2xl">{clientName}</CardTitle>
                <CardDescription>
                  {client.company || t('clients.noCompany')}
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="mt-6">
              <TabsList className="mb-4">
                <TabsTrigger value="overview">{t('clients.overview')}</TabsTrigger>
                <TabsTrigger value="matters">{t('clients.matters')}</TabsTrigger>
                <TabsTrigger value="documents">{t('clients.documents')}</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
                  <div className="flex items-start space-x-3">
                    <Mail className="h-5 w-5 text-gray-500 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-gray-500">{t('clients.email')}</p>
                      <p className="text-base">{client.email}</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <Phone className="h-5 w-5 text-gray-500 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-gray-500">{t('clients.phone')}</p>
                      <p className="text-base">{client.phone || t('clients.noPhone')}</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <Building className="h-5 w-5 text-gray-500 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-gray-500">{t('clients.company')}</p>
                      <p className="text-base">{client.company || t('clients.noCompany')}</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <Calendar className="h-5 w-5 text-gray-500 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-gray-500">{t('clients.clientSince')}</p>
                      <p className="text-base">{formattedDate}</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3 col-span-2">
                    <MapPin className="h-5 w-5 text-gray-500 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-gray-500">{t('clients.address')}</p>
                      <p className="text-base">
                        {client.address ? (
                          <>
                            {client.address}<br />
                            {client.city && `${client.city}, `}
                            {client.state && `${client.state} `}
                            {client.zipCode && client.zipCode}
                          </>
                        ) : (
                          t('clients.noAddress')
                        )}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Assigned Attorney information */}
                {client.assigned_attorney && (
                  <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700 mb-4">
                    <h3 className="font-medium mb-3">{t('clients.assignedAttorney')}</h3>
                    <div className="flex items-start space-x-3">
                      <div className="bg-blue-50 dark:bg-blue-900/30 p-2 rounded-full">
                        <User className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                      </div>
                      <div>
                        <p className="font-medium">
                          {client.assigned_attorney.firstName} {client.assigned_attorney.lastName}
                        </p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          {client.assigned_attorney.email}
                        </p>
                        <p className="text-xs text-gray-500 dark:text-gray-500 mt-1 capitalize">
                          {client.assigned_attorney.role}
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {client.notes && (
                  <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
                    <h3 className="font-medium mb-2">{t('clients.notes')}</h3>
                    <p className="text-gray-700 dark:text-gray-300 whitespace-pre-line">
                      {client.notes}
                    </p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="matters">
                <div className="py-8 text-center text-gray-500 dark:text-gray-400 border border-dashed border-gray-300 dark:border-gray-700 rounded-md">
                  <p>{t('clients.noMatters')}</p>
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="mt-2"
                  >
                    {t('clients.createMatter')}
                  </Button>
                </div>
              </TabsContent>

              <TabsContent value="documents">
                <div className="py-8 text-center text-gray-500 dark:text-gray-400 border border-dashed border-gray-300 dark:border-gray-700 rounded-md">
                  <p>{t('clients.noDocuments')}</p>
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="mt-2"
                  >
                    {t('clients.uploadDocument')}
                  </Button>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Timeline/Activity */}
        <Card>
          <CardHeader>
            <CardTitle>{t('clients.activity')}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <div className="bg-blue-100 dark:bg-blue-900/40 rounded-full p-1.5 mt-0.5">
                  <User className="h-3 w-3 text-blue-600 dark:text-blue-300" />
                </div>
                <div>
                  <p className="text-sm font-medium">
                    {t('clients.clientCreated')}
                  </p>
                  <p className="text-xs text-gray-500">{formattedDate}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}