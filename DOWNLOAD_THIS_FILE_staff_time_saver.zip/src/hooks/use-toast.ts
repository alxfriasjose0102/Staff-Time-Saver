import { toast, ToastProps } from "../components/ui/toast";

export { ToastProps };

export const useToast = () => {
  return {
    toast,
  };
};