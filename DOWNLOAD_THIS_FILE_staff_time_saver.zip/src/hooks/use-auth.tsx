import { createContext, ReactNode, useContext, useEffect, useState, useCallback } from "react";
import {
  useQuery,
  useMutation,
  UseMutationResult,
} from "@tanstack/react-query";
import { useTranslation } from "react-i18next";
import { UserRoleType } from "../../shared/schema";
import { queryClient } from "../lib/queryClient";
import { useToast } from "./use-toast";
import {
  loginWithEmail,
  signUpWithEmail,
  logout,
  getCurrentUser,
  AuthUserMetadata,
  onAuthStateChange
} from "../lib/supabaseClient";
import type { User as SupabaseUser } from "@supabase/supabase-js";

// Define the app User type based on our schema
interface SchemaUser {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: UserRoleType;
  avatarUrl?: string;
  createdAt?: string;
  updatedAt?: string;
}

type AuthContextType = {
  user: SchemaUser | null;
  isLoading: boolean;
  error: Error | null;
  loginMutation: UseMutationResult<SchemaUser, Error, LoginData>;
  logoutMutation: UseMutationResult<void, Error, void>;
  registerMutation: UseMutationResult<SchemaUser, Error, RegisterData>;
  refreshAuth: () => Promise<void>;
};

type LoginData = {
  email: string;
  password: string;
};

type RegisterData = {
  email: string;
  password: string;
  confirmPassword: string;
  firstName: string;
  lastName: string;
  role: UserRoleType;
};

/**
 * Convert a Supabase user to our application User format
 */
function supabaseUserToAppUser(user: SupabaseUser | null): SchemaUser | null {
  if (!user) return null;

  // Extract user metadata from the Supabase user
  const metadata = user.user_metadata || {};
  const defaultRole: UserRoleType = "staff";
  
  // Ensure the role is valid according to our schema
  let role: UserRoleType = defaultRole;
  if (metadata.role && ["admin", "attorney", "paralegal", "staff"].includes(metadata.role)) {
    role = metadata.role as UserRoleType;
  }

  return {
    id: user.id,
    email: user.email || "",
    firstName: metadata.firstName || "",
    lastName: metadata.lastName || "",
    role,
    avatarUrl: metadata.avatarUrl || "",
    createdAt: user.created_at,
    updatedAt: user.updated_at
  };
}

export const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();
  const { t } = useTranslation();
  const [authInitialized, setAuthInitialized] = useState(false);
  
  // Track loading state for initial auth check
  const {
    data: user,
    error,
    isLoading,
    refetch
  } = useQuery({
    queryKey: ["auth-user"],
    queryFn: async () => {
      try {
        const currentUser = await getCurrentUser();
        return supabaseUserToAppUser(currentUser);
      } catch (e) {
        console.error("Error fetching current user:", e);
        return null;
      }
    },
    enabled: authInitialized,
  });

  // Set up auth state listener
  useEffect(() => {
    const subscription = onAuthStateChange(async (event) => {
      console.log("Auth state changed:", event);
      
      if (event === 'SIGNED_IN' || event === 'USER_UPDATED') {
        // Fetch updated user information
        refetch();
        
        // Show toast for login event
        if (event === 'SIGNED_IN') {
          toast({
            title: t('auth.signedIn') || "Signed in",
            description: t('auth.signedInDesc') || "You have successfully signed in",
          });
        }
      } else if (event === 'SIGNED_OUT') {
        // Clear the user data in the query cache
        queryClient.setQueryData(["auth-user"], null);
        
        toast({
          title: t('auth.signedOut') || "Signed out",
          description: t('auth.signedOutDesc') || "You have been signed out",
        });
      }
    });

    setAuthInitialized(true);

    // Cleanup subscription on unmount
    return () => {
      subscription.unsubscribe();
    };
  }, [toast, refetch]);

  // Function to manually refresh auth state
  const refreshAuth = useCallback(async () => {
    await refetch();
  }, [refetch]);

  // Login mutation
  const loginMutation = useMutation({
    mutationFn: async (credentials: LoginData) => {
      try {
        const response = await loginWithEmail(credentials.email, credentials.password);
        const user = supabaseUserToAppUser(response.data.user);
        
        if (!user) {
          throw new Error(t('auth.failedUserData') || "Failed to get user data after login");
        }
        
        return user;
      } catch (error) {
        console.error("Login error:", error);
        throw error;
      }
    },
    onSuccess: (userData: SchemaUser) => {
      queryClient.setQueryData(["auth-user"], userData);
      
      toast({
        title: t('auth.loginSuccess') || "Login Successful",
        description: t('auth.welcomeBack') || "Welcome back!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: t('auth.loginFailed') || "Login Failed",
        description: error.message || t('auth.loginError') || "An error occurred during login",
        variant: "destructive",
      });
    },
  });

  // Registration mutation
  const registerMutation = useMutation({
    mutationFn: async (userData: RegisterData) => {
      try {
        if (userData.password !== userData.confirmPassword) {
          throw new Error(t('auth.passwordMismatch') || "Passwords do not match");
        }

        // Prepare metadata for Supabase
        const metadata: AuthUserMetadata = {
          firstName: userData.firstName,
          lastName: userData.lastName,
          role: userData.role
        };

        const response = await signUpWithEmail(
          userData.email,
          userData.password,
          metadata
        );

        const user = supabaseUserToAppUser(response.data.user);
        
        if (!user) {
          throw new Error(t('auth.failedRegistrationData') || "Failed to get user data after registration");
        }
        
        return user;
      } catch (error) {
        console.error("Registration error:", error);
        throw error;
      }
    },
    onSuccess: (userData: SchemaUser) => {
      queryClient.setQueryData(["auth-user"], userData);
      
      toast({
        title: t('auth.registrationSuccess') || "Registration Successful",
        description: t('auth.accountCreated') || "Your account has been created successfully!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: t('auth.registrationFailed') || "Registration Failed",
        description: error.message || t('auth.registrationError') || "An error occurred during registration",
        variant: "destructive",
      });
    },
  });

  // Logout mutation
  const logoutMutation = useMutation({
    mutationFn: async () => {
      await logout();
    },
    onSuccess: () => {
      queryClient.setQueryData(["auth-user"], null);
      
      toast({
        title: t('auth.loggedOut') || "Logged Out",
        description: t('auth.logoutSuccess') || "You have been logged out successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: t('auth.logoutFailed') || "Logout Failed",
        description: error.message || t('auth.logoutError') || "An error occurred during logout",
        variant: "destructive",
      });
    },
  });

  return (
    <AuthContext.Provider
      value={{
        user: user ?? null,
        isLoading,
        error,
        loginMutation,
        logoutMutation,
        registerMutation,
        refreshAuth
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}