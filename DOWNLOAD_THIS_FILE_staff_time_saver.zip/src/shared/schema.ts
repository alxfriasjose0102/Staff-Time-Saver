import { createInsertSchema } from 'drizzle-zod';
import { pgTable, serial, text, timestamp, integer, boolean, pgEnum, uuid, varchar } from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';
import { z } from 'zod';

// Define roles enum
export const UserRole = {
  ADMIN: 'admin',
  ATTORNEY: 'attorney',
  PARALEGAL: 'paralegal',
  STAFF: 'staff',
  CLIENT: 'client'
} as const;

export type UserRoleType = typeof UserRole[keyof typeof UserRole];

// Matter type enum
export const matterTypeEnum = pgEnum('matter_type', [
  'Family Law',
  'Estate Planning',
  'Immigration',
  'Corporate',
  'Real Estate',
  'Personal Injury',
  'Criminal Defense',
  'Intellectual Property',
  'Tax',
  'Other'
]);

// Document status enum
export const documentStatusEnum = pgEnum('document_status', [
  'Draft',
  'Pending Review',
  'Pending Signature',
  'Signed',
  'Final',
  'Archived'
]);

// Users table
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  email: text('email').notNull().unique(),
  password: text('password').notNull(),
  firstName: text('first_name'),
  lastName: text('last_name'),
  role: text('role').$type<UserRoleType>().notNull().default(UserRole.STAFF),
  avatarUrl: text('avatar_url'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// User type definitions
export type User = typeof users.$inferSelect;
export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export type InsertUser = z.infer<typeof insertUserSchema>;

// Clients table
export const clients = pgTable('clients', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  firstName: text('first_name').notNull(),
  lastName: text('last_name').notNull(),
  email: text('email').notNull().unique(),
  company: text('company'),
  phone: text('phone'),
  address: text('address'),
  city: text('city'),
  state: text('state'),
  zipCode: text('zip_code'),
  notes: text('notes'),
  isActive: boolean('is_active').default(true).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Client type definitions
export type Client = typeof clients.$inferSelect;
export const insertClientSchema = createInsertSchema(clients).omit({ id: true });
export type InsertClient = z.infer<typeof insertClientSchema>;

// Matters table
export const matters = pgTable('matters', {
  id: serial('id').primaryKey(),
  clientId: integer('client_id').references(() => clients.id).notNull(),
  title: text('title').notNull(),
  description: text('description'),
  type: matterTypeEnum('type').notNull(),
  status: text('status').default('Active').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Matter type definitions
export type Matter = typeof matters.$inferSelect;
export const insertMatterSchema = createInsertSchema(matters).omit({ id: true });
export type InsertMatter = z.infer<typeof insertMatterSchema>;

// Documents table
export const documents = pgTable('documents', {
  id: serial('id').primaryKey(),
  matterId: integer('matter_id').references(() => matters.id),
  clientId: integer('client_id').references(() => clients.id).notNull(),
  title: text('title').notNull(),
  fileName: text('file_name'),
  fileUrl: text('file_url'),
  fileType: text('file_type'),
  fileSize: integer('file_size'),
  status: documentStatusEnum('status').default('Draft').notNull(),
  createdById: integer('created_by_id').references(() => users.id).notNull(),
  needsSignature: boolean('needs_signature').default(false),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Document type definitions
export type Document = typeof documents.$inferSelect;
export const insertDocumentSchema = createInsertSchema(documents).omit({ id: true });
export type InsertDocument = z.infer<typeof insertDocumentSchema>;

// Signature request status enum
export const signatureRequestStatusEnum = pgEnum('signature_request_status', [
  'Pending',
  'Completed',
  'Expired',
  'Canceled'
]);

// Signature requests table
export const signatureRequests = pgTable('signature_requests', {
  id: uuid('id').defaultRandom().primaryKey(),
  documentId: integer('document_id').notNull().references(() => documents.id, { onDelete: 'cascade' }),
  createdById: integer('created_by_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  recipientEmail: varchar('recipient_email', { length: 255 }).notNull(),
  status: signatureRequestStatusEnum('status').notNull().default('Pending'),
  message: text('message'),
  expiresAt: timestamp('expires_at').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
  signedAt: timestamp('signed_at'),
  signatureUrl: text('signature_url'),
  tokenHash: varchar('token_hash', { length: 255 }).notNull().unique(),
});

// Signature request type definitions
export type SignatureRequest = typeof signatureRequests.$inferSelect;
export const insertSignatureRequestSchema = createInsertSchema(signatureRequests).omit({ 
  id: true, 
  status: true, 
  createdAt: true, 
  updatedAt: true, 
  signedAt: true, 
  signatureUrl: true 
});
export type InsertSignatureRequest = z.infer<typeof insertSignatureRequestSchema>;

// Set up relations
export const usersRelations = relations(users, ({ many }) => ({
  clients: many(clients),
  documents: many(documents, { relationName: 'createdBy' }),
  signatureRequests: many(signatureRequests, { relationName: 'signatureRequestsCreatedBy' }),
}));

export const clientsRelations = relations(clients, ({ one, many }) => ({
  user: one(users, {
    fields: [clients.userId],
    references: [users.id],
  }),
  matters: many(matters),
  documents: many(documents),
}));

export const mattersRelations = relations(matters, ({ one, many }) => ({
  client: one(clients, {
    fields: [matters.clientId],
    references: [clients.id],
  }),
  documents: many(documents),
}));

export const documentsRelations = relations(documents, ({ one, many }) => ({
  client: one(clients, {
    fields: [documents.clientId],
    references: [clients.id],
  }),
  matter: one(matters, {
    fields: [documents.matterId],
    references: [matters.id],
  }),
  createdBy: one(users, {
    fields: [documents.createdById],
    references: [users.id],
    relationName: 'createdBy',
  }),
  signatureRequests: many(signatureRequests),
}));

export const signatureRequestsRelations = relations(signatureRequests, ({ one }) => ({
  document: one(documents, {
    fields: [signatureRequests.documentId],
    references: [documents.id],
  }),
  createdBy: one(users, {
    fields: [signatureRequests.createdById],
    references: [users.id],
    relationName: 'signatureRequestsCreatedBy',
  }),
}));

// Permission system
export const permissions = {
  // User management
  CREATE_USER: 'create_user',
  READ_USER: 'read_user',
  UPDATE_USER: 'update_user',
  DELETE_USER: 'delete_user',
  
  // Client management
  CREATE_CLIENT: 'create_client',
  READ_CLIENT: 'read_client',
  UPDATE_CLIENT: 'update_client',
  DELETE_CLIENT: 'delete_client',
  
  // Matter management
  CREATE_MATTER: 'create_matter',
  READ_MATTER: 'read_matter',
  UPDATE_MATTER: 'update_matter',
  DELETE_MATTER: 'delete_matter',
  
  // Document management
  CREATE_DOCUMENT: 'create_document',
  READ_DOCUMENT: 'read_document',
  UPDATE_DOCUMENT: 'update_document',
  DELETE_DOCUMENT: 'delete_document',
  
  // Signature management
  CREATE_SIGNATURE_REQUEST: 'create_signature_request',
  READ_SIGNATURE_REQUEST: 'read_signature_request',
  UPDATE_SIGNATURE_REQUEST: 'update_signature_request',
  DELETE_SIGNATURE_REQUEST: 'delete_signature_request',
  
  // Task management
  CREATE_TASK: 'create_task',
  READ_TASK: 'read_task',
  UPDATE_TASK: 'update_task',
  DELETE_TASK: 'delete_task',
};

// Role-based permissions
export const rolePermissions = {
  [UserRole.ADMIN]: Object.values(permissions),
  [UserRole.ATTORNEY]: [
    permissions.READ_USER,
    permissions.CREATE_CLIENT, permissions.READ_CLIENT, permissions.UPDATE_CLIENT,
    permissions.CREATE_MATTER, permissions.READ_MATTER, permissions.UPDATE_MATTER,
    permissions.CREATE_DOCUMENT, permissions.READ_DOCUMENT, permissions.UPDATE_DOCUMENT,
    permissions.CREATE_SIGNATURE_REQUEST, permissions.READ_SIGNATURE_REQUEST, 
    permissions.UPDATE_SIGNATURE_REQUEST, permissions.DELETE_SIGNATURE_REQUEST,
    permissions.CREATE_TASK, permissions.READ_TASK, permissions.UPDATE_TASK, permissions.DELETE_TASK,
  ],
  [UserRole.PARALEGAL]: [
    permissions.READ_USER,
    permissions.CREATE_CLIENT, permissions.READ_CLIENT, permissions.UPDATE_CLIENT,
    permissions.CREATE_MATTER, permissions.READ_MATTER, permissions.UPDATE_MATTER,
    permissions.CREATE_DOCUMENT, permissions.READ_DOCUMENT, permissions.UPDATE_DOCUMENT,
    permissions.CREATE_SIGNATURE_REQUEST, permissions.READ_SIGNATURE_REQUEST, 
    permissions.UPDATE_SIGNATURE_REQUEST,
    permissions.CREATE_TASK, permissions.READ_TASK, permissions.UPDATE_TASK, permissions.DELETE_TASK,
  ],
  [UserRole.STAFF]: [
    permissions.READ_USER,
    permissions.READ_CLIENT,
    permissions.READ_MATTER,
    permissions.READ_DOCUMENT,
    permissions.READ_SIGNATURE_REQUEST,
    permissions.CREATE_TASK, permissions.READ_TASK, permissions.UPDATE_TASK,
  ],
  [UserRole.CLIENT]: [
    permissions.READ_DOCUMENT,
    permissions.READ_SIGNATURE_REQUEST,
    permissions.READ_TASK,
  ],
};

// Helper function to check if a user has a specific permission
export function hasPermission(userRole: UserRoleType, permission: string): boolean {
  return rolePermissions[userRole]?.includes(permission) || false;
}