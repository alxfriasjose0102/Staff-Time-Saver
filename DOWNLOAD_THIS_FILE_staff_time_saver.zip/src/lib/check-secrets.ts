/**
 * Utility function to check if an environment variable is defined
 * This can be used to conditionally show components that require API keys
 */
export function check(envVarName: string): boolean {
  return Boolean(import.meta.env[envVarName]);
}