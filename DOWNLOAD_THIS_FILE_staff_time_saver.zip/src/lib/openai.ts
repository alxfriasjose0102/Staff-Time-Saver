import OpenAI from 'openai';

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: import.meta.env.OPENAI_API_KEY });

export interface DocumentAnalysisResult {
  summary: string;
  keyPoints: string[];
  legalRisks: {
    risk: string;
    severity: 'low' | 'medium' | 'high';
    suggestion: string;
  }[];
  nextSteps: string[];
  relevantCaseLaw?: string[];
  confidenceScore: number;
}

export interface DocumentMetadata {
  documentType: string;
  parties: string[];
  effectiveDate?: string;
  expirationDate?: string;
  jurisdiction?: string;
  governingLaw?: string;
  keyProvisions: string[];
  [key: string]: any;
}

export interface DocumentComparisonResult {
  similarities: string[];
  differences: string[];
  recommendations: string[];
}

/**
 * Analyzes a legal document and returns structured insights
 */
export async function analyzeLegalDocument(
  documentText: string,
  documentName?: string
): Promise<DocumentAnalysisResult> {
  try {
    const prompt = `
      As a legal expert, analyze the following document${documentName ? ` (${documentName})` : ''}:
      
      ${documentText}
      
      Provide a comprehensive analysis in JSON format with these fields:
      - summary: A concise summary of the document
      - keyPoints: An array of the most important points in the document
      - legalRisks: An array of objects with these fields:
        - risk: Description of the potential legal risk
        - severity: 'low', 'medium', or 'high'
        - suggestion: Recommended action to mitigate this risk
      - nextSteps: An array of recommended next steps
      - relevantCaseLaw: (optional) An array of relevant case law or precedents
      - confidenceScore: A number between 0 and 1 representing confidence in this analysis
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content);

    return {
      summary: result.summary || "No summary provided",
      keyPoints: result.keyPoints || [],
      legalRisks: result.legalRisks || [],
      nextSteps: result.nextSteps || [],
      relevantCaseLaw: result.relevantCaseLaw || [],
      confidenceScore: result.confidenceScore || 0.5,
    };
  } catch (error) {
    console.error("Error analyzing document:", error);
    throw new Error("Failed to analyze document");
  }
}

/**
 * Extracts metadata from a legal document
 */
export async function extractDocumentMetadata(
  documentText: string,
  documentName?: string
): Promise<DocumentMetadata> {
  try {
    const prompt = `
      As a legal expert, extract key metadata from the following document${documentName ? ` (${documentName})` : ''}:
      
      ${documentText}
      
      Provide the metadata in JSON format with these fields:
      - documentType: The type of legal document
      - parties: Array of parties involved in the document
      - effectiveDate: (if applicable) When the document takes effect
      - expirationDate: (if applicable) When the document expires
      - jurisdiction: (if applicable) The jurisdiction governing the document
      - governingLaw: (if applicable) The governing law
      - keyProvisions: Array of key provisions or clauses
      
      Include any additional relevant metadata fields as appropriate.
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content);

    return {
      documentType: result.documentType || "Unknown",
      parties: result.parties || [],
      effectiveDate: result.effectiveDate,
      expirationDate: result.expirationDate,
      jurisdiction: result.jurisdiction,
      governingLaw: result.governingLaw,
      keyProvisions: result.keyProvisions || [],
      ...result
    };
  } catch (error) {
    console.error("Error extracting document metadata:", error);
    throw new Error("Failed to extract document metadata");
  }
}

/**
 * Compares two legal documents and identifies similarities and differences
 */
export async function compareDocuments(
  document1: string,
  document2: string,
  document1Name?: string,
  document2Name?: string
): Promise<DocumentComparisonResult> {
  try {
    const prompt = `
      As a legal expert, compare these two documents:
      
      DOCUMENT 1${document1Name ? ` (${document1Name})` : ''}:
      ${document1}
      
      DOCUMENT 2${document2Name ? ` (${document2Name})` : ''}:
      ${document2}
      
      Provide a comparison in JSON format with these fields:
      - similarities: Array of key similarities between the documents
      - differences: Array of key differences between the documents
      - recommendations: Array of recommendations based on the comparison
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content);

    return {
      similarities: result.similarities || [],
      differences: result.differences || [],
      recommendations: result.recommendations || [],
    };
  } catch (error) {
    console.error("Error comparing documents:", error);
    throw new Error("Failed to compare documents");
  }
}