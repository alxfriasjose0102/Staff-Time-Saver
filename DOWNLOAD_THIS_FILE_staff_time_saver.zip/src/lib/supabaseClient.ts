import { createClient } from '@supabase/supabase-js';
import type { Session, User } from '@supabase/supabase-js';
import { UserRoleType } from '../../shared/schema';

// Supabase configuration
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Supabase credentials not found. Please check your environment variables.');
}

// Create a single supabase client for interacting with your database
export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface AuthUserMetadata {
  firstName?: string;
  lastName?: string;
  role?: UserRoleType;
  avatarUrl?: string;
}

export async function loginWithEmail(email: string, password: string) {
  const response = await supabase.auth.signInWithPassword({
    email,
    password,
  });

  if (response.error) {
    throw new Error(response.error.message);
  }

  return response;
}

export async function signUpWithEmail(
  email: string, 
  password: string, 
  metadata: AuthUserMetadata
) {
  const response = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: {
        firstName: metadata.firstName || '',
        lastName: metadata.lastName || '',
        role: metadata.role || 'staff',
        avatarUrl: metadata.avatarUrl || '',
      }
    }
  });

  if (response.error) {
    throw new Error(response.error.message);
  }

  return response;
}

export async function logout(): Promise<void> {
  const { error } = await supabase.auth.signOut();
  
  if (error) {
    throw new Error(error.message);
  }
}

export async function getCurrentUser(): Promise<User | null> {
  const { data } = await supabase.auth.getUser();
  return data.user;
}

export async function refreshSession(): Promise<void> {
  const { error } = await supabase.auth.refreshSession();
  
  if (error) {
    console.error('Failed to refresh session:', error);
    throw new Error(error.message);
  }
}

// Reset password functionality
export async function resetPassword(email: string): Promise<void> {
  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: `${window.location.origin}/reset-password`,
  });
  
  if (error) {
    throw new Error(error.message);
  }
}

// Update user password
export async function updatePassword(newPassword: string): Promise<void> {
  const { error } = await supabase.auth.updateUser({
    password: newPassword,
  });
  
  if (error) {
    throw new Error(error.message);
  }
}

// Update user profile
export async function updateUserProfile(metadata: Partial<AuthUserMetadata>): Promise<void> {
  const { error } = await supabase.auth.updateUser({
    data: metadata
  });
  
  if (error) {
    throw new Error(error.message);
  }
}

// Set up auth state change listener
export function onAuthStateChange(callback: (event: string, session: Session | null) => void) {
  const { data } = supabase.auth.onAuthStateChange((event, session) => {
    callback(event, session);
  });
  
  return data.subscription;
}

export default supabase;