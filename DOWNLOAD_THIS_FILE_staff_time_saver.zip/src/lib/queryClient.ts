import { QueryClient } from "@tanstack/react-query";
import { getApiUrl } from "./config";

type ApiRequestOptions = {
  on401?: "redirect" | "returnNull";
};

export async function apiRequest(
  method: string,
  url: string,
  data?: any
): Promise<Response> {
  // Use the getApiUrl helper to handle environment differences
  const apiUrl = getApiUrl(url);
  
  const options: RequestInit = {
    method,
    headers: {
      "Content-Type": "application/json",
    },
    credentials: "include",
  };

  if (data) {
    options.body = JSON.stringify(data);
  }

  const response = await fetch(apiUrl, options);

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    const error = new Error(
      errorData.message || `API request failed with status ${response.status}`
    );
    throw Object.assign(error, {
      status: response.status,
      ...errorData,
    });
  }

  return response;
}

export const getQueryFn =
  (options: ApiRequestOptions = {}) =>
  async ({ queryKey }: { queryKey: string[] }) => {
    const [url] = queryKey;
    try {
      // Use the getApiUrl helper to handle environment differences
      const apiUrl = getApiUrl(url);
      
      const response = await fetch(apiUrl, {
        credentials: "include",
      });

      if (response.status === 401 && options.on401 === "returnNull") {
        return null;
      }

      if (response.status === 401 && options.on401 === "redirect") {
        window.location.href = "/auth";
        return null;
      }

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        const error = new Error(
          errorData.message || `API request failed with status ${response.status}`
        );
        throw Object.assign(error, {
          status: response.status,
          ...errorData,
        });
      }

      const contentType = response.headers.get("content-type");
      if (contentType && contentType.includes("application/json")) {
        return response.json();
      }

      return response.text();
    } catch (error) {
      console.error("Query error:", error);
      throw error;
    }
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      staleTime: 5 * 60 * 1000, // 5 minutes
      retry: 1,
    },
  },
});