// Environment configuration for frontend

// Determine if we're in development or production
const isDev = import.meta.env.DEV;

// API base URL - automatically switches between local and production
export const API_BASE_URL = isDev ? '' : '/.netlify/functions/api';

// Function to get full API URL
export const getApiUrl = (path: string): string => {
  // Make sure path starts with a slash if not already
  const formattedPath = path.startsWith('/') ? path : `/${path}`;
  
  // For local development, keep the path as is (e.g., /api/user)
  // For production on Netlify, prepend the Netlify function path
  return isDev ? formattedPath : `${API_BASE_URL}${formattedPath.replace(/^\/api/, '')}`;
};

// Other configuration values
export const APP_CONFIG = {
  appName: 'Staff Time Saver',
  defaultLocale: 'en',
  supportedLocales: ['en', 'es', 'ht', 'ru'],
  defaultTimeFormat: 'h:mm a',
  defaultDateFormat: 'MM/dd/yyyy',
};