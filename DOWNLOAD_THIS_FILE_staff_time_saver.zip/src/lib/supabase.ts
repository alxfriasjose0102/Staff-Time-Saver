import { createClient } from '@supabase/supabase-js';
import type { InsertClient, InsertMatter } from '../../shared/schema';

// Initialize Supabase client
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables. Please set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY.');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Matter-related functions
export const matterService = {
  /**
   * Create a new matter/case
   * @param matterData Matter data to insert
   * @returns The created matter or null if an error occurred
   */
  async createMatter(matterData: InsertMatter) {
    try {
      const { data, error } = await supabase
        .from('matters')
        .insert(matterData)
        .select()
        .single();

      if (error) {
        console.error('Error creating matter:', error);
        throw new Error(error.message);
      }

      return data;
    } catch (error) {
      console.error('Error in createMatter:', error);
      throw error;
    }
  },

  /**
   * Get all matters
   * @returns An array of matters
   */
  async getMatters() {
    try {
      const { data, error } = await supabase
        .from('matters')
        .select(`
          *,
          client:client_id(*),
          assigned_attorney:assigned_attorney_id(
            id,
            firstName,
            lastName,
            email,
            role
          )
        `)
        .order('createdAt', { ascending: false });

      if (error) {
        console.error('Error fetching matters:', error);
        throw new Error(error.message);
      }

      return data || [];
    } catch (error) {
      console.error('Error in getMatters:', error);
      throw error;
    }
  },

  /**
   * Get matters for a specific client
   * @param clientId Client ID
   * @returns Matters for the client
   */
  async getMattersByClientId(clientId: number) {
    try {
      const { data, error } = await supabase
        .from('matters')
        .select(`
          *,
          assigned_attorney:assigned_attorney_id(
            id,
            firstName,
            lastName,
            email,
            role
          )
        `)
        .eq('client_id', clientId)
        .order('createdAt', { ascending: false });

      if (error) {
        console.error('Error fetching client matters:', error);
        throw new Error(error.message);
      }

      return data || [];
    } catch (error) {
      console.error('Error in getMattersByClientId:', error);
      throw error;
    }
  },

  /**
   * Get a matter by ID
   * @param id Matter ID
   * @returns The matter or null if not found
   */
  async getMatterById(id: number) {
    try {
      const { data, error } = await supabase
        .from('matters')
        .select(`
          *,
          client:client_id(*),
          assigned_attorney:assigned_attorney_id(
            id,
            firstName,
            lastName,
            email,
            role
          ),
          documents:documents(*)
        `)
        .eq('id', id)
        .single();

      if (error) {
        console.error('Error fetching matter:', error);
        throw new Error(error.message);
      }

      return data;
    } catch (error) {
      console.error('Error in getMatterById:', error);
      throw error;
    }
  },

  /**
   * Update a matter
   * @param id Matter ID
   * @param matterData Matter data to update
   * @returns The updated matter or null if an error occurred
   */
  async updateMatter(id: number, matterData: Partial<InsertMatter>) {
    try {
      const { data, error } = await supabase
        .from('matters')
        .update(matterData)
        .eq('id', id)
        .select()
        .single();

      if (error) {
        console.error('Error updating matter:', error);
        throw new Error(error.message);
      }

      return data;
    } catch (error) {
      console.error('Error in updateMatter:', error);
      throw error;
    }
  },

  /**
   * Delete a matter
   * @param id Matter ID
   * @returns True if deleted successfully, false otherwise
   */
  async deleteMatter(id: number): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('matters')
        .delete()
        .eq('id', id);

      if (error) {
        console.error('Error deleting matter:', error);
        throw new Error(error.message);
      }

      return true;
    } catch (error) {
      console.error('Error in deleteMatter:', error);
      throw error;
    }
  }
};

// Client-related functions
export const clientService = {
  /**
   * Create a new client
   * @param clientData Client data to create
   * @returns The created client or null if an error occurred
   */
  async createClient(clientData: InsertClient) {
    try {
      const { data, error } = await supabase
        .from('clients')
        .insert(clientData)
        .select()
        .single();

      if (error) {
        console.error('Error creating client:', error);
        throw new Error(error.message);
      }

      return data;
    } catch (error) {
      console.error('Error in createClient:', error);
      throw error;
    }
  },

  /**
   * Get all clients
   * @returns An array of clients
   */
  async getClients() {
    try {
      const { data, error } = await supabase
        .from('clients')
        .select(`
          *,
          assigned_attorney:assigned_attorney_id(
            id,
            firstName,
            lastName,
            email,
            role
          )
        `)
        .order('createdAt', { ascending: false });

      if (error) {
        console.error('Error fetching clients:', error);
        throw new Error(error.message);
      }

      return data || [];
    } catch (error) {
      console.error('Error in getClients:', error);
      throw error;
    }
  },

  /**
   * Get a client by ID
   * @param id Client ID
   * @returns The client or null if not found
   */
  async getClientById(id: number) {
    try {
      const { data, error } = await supabase
        .from('clients')
        .select(`
          *,
          matters(*),
          assigned_attorney:assigned_attorney_id(
            id,
            firstName,
            lastName,
            email,
            role
          )
        `)
        .eq('id', id)
        .single();

      if (error) {
        console.error('Error fetching client:', error);
        throw new Error(error.message);
      }

      return data;
    } catch (error) {
      console.error('Error in getClientById:', error);
      throw error;
    }
  },

  /**
   * Update a client
   * @param id Client ID
   * @param clientData Client data to update
   * @returns The updated client or null if an error occurred
   */
  async updateClient(id: number, clientData: Partial<InsertClient>) {
    try {
      const { data, error } = await supabase
        .from('clients')
        .update(clientData)
        .eq('id', id)
        .select()
        .single();

      if (error) {
        console.error('Error updating client:', error);
        throw new Error(error.message);
      }

      return data;
    } catch (error) {
      console.error('Error in updateClient:', error);
      throw error;
    }
  },

  /**
   * Delete a client
   * @param id Client ID
   * @returns True if deleted successfully, false otherwise
   */
  async deleteClient(id: number): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('clients')
        .delete()
        .eq('id', id);

      if (error) {
        console.error('Error deleting client:', error);
        throw new Error(error.message);
      }

      return true;
    } catch (error) {
      console.error('Error in deleteClient:', error);
      throw error;
    }
  }
};