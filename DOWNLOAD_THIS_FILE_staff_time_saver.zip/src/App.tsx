import { Route, Switch } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { AuthProvider } from "./hooks/use-auth";
import { Toaster } from "./components/ui/toaster";
import ProtectedRoute from "./components/ProtectedRoute";
import SessionCheck from "./components/SessionCheck";
import AuthPage from "./pages/auth-page";
import DashboardPage from "./pages/dashboard-page";
import ClientsPage from "./pages/clients-page";
import DocumentsPage from "./pages/documents-page";
import DocumentAnalysisPage from "./pages/document-analysis-page";
import MattersPage from "./pages/matters-page";
import NotFoundPage from "./pages/not-found";
import { MainLayout } from "./layouts/MainLayout";
import { Redirect } from "wouter";

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <div className="min-h-screen bg-background">
          <SessionCheck />
          <Switch>
            <Route path="/" component={() => <Redirect to="/dashboard" />} />
            <Route path="/auth" component={AuthPage} />
            <ProtectedRoute path="/dashboard" component={DashboardPage} />
            <ProtectedRoute path="/clients" component={ClientsPage} />
            <ProtectedRoute path="/documents" component={DocumentsPage} />
            <ProtectedRoute path="/documents/analyze" component={DocumentAnalysisPage} />
            <ProtectedRoute path="/matters" component={MattersPage} />
            <ProtectedRoute path="/signatures" component={() => <MainLayout><h1 className="text-2xl font-bold">Signatures</h1></MainLayout>} />
            <ProtectedRoute path="/reports" component={() => <MainLayout><h1 className="text-2xl font-bold">Reports</h1></MainLayout>} />
            <ProtectedRoute path="/calendar" component={() => <MainLayout><h1 className="text-2xl font-bold">Calendar</h1></MainLayout>} />
            <ProtectedRoute path="/tasks" component={() => <MainLayout><h1 className="text-2xl font-bold">Tasks</h1></MainLayout>} />
            <ProtectedRoute path="/settings" component={() => <MainLayout><h1 className="text-2xl font-bold">Settings</h1></MainLayout>} />
            <Route component={NotFoundPage} />
          </Switch>
        </div>
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;