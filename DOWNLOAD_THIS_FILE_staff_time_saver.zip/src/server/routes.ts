import express, { Express } from 'express';
import { createServer, type Server } from 'http';
import { setupAuth } from './auth';
import { storage } from './storage';
import { db } from './db';
import { eq, and, desc, sql, asc, or, isNull } from 'drizzle-orm';
import crypto from 'crypto';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { 
  hasPermission, 
  permissions, 
  clients, 
  matters, 
  users,
  documents,
  signatureRequests,
  insertClientSchema,
  insertMatterSchema,
  insertDocumentSchema,
  insertSignatureRequestSchema,
  signatureRequestStatusEnum,
} from '../shared/schema';
import {
  analyzeDocument,
  DocumentAnalysisResult,
  extractDocumentMetadata,
  summarizeLegalDocument,
  compareDocuments
} from './openai';

// Middleware to check if user is authenticated
function isAuthenticated(req: express.Request, res: express.Response, next: express.NextFunction) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ error: 'Not authenticated' });
}

// Middleware to check if user has a specific permission
function checkPermission(permission: string) {
  return (req: express.Request, res: express.Response, next: express.NextFunction) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: 'Not authenticated' });
    }

    const user = req.user;
    if (!user || !user.role || !hasPermission(user.role as any, permission)) {
      return res.status(403).json({ error: 'Forbidden' });
    }

    next();
  };
}

export function registerRoutes(app: Express): Server {
  // Setup authentication
  setupAuth(app);

  // API routes

  // Users
  app.get('/api/users', 
    isAuthenticated,
    checkPermission(permissions.READ_USER),
    async (req, res) => {
      try {
        const usersList = await db.select().from(users);
        
        // Remove password field from response
        const usersWithoutPassword = usersList.map(user => {
          const { password, ...userWithoutPassword } = user;
          return userWithoutPassword;
        });
        
        res.json(usersWithoutPassword);
      } catch (error) {
        console.error('Error fetching users:', error);
        res.status(500).json({ error: 'Failed to fetch users' });
      }
    }
  );

  // Clients
  app.get('/api/clients',
    isAuthenticated,
    checkPermission(permissions.READ_CLIENT),
    async (req, res) => {
      try {
        const clientsList = await db.select().from(clients).orderBy(desc(clients.createdAt));
        res.json(clientsList);
      } catch (error) {
        console.error('Error fetching clients:', error);
        res.status(500).json({ error: 'Failed to fetch clients' });
      }
    }
  );

  app.post('/api/clients',
    isAuthenticated,
    checkPermission(permissions.CREATE_CLIENT),
    async (req, res) => {
      try {
        // Validate request body using the schema
        const validationResult = insertClientSchema.safeParse(req.body);
        if (!validationResult.success) {
          return res.status(400).json({ 
            error: 'Invalid client data', 
            details: validationResult.error.errors 
          });
        }
        
        // Get the current user ID
        const userId = req.user?.id;
        
        // Extract matters from request (if any)
        const { matters: clientMatters, ...clientData } = req.body;
        
        // Create client
        const [newClient] = await db.insert(clients)
          .values({
            ...clientData,
            userId,
            updatedAt: new Date(),
          })
          .returning();
        
        // If matters were provided, create them
        if (clientMatters && Array.isArray(clientMatters) && clientMatters.length > 0) {
          const mattersToInsert = clientMatters.map(matter => ({
            clientId: newClient.id,
            title: matter.title,
            description: matter.description || null,
            type: matter.type,
            status: 'Active',
          }));
          
          await db.insert(matters).values(mattersToInsert);
        }
        
        // Get the client with all relationships
        const clientWithMatters = await db.query.clients.findFirst({
          where: eq(clients.id, newClient.id),
          with: {
            matters: true,
          },
        });
        
        res.status(201).json(clientWithMatters);
      } catch (error) {
        console.error('Error creating client:', error);
        res.status(500).json({ error: 'Failed to create client' });
      }
    }
  );

  app.get('/api/clients/:id',
    isAuthenticated,
    checkPermission(permissions.READ_CLIENT),
    async (req, res) => {
      try {
        const clientId = parseInt(req.params.id);
        if (isNaN(clientId)) {
          return res.status(400).json({ error: 'Invalid client ID' });
        }
        
        // Get client with all relationships
        const clientWithDetails = await db.query.clients.findFirst({
          where: eq(clients.id, clientId),
          with: {
            matters: true,
          },
        });
        
        if (!clientWithDetails) {
          return res.status(404).json({ error: 'Client not found' });
        }
        
        res.json(clientWithDetails);
      } catch (error) {
        console.error('Error fetching client details:', error);
        res.status(500).json({ error: 'Failed to fetch client details' });
      }
    }
  );

  app.put('/api/clients/:id',
    isAuthenticated,
    checkPermission(permissions.UPDATE_CLIENT),
    async (req, res) => {
      try {
        const clientId = parseInt(req.params.id);
        if (isNaN(clientId)) {
          return res.status(400).json({ error: 'Invalid client ID' });
        }
        
        // Validate request body
        const validationResult = insertClientSchema.partial().safeParse(req.body);
        if (!validationResult.success) {
          return res.status(400).json({ 
            error: 'Invalid client data', 
            details: validationResult.error.errors 
          });
        }
        
        // Check if client exists
        const existingClient = await db.query.clients.findFirst({
          where: eq(clients.id, clientId)
        });
        
        if (!existingClient) {
          return res.status(404).json({ error: 'Client not found' });
        }
        
        // Update client
        const [updatedClient] = await db.update(clients)
          .set({
            ...req.body,
            updatedAt: new Date(),
          })
          .where(eq(clients.id, clientId))
          .returning();
        
        res.json(updatedClient);
      } catch (error) {
        console.error('Error updating client:', error);
        res.status(500).json({ error: 'Failed to update client' });
      }
    }
  );

  app.delete('/api/clients/:id',
    isAuthenticated,
    checkPermission(permissions.DELETE_CLIENT),
    async (req, res) => {
      try {
        const clientId = parseInt(req.params.id);
        if (isNaN(clientId)) {
          return res.status(400).json({ error: 'Invalid client ID' });
        }
        
        // Check if client exists
        const existingClient = await db.query.clients.findFirst({
          where: eq(clients.id, clientId)
        });
        
        if (!existingClient) {
          return res.status(404).json({ error: 'Client not found' });
        }
        
        // Delete associated matters first
        await db.delete(matters).where(eq(matters.clientId, clientId));
        
        // Delete client
        await db.delete(clients).where(eq(clients.id, clientId));
        
        res.json({ success: true, message: 'Client and all associated records deleted successfully' });
      } catch (error) {
        console.error('Error deleting client:', error);
        res.status(500).json({ error: 'Failed to delete client' });
      }
    }
  );
  
  // Matters
  app.get('/api/matters',
    isAuthenticated,
    checkPermission(permissions.READ_MATTER),
    async (req, res) => {
      try {
        const mattersList = await db.query.matters.findMany({
          with: {
            client: true,
          },
          orderBy: [desc(matters.createdAt)],
        });
        
        res.json(mattersList);
      } catch (error) {
        console.error('Error fetching matters:', error);
        res.status(500).json({ error: 'Failed to fetch matters' });
      }
    }
  );
  
  app.post('/api/matters',
    isAuthenticated,
    checkPermission(permissions.CREATE_MATTER),
    async (req, res) => {
      try {
        // Validate request body
        const validationResult = insertMatterSchema.safeParse(req.body);
        if (!validationResult.success) {
          return res.status(400).json({ 
            error: 'Invalid matter data', 
            details: validationResult.error.errors 
          });
        }
        
        // Check if client exists
        const clientExists = await db.query.clients.findFirst({
          where: eq(clients.id, req.body.clientId)
        });
        
        if (!clientExists) {
          return res.status(400).json({ error: 'Client not found' });
        }
        
        // Create matter
        const [newMatter] = await db.insert(matters)
          .values({
            ...req.body,
            updatedAt: new Date(),
          })
          .returning();
        
        res.status(201).json(newMatter);
      } catch (error) {
        console.error('Error creating matter:', error);
        res.status(500).json({ error: 'Failed to create matter' });
      }
    }
  );
  
  app.get('/api/matters/:id',
    isAuthenticated,
    checkPermission(permissions.READ_MATTER),
    async (req, res) => {
      try {
        const matterId = parseInt(req.params.id);
        if (isNaN(matterId)) {
          return res.status(400).json({ error: 'Invalid matter ID' });
        }
        
        const matterWithDetails = await db.query.matters.findFirst({
          where: eq(matters.id, matterId),
          with: {
            client: true,
          },
        });
        
        if (!matterWithDetails) {
          return res.status(404).json({ error: 'Matter not found' });
        }
        
        res.json(matterWithDetails);
      } catch (error) {
        console.error('Error fetching matter details:', error);
        res.status(500).json({ error: 'Failed to fetch matter details' });
      }
    }
  );
  
  app.put('/api/matters/:id',
    isAuthenticated,
    checkPermission(permissions.UPDATE_MATTER),
    async (req, res) => {
      try {
        const matterId = parseInt(req.params.id);
        if (isNaN(matterId)) {
          return res.status(400).json({ error: 'Invalid matter ID' });
        }
        
        // Validate request body
        const validationResult = insertMatterSchema.partial().safeParse(req.body);
        if (!validationResult.success) {
          return res.status(400).json({ 
            error: 'Invalid matter data', 
            details: validationResult.error.errors 
          });
        }
        
        // Check if matter exists
        const existingMatter = await db.query.matters.findFirst({
          where: eq(matters.id, matterId)
        });
        
        if (!existingMatter) {
          return res.status(404).json({ error: 'Matter not found' });
        }
        
        // If changing client, verify client exists
        if (req.body.clientId && req.body.clientId !== existingMatter.clientId) {
          const clientExists = await db.query.clients.findFirst({
            where: eq(clients.id, req.body.clientId)
          });
          
          if (!clientExists) {
            return res.status(400).json({ error: 'Client not found' });
          }
        }
        
        // Update matter
        const [updatedMatter] = await db.update(matters)
          .set({
            ...req.body,
            updatedAt: new Date(),
          })
          .where(eq(matters.id, matterId))
          .returning();
        
        res.json(updatedMatter);
      } catch (error) {
        console.error('Error updating matter:', error);
        res.status(500).json({ error: 'Failed to update matter' });
      }
    }
  );
  
  app.delete('/api/matters/:id',
    isAuthenticated,
    checkPermission(permissions.DELETE_MATTER),
    async (req, res) => {
      try {
        const matterId = parseInt(req.params.id);
        if (isNaN(matterId)) {
          return res.status(400).json({ error: 'Invalid matter ID' });
        }
        
        // Check if matter exists
        const existingMatter = await db.query.matters.findFirst({
          where: eq(matters.id, matterId)
        });
        
        if (!existingMatter) {
          return res.status(404).json({ error: 'Matter not found' });
        }
        
        // Delete matter
        await db.delete(matters).where(eq(matters.id, matterId));
        
        res.json({ success: true, message: 'Matter deleted successfully' });
      } catch (error) {
        console.error('Error deleting matter:', error);
        res.status(500).json({ error: 'Failed to delete matter' });
      }
    }
  );

  // Set up multer for file uploads
  const uploadsDir = path.join(process.cwd(), 'uploads');
  if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
  }

  const storage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, uploadsDir);
    },
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
      const ext = path.extname(file.originalname);
      cb(null, uniqueSuffix + ext);
    },
  });

  const upload = multer({ 
    storage,
    limits: {
      fileSize: 10 * 1024 * 1024, // 10MB max file size
    },
    fileFilter: (req, file, cb) => {
      // Accept common document, image and PDF types
      const allowedTypes = [
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'text/plain',
        'image/jpeg',
        'image/png',
        'image/gif',
      ];
      
      if (allowedTypes.includes(file.mimetype)) {
        cb(null, true);
      } else {
        cb(new Error('Invalid file type. Only document, PDF, and image files are allowed.'), false);
      }
    },
  });

  // Documents
  app.get('/api/documents',
    isAuthenticated,
    checkPermission(permissions.READ_DOCUMENT),
    async (req, res) => {
      try {
        const clientId = req.query.clientId ? parseInt(req.query.clientId as string) : undefined;
        const matterId = req.query.matterId ? parseInt(req.query.matterId as string) : undefined;
        
        let whereClause = {};
        
        if (clientId) {
          whereClause = eq(documents.clientId, clientId);
        }
        
        if (matterId) {
          whereClause = eq(documents.matterId, matterId);
        }
        
        const documentsList = await db.query.documents.findMany({
          where: Object.keys(whereClause).length > 0 ? whereClause : undefined,
          with: {
            client: true,
            matter: true,
            createdBy: true,
          },
          orderBy: [desc(documents.createdAt)],
        });
        
        res.json(documentsList);
      } catch (error) {
        console.error('Error fetching documents:', error);
        res.status(500).json({ error: 'Failed to fetch documents' });
      }
    }
  );
  
  app.post('/api/documents',
    isAuthenticated,
    checkPermission(permissions.CREATE_DOCUMENT),
    upload.single('file'),
    async (req, res) => {
      try {
        // Extract document data
        const { title, clientId, matterId, status, needsSignature } = req.body;
        
        // Validate required fields
        if (!title || !clientId) {
          return res.status(400).json({ error: 'Title and client are required' });
        }
        
        // Check if client exists
        const client = await db.query.clients.findFirst({
          where: eq(clients.id, parseInt(clientId)),
        });
        
        if (!client) {
          return res.status(400).json({ error: 'Client not found' });
        }
        
        // Check if matter exists if provided
        if (matterId) {
          const matter = await db.query.matters.findFirst({
            where: eq(matters.id, parseInt(matterId)),
          });
          
          if (!matter) {
            return res.status(400).json({ error: 'Matter not found' });
          }
        }
        
        // Create document record
        const [newDocument] = await db.insert(documents)
          .values({
            title,
            clientId: parseInt(clientId),
            matterId: matterId ? parseInt(matterId) : null,
            status: status || 'Draft',
            needsSignature: needsSignature === 'true',
            createdById: req.user!.id,
            fileName: req.file?.originalname,
            fileType: req.file?.mimetype,
            fileSize: req.file?.size,
            fileUrl: req.file ? `/uploads/${req.file.filename}` : null,
            createdAt: new Date(),
            updatedAt: new Date(),
          })
          .returning();
        
        // Get the document with all relationships
        const documentWithDetails = await db.query.documents.findFirst({
          where: eq(documents.id, newDocument.id),
          with: {
            client: true,
            matter: true,
            createdBy: true,
          },
        });
        
        res.status(201).json(documentWithDetails);
      } catch (error) {
        console.error('Error creating document:', error);
        res.status(500).json({ error: 'Failed to create document' });
      }
    }
  );
  
  app.get('/api/documents/:id',
    isAuthenticated,
    checkPermission(permissions.READ_DOCUMENT),
    async (req, res) => {
      try {
        const documentId = parseInt(req.params.id);
        if (isNaN(documentId)) {
          return res.status(400).json({ error: 'Invalid document ID' });
        }
        
        const documentWithDetails = await db.query.documents.findFirst({
          where: eq(documents.id, documentId),
          with: {
            client: true,
            matter: true,
            createdBy: true,
          },
        });
        
        if (!documentWithDetails) {
          return res.status(404).json({ error: 'Document not found' });
        }
        
        res.json(documentWithDetails);
      } catch (error) {
        console.error('Error fetching document details:', error);
        res.status(500).json({ error: 'Failed to fetch document details' });
      }
    }
  );
  
  app.patch('/api/documents/:id/status',
    isAuthenticated,
    checkPermission(permissions.UPDATE_DOCUMENT),
    async (req, res) => {
      try {
        const documentId = parseInt(req.params.id);
        if (isNaN(documentId)) {
          return res.status(400).json({ error: 'Invalid document ID' });
        }
        
        const { status } = req.body;
        if (!status) {
          return res.status(400).json({ error: 'Status is required' });
        }
        
        // Check if document exists
        const existingDocument = await db.query.documents.findFirst({
          where: eq(documents.id, documentId),
        });
        
        if (!existingDocument) {
          return res.status(404).json({ error: 'Document not found' });
        }
        
        // Update document status
        const [updatedDocument] = await db.update(documents)
          .set({
            status,
            updatedAt: new Date(),
          })
          .where(eq(documents.id, documentId))
          .returning();
        
        res.json(updatedDocument);
      } catch (error) {
        console.error('Error updating document status:', error);
        res.status(500).json({ error: 'Failed to update document status' });
      }
    }
  );
  
  app.put('/api/documents/:id',
    isAuthenticated,
    checkPermission(permissions.UPDATE_DOCUMENT),
    upload.single('file'),
    async (req, res) => {
      try {
        const documentId = parseInt(req.params.id);
        if (isNaN(documentId)) {
          return res.status(400).json({ error: 'Invalid document ID' });
        }
        
        // Extract document data
        const { title, clientId, matterId, status, needsSignature } = req.body;
        
        // Validate required fields
        if (!title || !clientId) {
          return res.status(400).json({ error: 'Title and client are required' });
        }
        
        // Check if document exists
        const existingDocument = await db.query.documents.findFirst({
          where: eq(documents.id, documentId),
        });
        
        if (!existingDocument) {
          return res.status(404).json({ error: 'Document not found' });
        }
        
        // Check if client exists
        const client = await db.query.clients.findFirst({
          where: eq(clients.id, parseInt(clientId)),
        });
        
        if (!client) {
          return res.status(400).json({ error: 'Client not found' });
        }
        
        // Check if matter exists if provided
        if (matterId) {
          const matter = await db.query.matters.findFirst({
            where: eq(matters.id, parseInt(matterId)),
          });
          
          if (!matter) {
            return res.status(400).json({ error: 'Matter not found' });
          }
        }
        
        // Prepare update data
        const updateData: any = {
          title,
          clientId: parseInt(clientId),
          matterId: matterId ? parseInt(matterId) : null,
          status: status || existingDocument.status,
          needsSignature: needsSignature === 'true',
          updatedAt: new Date(),
        };
        
        // Update file information if a new file was uploaded
        if (req.file) {
          // Remove old file if exists
          if (existingDocument.fileUrl) {
            const oldFilePath = path.join(process.cwd(), existingDocument.fileUrl.replace('/', ''));
            if (fs.existsSync(oldFilePath)) {
              fs.unlinkSync(oldFilePath);
            }
          }
          
          updateData.fileName = req.file.originalname;
          updateData.fileType = req.file.mimetype;
          updateData.fileSize = req.file.size;
          updateData.fileUrl = `/uploads/${req.file.filename}`;
        }
        
        // Update document
        const [updatedDocument] = await db.update(documents)
          .set(updateData)
          .where(eq(documents.id, documentId))
          .returning();
        
        // Get the document with all relationships
        const documentWithDetails = await db.query.documents.findFirst({
          where: eq(documents.id, updatedDocument.id),
          with: {
            client: true,
            matter: true,
            createdBy: true,
          },
        });
        
        res.json(documentWithDetails);
      } catch (error) {
        console.error('Error updating document:', error);
        res.status(500).json({ error: 'Failed to update document' });
      }
    }
  );
  
  app.delete('/api/documents/:id',
    isAuthenticated,
    checkPermission(permissions.DELETE_DOCUMENT),
    async (req, res) => {
      try {
        const documentId = parseInt(req.params.id);
        if (isNaN(documentId)) {
          return res.status(400).json({ error: 'Invalid document ID' });
        }
        
        // Check if document exists
        const existingDocument = await db.query.documents.findFirst({
          where: eq(documents.id, documentId),
        });
        
        if (!existingDocument) {
          return res.status(404).json({ error: 'Document not found' });
        }
        
        // Delete file if exists
        if (existingDocument.fileUrl) {
          const filePath = path.join(process.cwd(), existingDocument.fileUrl.replace('/', ''));
          if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
          }
        }
        
        // Delete document
        await db.delete(documents).where(eq(documents.id, documentId));
        
        res.json({ success: true, message: 'Document deleted successfully' });
      } catch (error) {
        console.error('Error deleting document:', error);
        res.status(500).json({ error: 'Failed to delete document' });
      }
    }
  );
  
  // Serve uploaded files
  app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));

  // Signature Requests
  app.get('/api/signature-requests',
    isAuthenticated,
    checkPermission(permissions.READ_SIGNATURE_REQUEST),
    async (req, res) => {
      try {
        const userId = req.user?.id;
        
        const requestsList = await db.query.signatureRequests.findMany({
          where: userId ? eq(signatureRequests.createdById, userId) : undefined,
          with: {
            document: {
              with: {
                client: true,
              },
            },
            createdBy: true,
          },
          orderBy: [desc(signatureRequests.createdAt)],
        });
        
        // Format the response to include only necessary fields
        const formattedRequests = requestsList.map(request => {
          const { createdBy, document, ...requestData } = request;
          
          return {
            ...requestData,
            document: {
              id: document.id,
              title: document.title,
            },
            recipient: {
              email: request.recipientEmail,
            },
          };
        });
        
        res.json(formattedRequests);
      } catch (error) {
        console.error('Error fetching signature requests:', error);
        res.status(500).json({ error: 'Failed to fetch signature requests' });
      }
    }
  );
  
  app.post('/api/signature-requests',
    isAuthenticated,
    checkPermission(permissions.CREATE_SIGNATURE_REQUEST),
    async (req, res) => {
      try {
        // Validate request body
        const validationResult = insertSignatureRequestSchema.safeParse(req.body);
        if (!validationResult.success) {
          return res.status(400).json({ 
            error: 'Invalid signature request data', 
            details: validationResult.error.errors 
          });
        }
        
        const { documentId, recipientEmail, message, expiresAt } = req.body;
        
        // Check if document exists
        const document = await db.query.documents.findFirst({
          where: eq(documents.id, documentId),
          with: {
            client: true,
          },
        });
        
        if (!document) {
          return res.status(400).json({ error: 'Document not found' });
        }
        
        // Generate a secure token for the signature request
        const token = crypto.randomBytes(32).toString('hex');
        
        // Hash the token for storage (we'll send the actual token in the email)
        const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
        
        // Create the signature request
        const [newRequest] = await db.insert(signatureRequests)
          .values({
            documentId,
            createdById: req.user?.id,
            recipientEmail,
            message,
            expiresAt: new Date(expiresAt),
            tokenHash,
            updatedAt: new Date(),
          })
          .returning();
        
        // Update document status
        await db.update(documents)
          .set({
            status: 'Pending Signature',
            needsSignature: true,
            updatedAt: new Date(),
          })
          .where(eq(documents.id, documentId));
        
        // In a real application, we would send an email here with a link to sign
        // For now, log the signing URL which would be included in the email
        const baseUrl = process.env.BASE_URL || `http://localhost:${process.env.PORT || 5173}`;
        const signUrl = `${baseUrl}/sign/${newRequest.id}?token=${token}`;
        
        console.log(`Signature request created. Signing URL: ${signUrl}`);
        
        res.status(201).json({
          ...newRequest,
          document: {
            id: document.id,
            title: document.title,
          },
          recipient: {
            email: recipientEmail,
          },
        });
      } catch (error) {
        console.error('Error creating signature request:', error);
        res.status(500).json({ error: 'Failed to create signature request' });
      }
    }
  );
  
  app.get('/api/signature-requests/:id',
    isAuthenticated,
    checkPermission(permissions.READ_SIGNATURE_REQUEST),
    async (req, res) => {
      try {
        const requestId = req.params.id;
        
        const request = await db.query.signatureRequests.findFirst({
          where: eq(signatureRequests.id, requestId),
          with: {
            document: {
              with: {
                client: true,
              },
            },
            createdBy: true,
          },
        });
        
        if (!request) {
          return res.status(404).json({ error: 'Signature request not found' });
        }
        
        // Only allow the creator to view the details
        if (request.createdById !== req.user?.id && req.user?.role !== 'admin') {
          return res.status(403).json({ error: 'You do not have permission to view this signature request' });
        }
        
        // Format the response
        const { createdBy, document, ...requestData } = request;
        
        const formattedRequest = {
          ...requestData,
          document: {
            id: document.id,
            title: document.title,
            fileName: document.fileName,
            fileUrl: document.fileUrl,
          },
          sender: {
            firstName: createdBy.firstName,
            lastName: createdBy.lastName,
            email: createdBy.email,
          },
        };
        
        res.json(formattedRequest);
      } catch (error) {
        console.error('Error fetching signature request details:', error);
        res.status(500).json({ error: 'Failed to fetch signature request details' });
      }
    }
  );
  
  app.patch('/api/signature-requests/:id/cancel',
    isAuthenticated,
    checkPermission(permissions.UPDATE_SIGNATURE_REQUEST),
    async (req, res) => {
      try {
        const requestId = req.params.id;
        
        // Check if request exists and belongs to the user
        const request = await db.query.signatureRequests.findFirst({
          where: eq(signatureRequests.id, requestId),
        });
        
        if (!request) {
          return res.status(404).json({ error: 'Signature request not found' });
        }
        
        if (request.createdById !== req.user?.id && req.user?.role !== 'admin') {
          return res.status(403).json({ error: 'You do not have permission to cancel this signature request' });
        }
        
        if (request.status !== 'Pending') {
          return res.status(400).json({ error: `Cannot cancel a signature request with status '${request.status}'` });
        }
        
        // Cancel the request
        const [updatedRequest] = await db.update(signatureRequests)
          .set({
            status: 'Canceled',
            updatedAt: new Date(),
          })
          .where(eq(signatureRequests.id, requestId))
          .returning();
        
        res.json(updatedRequest);
      } catch (error) {
        console.error('Error canceling signature request:', error);
        res.status(500).json({ error: 'Failed to cancel signature request' });
      }
    }
  );
  
  app.post('/api/signature-requests/:id/resend',
    isAuthenticated,
    checkPermission(permissions.UPDATE_SIGNATURE_REQUEST),
    async (req, res) => {
      try {
        const requestId = req.params.id;
        
        // Check if request exists and belongs to the user
        const request = await db.query.signatureRequests.findFirst({
          where: eq(signatureRequests.id, requestId),
          with: {
            document: true,
          },
        });
        
        if (!request) {
          return res.status(404).json({ error: 'Signature request not found' });
        }
        
        if (request.createdById !== req.user?.id && req.user?.role !== 'admin') {
          return res.status(403).json({ error: 'You do not have permission to resend this signature request' });
        }
        
        if (request.status !== 'Pending') {
          return res.status(400).json({ error: `Cannot resend a signature request with status '${request.status}'` });
        }
        
        // Update the request to extend expiration and mark as updated
        const [updatedRequest] = await db.update(signatureRequests)
          .set({
            expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // Extend by 7 days
            updatedAt: new Date(),
          })
          .where(eq(signatureRequests.id, requestId))
          .returning();
        
        // In a real application, we would re-send the email here
        // For now, log a message
        console.log(`Signature request ${requestId} has been resent to ${request.recipientEmail}`);
        
        res.json(updatedRequest);
      } catch (error) {
        console.error('Error resending signature request:', error);
        res.status(500).json({ error: 'Failed to resend signature request' });
      }
    }
  );
  
  // Public endpoint for signing a document
  app.get('/api/sign/:id',
    async (req, res) => {
      try {
        const requestId = req.params.id;
        const token = req.query.token as string;
        
        if (!token) {
          return res.status(400).json({ error: 'Missing token' });
        }
        
        // Hash the token to compare with stored hash
        const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
        
        // Find the signature request
        const request = await db.query.signatureRequests.findFirst({
          where: and(
            eq(signatureRequests.id, requestId),
            eq(signatureRequests.tokenHash, tokenHash)
          ),
          with: {
            document: {
              with: {
                client: true,
                createdBy: true,
              },
            },
          },
        });
        
        if (!request) {
          return res.status(404).json({ error: 'Signature request not found or invalid token' });
        }
        
        if (request.status !== 'Pending') {
          return res.status(400).json({ error: `This signature request has already been ${request.status.toLowerCase()}` });
        }
        
        // Check if expired
        if (new Date(request.expiresAt) < new Date()) {
          await db.update(signatureRequests)
            .set({
              status: 'Expired',
              updatedAt: new Date(),
            })
            .where(eq(signatureRequests.id, requestId));
            
          return res.status(400).json({ error: 'This signature request has expired' });
        }
        
        // Format the response for the signer
        const { document, ...requestData } = request;
        const { password, ...createdBy } = document.createdBy;
        
        const formattedRequest = {
          ...requestData,
          document: {
            id: document.id,
            title: document.title,
            fileName: document.fileName,
            fileUrl: document.fileUrl,
          },
          sender: {
            firstName: createdBy.firstName,
            lastName: createdBy.lastName,
            email: createdBy.email,
          },
        };
        
        res.json(formattedRequest);
      } catch (error) {
        console.error('Error retrieving signature request:', error);
        res.status(500).json({ error: 'Failed to retrieve signature request' });
      }
    }
  );
  
  app.post('/api/sign/:id',
    async (req, res) => {
      try {
        const requestId = req.params.id;
        const token = req.query.token as string;
        const { signature } = req.body;
        
        if (!token) {
          return res.status(400).json({ error: 'Missing token' });
        }
        
        if (!signature) {
          return res.status(400).json({ error: 'Signature is required' });
        }
        
        // Hash the token to compare with stored hash
        const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
        
        // Find the signature request
        const request = await db.query.signatureRequests.findFirst({
          where: and(
            eq(signatureRequests.id, requestId),
            eq(signatureRequests.tokenHash, tokenHash)
          ),
          with: {
            document: true,
          },
        });
        
        if (!request) {
          return res.status(404).json({ error: 'Signature request not found or invalid token' });
        }
        
        if (request.status !== 'Pending') {
          return res.status(400).json({ error: `This signature request has already been ${request.status.toLowerCase()}` });
        }
        
        // Check if expired
        if (new Date(request.expiresAt) < new Date()) {
          await db.update(signatureRequests)
            .set({
              status: 'Expired',
              updatedAt: new Date(),
            })
            .where(eq(signatureRequests.id, requestId));
            
          return res.status(400).json({ error: 'This signature request has expired' });
        }
        
        // Save the signature and mark as completed
        const [completedRequest] = await db.update(signatureRequests)
          .set({
            status: 'Completed',
            signatureUrl: signature,
            signedAt: new Date(),
            updatedAt: new Date(),
          })
          .where(eq(signatureRequests.id, requestId))
          .returning();
        
        // Update the document status
        await db.update(documents)
          .set({
            status: 'Signed',
            updatedAt: new Date(),
          })
          .where(eq(documents.id, request.documentId));
        
        // In a real application, we would notify the sender here
        // For now, log a message
        console.log(`Signature request ${requestId} has been completed.`);
        
        res.json(completedRequest);
      } catch (error) {
        console.error('Error completing signature request:', error);
        res.status(500).json({ error: 'Failed to complete signature request' });
      }
    }
  );

  // Reports API
  
  // Summary statistics
  app.get('/api/reports/summary',
    isAuthenticated,
    async (req, res) => {
      try {
        const timeRange = req.query.timeRange as string || '30d';
        let startDate = new Date();
        
        // Calculate start date based on time range
        switch (timeRange) {
          case '7d':
            startDate.setDate(startDate.getDate() - 7);
            break;
          case '30d':
            startDate.setDate(startDate.getDate() - 30);
            break;
          case '90d':
            startDate.setDate(startDate.getDate() - 90);
            break;
          case 'year':
            startDate.setFullYear(startDate.getFullYear() - 1);
            break;
          case 'all':
            startDate = new Date(0); // Beginning of time
            break;
          default:
            startDate.setDate(startDate.getDate() - 30);
        }
        
        // Previous period for comparison
        const prevPeriodStartDate = new Date(startDate);
        const prevPeriodLength = new Date().getTime() - startDate.getTime();
        prevPeriodStartDate.setTime(prevPeriodStartDate.getTime() - prevPeriodLength);
        
        // Get total clients count
        const [clientsResult] = await db.select({
          count: sql<number>`count(*)`,
        }).from(clients);

        // Get active clients (clients with documents or matters in the time range)
        const [activeClientsResult] = await db.select({
          count: sql<number>`count(distinct ${clients.id})`,
        })
        .from(clients)
        .leftJoin(documents, eq(documents.clientId, clients.id))
        .leftJoin(matters, eq(matters.clientId, clients.id))
        .where(
          or(
            and(
              sql`${documents.createdAt} >= ${startDate.toISOString()}`,
              sql`${documents.createdAt} <= ${new Date().toISOString()}`
            ),
            and(
              sql`${matters.createdAt} >= ${startDate.toISOString()}`,
              sql`${matters.createdAt} <= ${new Date().toISOString()}`
            )
          )
        );
        
        // Get clients in current period
        const [currentPeriodClientsResult] = await db.select({
          count: sql<number>`count(*)`,
        })
        .from(clients)
        .where(
          and(
            sql`${clients.createdAt} >= ${startDate.toISOString()}`,
            sql`${clients.createdAt} <= ${new Date().toISOString()}`
          )
        );
        
        // Get clients in previous period
        const [prevPeriodClientsResult] = await db.select({
          count: sql<number>`count(*)`,
        })
        .from(clients)
        .where(
          and(
            sql`${clients.createdAt} >= ${prevPeriodStartDate.toISOString()}`,
            sql`${clients.createdAt} < ${startDate.toISOString()}`
          )
        );
        
        // Calculate client change percentage
        const currentPeriodClients = currentPeriodClientsResult.count || 0;
        const prevPeriodClients = prevPeriodClientsResult.count || 0;
        let clientsMonthlyChange = '0%';
        
        if (prevPeriodClients > 0) {
          const changePercentage = ((currentPeriodClients - prevPeriodClients) / prevPeriodClients) * 100;
          clientsMonthlyChange = `${changePercentage.toFixed(1)}%`;
        } else if (currentPeriodClients > 0) {
          clientsMonthlyChange = '100%';
        }

        // Get total documents count
        const [documentsResult] = await db.select({
          count: sql<number>`count(*)`,
        }).from(documents);
        
        // Get documents in current period
        const [currentPeriodDocsResult] = await db.select({
          count: sql<number>`count(*)`,
        })
        .from(documents)
        .where(
          and(
            sql`${documents.createdAt} >= ${startDate.toISOString()}`,
            sql`${documents.createdAt} <= ${new Date().toISOString()}`
          )
        );
        
        // Get documents in previous period
        const [prevPeriodDocsResult] = await db.select({
          count: sql<number>`count(*)`,
        })
        .from(documents)
        .where(
          and(
            sql`${documents.createdAt} >= ${prevPeriodStartDate.toISOString()}`,
            sql`${documents.createdAt} < ${startDate.toISOString()}`
          )
        );
        
        // Calculate document change percentage
        const currentPeriodDocs = currentPeriodDocsResult.count || 0;
        const prevPeriodDocs = prevPeriodDocsResult.count || 0;
        let documentsMonthlyChange = '0%';
        
        if (prevPeriodDocs > 0) {
          const changePercentage = ((currentPeriodDocs - prevPeriodDocs) / prevPeriodDocs) * 100;
          documentsMonthlyChange = `${changePercentage.toFixed(1)}%`;
        } else if (currentPeriodDocs > 0) {
          documentsMonthlyChange = '100%';
        }
        
        // Get pending signatures count
        const [pendingSignaturesResult] = await db.select({
          count: sql<number>`count(*)`,
        })
        .from(signatureRequests)
        .where(eq(signatureRequests.status, 'Pending'));
        
        // Get completed signatures count
        const [completedSignaturesResult] = await db.select({
          count: sql<number>`count(*)`,
        })
        .from(signatureRequests)
        .where(eq(signatureRequests.status, 'Completed'));
        
        // Get signatures in current period
        const [currentPeriodSignaturesResult] = await db.select({
          count: sql<number>`count(*)`,
        })
        .from(signatureRequests)
        .where(
          and(
            sql`${signatureRequests.createdAt} >= ${startDate.toISOString()}`,
            sql`${signatureRequests.createdAt} <= ${new Date().toISOString()}`
          )
        );
        
        // Get signatures in previous period
        const [prevPeriodSignaturesResult] = await db.select({
          count: sql<number>`count(*)`,
        })
        .from(signatureRequests)
        .where(
          and(
            sql`${signatureRequests.createdAt} >= ${prevPeriodStartDate.toISOString()}`,
            sql`${signatureRequests.createdAt} < ${startDate.toISOString()}`
          )
        );
        
        // Calculate signature change percentage
        const currentPeriodSignatures = currentPeriodSignaturesResult.count || 0;
        const prevPeriodSignatures = prevPeriodSignaturesResult.count || 0;
        let signaturesMonthlyChange = '0%';
        
        if (prevPeriodSignatures > 0) {
          const changePercentage = ((currentPeriodSignatures - prevPeriodSignatures) / prevPeriodSignatures) * 100;
          signaturesMonthlyChange = `${changePercentage.toFixed(1)}%`;
        } else if (currentPeriodSignatures > 0) {
          signaturesMonthlyChange = '100%';
        }
        
        res.json({
          totalClients: clientsResult.count || 0,
          activeClients: activeClientsResult.count || 0,
          totalDocuments: documentsResult.count || 0,
          pendingSignatures: pendingSignaturesResult.count || 0,
          completedSignatures: completedSignaturesResult.count || 0,
          clientsMonthlyChange,
          documentsMonthlyChange,
          signaturesMonthlyChange
        });
      } catch (error) {
        console.error('Error fetching summary statistics:', error);
        res.status(500).json({ error: 'Failed to fetch summary statistics' });
      }
    }
  );
  
  // Client statistics
  app.get('/api/reports/clients',
    isAuthenticated,
    async (req, res) => {
      try {
        const timeRange = req.query.timeRange as string || '30d';
        let startDate = new Date();
        
        // Calculate start date based on time range
        switch (timeRange) {
          case '7d':
            startDate.setDate(startDate.getDate() - 7);
            break;
          case '30d':
            startDate.setDate(startDate.getDate() - 30);
            break;
          case '90d':
            startDate.setDate(startDate.getDate() - 90);
            break;
          case 'year':
            startDate.setFullYear(startDate.getFullYear() - 1);
            break;
          case 'all':
            startDate = new Date(0); // Beginning of time
            break;
          default:
            startDate.setDate(startDate.getDate() - 30);
        }
        
        // Calculate new vs returning clients
        // For simplicity, we'll count clients created in time range as "new"
        // and ones with activity (docs/matters) but created before as "returning"
        const [newClientsResult] = await db.select({
          count: sql<number>`count(*)`,
        })
        .from(clients)
        .where(
          and(
            sql`${clients.createdAt} >= ${startDate.toISOString()}`,
            sql`${clients.createdAt} <= ${new Date().toISOString()}`
          )
        );
        
        const [returningClientsResult] = await db.select({
          count: sql<number>`count(distinct ${clients.id})`,
        })
        .from(clients)
        .leftJoin(documents, eq(documents.clientId, clients.id))
        .leftJoin(matters, eq(matters.clientId, clients.id))
        .where(
          and(
            sql`${clients.createdAt} < ${startDate.toISOString()}`,
            or(
              and(
                sql`${documents.createdAt} >= ${startDate.toISOString()}`,
                sql`${documents.createdAt} <= ${new Date().toISOString()}`
              ),
              and(
                sql`${matters.createdAt} >= ${startDate.toISOString()}`,
                sql`${matters.createdAt} <= ${new Date().toISOString()}`
              )
            )
          )
        );
        
        // Count clients by type
        // This is a simplified example; adjust based on your actual client types
        const [businessClientsResult] = await db.select({
          count: sql<number>`count(*)`,
        })
        .from(clients)
        .where(sql`${clients.company} is not null`);
        
        const [totalClientsResult] = await db.select({
          count: sql<number>`count(*)`,
        }).from(clients);
        
        // Determine individual and other client counts
        const businessClients = businessClientsResult.count || 0;
        const totalClients = totalClientsResult.count || 0;
        const individualClients = totalClients - businessClients;
        
        // Generate monthly data (simplified)
        // In a real app, you would create a proper SQL query with date grouping
        const monthlyData = [];
        const today = new Date();
        
        for (let i = 5; i >= 0; i--) {
          const month = new Date(today.getFullYear(), today.getMonth() - i, 1);
          const monthName = month.toLocaleDateString('en-US', { month: 'short' });
          
          // This is simplified - in a real app, you'd query the DB for each month
          const count = Math.floor(Math.random() * 10) + 1; // Random count between 1-10
          
          monthlyData.push({
            month: monthName,
            count
          });
        }
        
        res.json({
          newClients: newClientsResult.count || 0,
          returningClients: returningClientsResult.count || 0,
          clientsByType: {
            individual: individualClients,
            business: businessClients,
            other: 0 // Example - adjust based on your data model
          },
          clientsByMonth: monthlyData
        });
      } catch (error) {
        console.error('Error fetching client statistics:', error);
        res.status(500).json({ error: 'Failed to fetch client statistics' });
      }
    }
  );
  
  // Document statistics
  app.get('/api/reports/documents',
    isAuthenticated,
    async (req, res) => {
      try {
        const timeRange = req.query.timeRange as string || '30d';
        let startDate = new Date();
        
        // Calculate start date based on time range
        switch (timeRange) {
          case '7d':
            startDate.setDate(startDate.getDate() - 7);
            break;
          case '30d':
            startDate.setDate(startDate.getDate() - 30);
            break;
          case '90d':
            startDate.setDate(startDate.getDate() - 90);
            break;
          case 'year':
            startDate.setFullYear(startDate.getFullYear() - 1);
            break;
          case 'all':
            startDate = new Date(0); // Beginning of time
            break;
          default:
            startDate.setDate(startDate.getDate() - 30);
        }
        
        // Get total documents
        const [totalDocumentsResult] = await db.select({
          count: sql<number>`count(*)`,
        }).from(documents);
        
        // Get documents requiring signature
        const [pendingDocumentsResult] = await db.select({
          count: sql<number>`count(distinct ${documents.id})`,
        })
        .from(documents)
        .leftJoin(signatureRequests, eq(signatureRequests.documentId, documents.id))
        .where(
          and(
            eq(documents.needsSignature, true),
            or(
              isNull(signatureRequests.id),
              eq(signatureRequests.status, 'Pending')
            )
          )
        );
        
        // Get documents that have been signed
        const [signedDocumentsResult] = await db.select({
          count: sql<number>`count(distinct ${documents.id})`,
        })
        .from(documents)
        .leftJoin(signatureRequests, eq(signatureRequests.documentId, documents.id))
        .where(
          and(
            eq(documents.needsSignature, true),
            eq(signatureRequests.status, 'Completed')
          )
        );
        
        // Generate monthly data (simplified)
        // In a real app, you would create a proper SQL query with date grouping
        const monthlyData = [];
        const today = new Date();
        
        for (let i = 5; i >= 0; i--) {
          const month = new Date(today.getFullYear(), today.getMonth() - i, 1);
          const monthName = month.toLocaleDateString('en-US', { month: 'short' });
          
          // This is simplified - in a real app, you'd query the DB for each month
          const uploaded = Math.floor(Math.random() * 15) + 5; // Random between 5-20
          const signed = Math.floor(Math.random() * uploaded); // Random up to uploaded
          
          monthlyData.push({
            month: monthName,
            uploaded,
            signed
          });
        }
        
        // Sample document types (simplified)
        // In a real app, you would query your database for actual document types
        const documentTypes = [
          { type: 'Contract', count: Math.floor(Math.random() * 20) + 10 },
          { type: 'Agreement', count: Math.floor(Math.random() * 15) + 5 },
          { type: 'Letter', count: Math.floor(Math.random() * 10) + 5 },
          { type: 'Form', count: Math.floor(Math.random() * 25) + 5 },
          { type: 'Other', count: Math.floor(Math.random() * 10) + 3 }
        ];
        
        res.json({
          totalUploaded: totalDocumentsResult.count || 0,
          totalPending: pendingDocumentsResult.count || 0,
          totalSigned: signedDocumentsResult.count || 0,
          documentsByMonth: monthlyData,
          documentsByType: documentTypes
        });
      } catch (error) {
        console.error('Error fetching document statistics:', error);
        res.status(500).json({ error: 'Failed to fetch document statistics' });
      }
    }
  );

  // Document Analysis
  app.post('/api/documents/:id/analyze',
    isAuthenticated,
    checkPermission(permissions.READ_DOCUMENT),
    async (req, res) => {
      try {
        const documentId = parseInt(req.params.id);
        if (isNaN(documentId)) {
          return res.status(400).json({ error: 'Invalid document ID' });
        }

        // Get document
        const document = await db.query.documents.findFirst({
          where: eq(documents.id, documentId),
        });

        if (!document) {
          return res.status(404).json({ error: 'Document not found' });
        }

        // For this endpoint, we'll need the document text
        // In a real application, this would read the file and extract text
        // Here, we'll use a simplified approach for demo purposes
        
        // Read file content (assuming text-based files)
        const filePath = path.join(process.cwd(), 'uploads', document.fileName || '');
        
        if (!fs.existsSync(filePath)) {
          return res.status(404).json({ error: 'Document file not found' });
        }
        
        let documentText;
        try {
          // Read the first 100KB of the file to avoid memory issues with large files
          const buffer = Buffer.alloc(102400); // 100KB buffer
          const fd = fs.openSync(filePath, 'r');
          fs.readSync(fd, buffer, 0, 102400, 0);
          fs.closeSync(fd);
          
          // Convert buffer to string and remove null bytes
          documentText = buffer.toString('utf8').replace(/\0/g, '');
        } catch (error) {
          console.error('Error reading document file:', error);
          return res.status(500).json({ error: 'Failed to read document file' });
        }
        
        // Determine document type from file extension
        const documentType = document.fileType || 'unknown';
        
        // Call OpenAI to analyze the document
        const analysis = await analyzeDocument(documentText, documentType);
        
        res.json(analysis);
      } catch (error) {
        console.error('Error analyzing document:', error);
        res.status(500).json({ error: 'Failed to analyze document' });
      }
    }
  );

  app.post('/api/documents/:id/extract-metadata',
    isAuthenticated,
    checkPermission(permissions.READ_DOCUMENT),
    async (req, res) => {
      try {
        const documentId = parseInt(req.params.id);
        if (isNaN(documentId)) {
          return res.status(400).json({ error: 'Invalid document ID' });
        }

        // Get document
        const document = await db.query.documents.findFirst({
          where: eq(documents.id, documentId),
        });

        if (!document) {
          return res.status(404).json({ error: 'Document not found' });
        }
        
        // Read file content
        const filePath = path.join(process.cwd(), 'uploads', document.fileName || '');
        
        if (!fs.existsSync(filePath)) {
          return res.status(404).json({ error: 'Document file not found' });
        }
        
        let documentText;
        try {
          // Read the first 100KB of the file
          const buffer = Buffer.alloc(102400); // 100KB buffer
          const fd = fs.openSync(filePath, 'r');
          fs.readSync(fd, buffer, 0, 102400, 0);
          fs.closeSync(fd);
          
          // Convert buffer to string and remove null bytes
          documentText = buffer.toString('utf8').replace(/\0/g, '');
        } catch (error) {
          console.error('Error reading document file:', error);
          return res.status(500).json({ error: 'Failed to read document file' });
        }
        
        // Extract metadata using OpenAI
        const metadata = await extractDocumentMetadata(documentText);
        
        res.json(metadata);
      } catch (error) {
        console.error('Error extracting document metadata:', error);
        res.status(500).json({ error: 'Failed to extract document metadata' });
      }
    }
  );

  app.post('/api/documents/:id/summarize',
    isAuthenticated,
    checkPermission(permissions.READ_DOCUMENT),
    async (req, res) => {
      try {
        const documentId = parseInt(req.params.id);
        const maxLength = req.body.maxLength || 250;
        
        if (isNaN(documentId)) {
          return res.status(400).json({ error: 'Invalid document ID' });
        }

        // Get document
        const document = await db.query.documents.findFirst({
          where: eq(documents.id, documentId),
        });

        if (!document) {
          return res.status(404).json({ error: 'Document not found' });
        }
        
        // Read file content
        const filePath = path.join(process.cwd(), 'uploads', document.fileName || '');
        
        if (!fs.existsSync(filePath)) {
          return res.status(404).json({ error: 'Document file not found' });
        }
        
        let documentText;
        try {
          // Read the first 100KB of the file
          const buffer = Buffer.alloc(102400); // 100KB buffer
          const fd = fs.openSync(filePath, 'r');
          fs.readSync(fd, buffer, 0, 102400, 0);
          fs.closeSync(fd);
          
          // Convert buffer to string and remove null bytes
          documentText = buffer.toString('utf8').replace(/\0/g, '');
        } catch (error) {
          console.error('Error reading document file:', error);
          return res.status(500).json({ error: 'Failed to read document file' });
        }
        
        // Summarize document using OpenAI
        const summary = await summarizeLegalDocument(documentText, maxLength);
        
        res.json({ summary });
      } catch (error) {
        console.error('Error summarizing document:', error);
        res.status(500).json({ error: 'Failed to summarize document' });
      }
    }
  );

  app.post('/api/documents/compare',
    isAuthenticated,
    checkPermission(permissions.READ_DOCUMENT),
    async (req, res) => {
      try {
        const { document1Id, document2Id } = req.body;
        
        if (!document1Id || !document2Id) {
          return res.status(400).json({ error: 'Both document IDs are required' });
        }
        
        // Get both documents
        const document1 = await db.query.documents.findFirst({
          where: eq(documents.id, document1Id),
        });
        
        const document2 = await db.query.documents.findFirst({
          where: eq(documents.id, document2Id),
        });
        
        if (!document1 || !document2) {
          return res.status(404).json({ error: 'One or both documents not found' });
        }
        
        // Read both document contents
        const filePath1 = path.join(process.cwd(), 'uploads', document1.fileName || '');
        const filePath2 = path.join(process.cwd(), 'uploads', document2.fileName || '');
        
        if (!fs.existsSync(filePath1) || !fs.existsSync(filePath2)) {
          return res.status(404).json({ error: 'One or both document files not found' });
        }
        
        let documentText1, documentText2;
        try {
          // Read the first 50KB of each file to stay within token limits
          const buffer1 = Buffer.alloc(51200); // 50KB buffer
          const fd1 = fs.openSync(filePath1, 'r');
          fs.readSync(fd1, buffer1, 0, 51200, 0);
          fs.closeSync(fd1);
          
          const buffer2 = Buffer.alloc(51200); // 50KB buffer
          const fd2 = fs.openSync(filePath2, 'r');
          fs.readSync(fd2, buffer2, 0, 51200, 0);
          fs.closeSync(fd2);
          
          // Convert buffer to string and remove null bytes
          documentText1 = buffer1.toString('utf8').replace(/\0/g, '');
          documentText2 = buffer2.toString('utf8').replace(/\0/g, '');
        } catch (error) {
          console.error('Error reading document files:', error);
          return res.status(500).json({ error: 'Failed to read document files' });
        }
        
        // Compare documents using OpenAI
        const comparison = await compareDocuments(documentText1, documentText2);
        
        res.json(comparison);
      } catch (error) {
        console.error('Error comparing documents:', error);
        res.status(500).json({ error: 'Failed to compare documents' });
      }
    }
  );

  // Create HTTP server
  const httpServer = createServer(app);
  
  return httpServer;
}