import OpenAI from "openai";

// Initialize the OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// The newest OpenAI model is "gpt-4o" which was released May 13, 2024. Do not change this unless explicitly requested by the user.
const MODEL = "gpt-4o";

export interface DocumentAnalysisResult {
  summary: string;
  keyPoints: string[];
  legalRisks: {
    risk: string;
    severity: 'low' | 'medium' | 'high';
    suggestion: string;
  }[];
  nextSteps: string[];
  relevantCaseLaw?: string[];
  confidenceScore: number;
}

export async function analyzeDocument(documentText: string, documentType: string): Promise<DocumentAnalysisResult> {
  try {
    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [
        {
          role: "system",
          content: `You are a legal document analysis assistant for a law firm. 
          Analyze the provided ${documentType} document and provide a structured analysis.
          Focus on identifying key legal terms, potential risks, and next steps.
          Be precise and comprehensive.`
        },
        {
          role: "user",
          content: documentText
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.1,
    });

    // Parse the JSON response
    const analysisText = response.choices[0].message.content;
    if (!analysisText) {
      throw new Error("Empty response from OpenAI");
    }

    const analysis = JSON.parse(analysisText) as DocumentAnalysisResult;
    return analysis;
  } catch (error) {
    console.error("Error analyzing document:", error);
    throw new Error(`Failed to analyze document: ${(error as Error).message}`);
  }
}

export async function extractDocumentMetadata(documentText: string): Promise<Record<string, any>> {
  try {
    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [
        {
          role: "system",
          content: `Extract key metadata from the provided legal document.
          Return a JSON object with the following fields (if present):
          - documentType: The type of legal document
          - parties: All parties involved in the document
          - effectiveDate: When the document becomes effective
          - expirationDate: When the document expires (if applicable)
          - jurisdiction: Legal jurisdiction that applies
          - governingLaw: What laws govern this document
          - keyProvisions: Array of important provisions
          
          Only include fields if the information is explicitly present in the document.`
        },
        {
          role: "user",
          content: documentText
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.1,
    });

    // Parse the JSON response
    const metadataText = response.choices[0].message.content;
    if (!metadataText) {
      throw new Error("Empty response from OpenAI");
    }

    return JSON.parse(metadataText);
  } catch (error) {
    console.error("Error extracting document metadata:", error);
    throw new Error(`Failed to extract document metadata: ${(error as Error).message}`);
  }
}

export async function summarizeLegalDocument(documentText: string, maxLength: number = 250): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [
        {
          role: "system",
          content: `Create a concise summary of this legal document in ${maxLength} characters or less.
          Focus on the most important legal implications and key details.`
        },
        {
          role: "user",
          content: documentText
        }
      ],
      max_tokens: Math.ceil(maxLength / 4), // Approximate tokens based on characters
      temperature: 0.3,
    });

    return response.choices[0].message.content || "Error: No summary generated";
  } catch (error) {
    console.error("Error summarizing document:", error);
    throw new Error(`Failed to summarize document: ${(error as Error).message}`);
  }
}

export async function compareDocuments(document1: string, document2: string): Promise<{
  similarities: string[];
  differences: string[];
  recommendations: string[];
}> {
  try {
    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [
        {
          role: "system",
          content: `Compare these two legal documents and identify key similarities and differences.
          Focus on legally significant elements, not superficial or formatting differences.
          Provide specific recommendations based on the comparison.
          Return as JSON with three arrays: similarities, differences, and recommendations.`
        },
        {
          role: "user",
          content: `Document 1: 
          ${document1}
          
          Document 2:
          ${document2}`
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.2,
    });

    // Parse the JSON response
    const comparisonText = response.choices[0].message.content;
    if (!comparisonText) {
      throw new Error("Empty response from OpenAI");
    }

    return JSON.parse(comparisonText) as {
      similarities: string[];
      differences: string[];
      recommendations: string[];
    };
  } catch (error) {
    console.error("Error comparing documents:", error);
    throw new Error(`Failed to compare documents: ${(error as Error).message}`);
  }
}