import express from 'express';
import { registerRoutes } from './routes';
import dotenv from 'dotenv';
import path from 'path';

// Load environment variables
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Register API routes
const httpServer = registerRoutes(app);

// Start server
httpServer.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});