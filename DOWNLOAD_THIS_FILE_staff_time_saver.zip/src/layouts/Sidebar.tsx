import { useTranslation } from 'react-i18next';
import { useLocation, Link } from 'wouter';
import {
  LayoutDashboard,
  Users,
  FileText,
  Calendar,
  CheckSquare,
  Settings,
  LogOut,
  X,
  Pen,
  BarChart3,
  PlusCircle,
  Briefcase,
} from 'lucide-react';
import { Button } from '../components/ui/button';
import { cn } from '../lib/utils';
import { useAuth } from '../hooks/use-auth';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

interface NavItem {
  icon: React.FC<{ className?: string }>;
  label: string;
  path: string;
  translationKey: string;
  category?: string;
}

interface NavCategory {
  name: string;
  translationKey: string;
  items: NavItem[];
}

export const Sidebar: React.FC<{ 
  isSidebarOpen: boolean; 
  toggleSidebar: () => void;
}> = ({ isSidebarOpen, toggleSidebar }) => {
  const { t } = useTranslation();
  const [location] = useLocation();
  const { logoutMutation, user } = useAuth();
  
  // Build the navigation structure
  const navCategories: NavCategory[] = [
    {
      name: 'Main',
      translationKey: 'sidebar.categories.main',
      items: [
        {
          icon: LayoutDashboard,
          label: 'Dashboard',
          path: '/dashboard',
          translationKey: 'common.dashboard',
        },
      ]
    },
    {
      name: 'Client Management',
      translationKey: 'sidebar.categories.clientManagement',
      items: [
        {
          icon: Users,
          label: 'Clients',
          path: '/clients',
          translationKey: 'common.clients',
        },
        {
          icon: Briefcase,
          label: 'Matters',
          path: '/matters',
          translationKey: 'common.matters',
        },
      ]
    },
    {
      name: 'Documents',
      translationKey: 'sidebar.categories.documents',
      items: [
        {
          icon: FileText,
          label: 'Documents',
          path: '/documents',
          translationKey: 'common.documents',
        },
        {
          icon: Pen,
          label: 'Signatures',
          path: '/signatures',
          translationKey: 'common.signatures',
        },
      ]
    },
    {
      name: 'Productivity',
      translationKey: 'sidebar.categories.productivity',
      items: [
        {
          icon: Calendar,
          label: 'Calendar',
          path: '/calendar',
          translationKey: 'common.calendar',
        },
        {
          icon: CheckSquare,
          label: 'Tasks',
          path: '/tasks',
          translationKey: 'common.tasks',
        },
      ]
    },
    {
      name: 'Reports',
      translationKey: 'sidebar.categories.reports',
      items: [
        {
          icon: BarChart3,
          label: 'Reports',
          path: '/reports',
          translationKey: 'common.reports',
        },
      ]
    },
    {
      name: 'Settings',
      translationKey: 'sidebar.categories.settings',
      items: [
        {
          icon: Settings,
          label: 'Settings',
          path: '/settings',
          translationKey: 'common.settings',
        },
      ]
    },
  ];

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <div className="h-full w-full flex flex-col overflow-hidden">
      {/* Logo */}
      <div className="flex h-16 items-center justify-between px-4 shrink-0">
        <h1 className="text-xl font-bold text-gray-800 dark:text-white">Staff Time Saver</h1>
        <button
          onClick={toggleSidebar}
          className="rounded-md p-1 text-gray-500 hover:bg-gray-100 hover:text-gray-900 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white md:hidden"
        >
          <X className="h-6 w-6" />
        </button>
      </div>

      {/* User Profile Summary */}
      {user && (
        <div className="px-4 py-3 mb-2 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-500 text-sm font-medium text-white">
              {user.firstName?.charAt(0)}{user.lastName?.charAt(0)}
            </div>
            <div className="truncate">
              <p className="text-sm font-medium text-gray-800 dark:text-white truncate">
                {user.firstName} {user.lastName}
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-400 capitalize truncate">
                {user.role || 'staff'}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto px-2 py-1">
        <TooltipProvider>
          {navCategories.map((category, index) => (
            <div key={category.name} className={index > 0 ? 'mt-6' : ''}>
              <h3 className="px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                {t(category.translationKey) || category.name}
              </h3>
              <div className="mt-2 space-y-1">
                {category.items.map((item) => {
                  const isActive = location === item.path;
                  
                  return (
                    <Tooltip key={item.path}>
                      <TooltipTrigger asChild>
                        <Link href={item.path}>
                          <a className={cn(
                            'group flex items-center rounded-md px-3 py-2 text-sm font-medium transition-colors',
                            isActive
                              ? 'bg-blue-100 text-blue-600 dark:bg-blue-900/50 dark:text-blue-200'
                              : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900 dark:text-gray-300 dark:hover:bg-gray-700 dark:hover:text-white'
                          )}>
                            <item.icon className="mr-3 h-5 w-5 flex-shrink-0" />
                            <span>{t(item.translationKey) || item.label}</span>
                          </a>
                        </Link>
                      </TooltipTrigger>
                      <TooltipContent side="right" sideOffset={10}>
                        {t(item.translationKey) || item.label}
                      </TooltipContent>
                    </Tooltip>
                  );
                })}
              </div>
            </div>
          ))}
        </TooltipProvider>
      </nav>

      {/* Quick actions */}
      <div className="border-t border-gray-200 dark:border-gray-700 p-2">
        <TooltipProvider>
          <div className="flex justify-center space-x-1">
            <Tooltip>
              <TooltipTrigger asChild>
                <Link href="/clients/new">
                  <a className="inline-flex items-center justify-center h-8 w-8 rounded-full bg-gray-100 text-gray-700 hover:bg-blue-100 hover:text-blue-600 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-blue-900/50 dark:hover:text-blue-200">
                    <PlusCircle className="h-4 w-4" />
                  </a>
                </Link>
              </TooltipTrigger>
              <TooltipContent side="top" sideOffset={5}>
                {t('actions.newClient')}
              </TooltipContent>
            </Tooltip>
          </div>
        </TooltipProvider>
      </div>

      {/* Logout button */}
      <div className="border-t border-gray-200 p-4 dark:border-gray-700 shrink-0">
        <Button
          variant="outline"
          className="w-full justify-start text-gray-600 dark:text-gray-400"
          onClick={handleLogout}
        >
          <LogOut className="mr-3 h-5 w-5" />
          {t('common.logout')}
        </Button>
      </div>
    </div>
  );
};