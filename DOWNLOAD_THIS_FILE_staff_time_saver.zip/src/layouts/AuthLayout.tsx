import React from 'react';
import { useTranslation } from 'react-i18next';
import { LanguageSelector } from '../components/ui/language-selector';

interface AuthLayoutProps {
  children: React.ReactNode;
}

export const AuthLayout: React.FC<AuthLayoutProps> = ({ children }) => {
  const { t } = useTranslation();

  return (
    <div className="flex min-h-screen flex-col md:flex-row">
      {/* Left side: Auth form */}
      <div className="flex w-full flex-col justify-center p-6 md:w-1/2 md:p-10">
        <div className="absolute top-6 right-6">
          <LanguageSelector />
        </div>
        <div className="mx-auto w-full max-w-md">
          <div className="mb-6">
            <h1 className="text-4xl font-bold tracking-tight text-gray-900 dark:text-white">
              Staff Time Saver
            </h1>
            <p className="mt-2 text-lg text-gray-600 dark:text-gray-400">
              {t('common.welcomeMessage')}
            </p>
          </div>
          {children}
        </div>
      </div>

      {/* Right side: Hero section */}
      <div className="hidden bg-gradient-to-br from-blue-500 to-indigo-700 p-10 md:flex md:w-1/2 md:flex-col md:justify-center">
        <div className="mx-auto max-w-md">
          <h2 className="text-3xl font-bold text-white">
            Streamline Your Legal Workflow
          </h2>
          <p className="mt-4 text-lg text-blue-100">
            Staff Time Saver helps legal professionals manage client information, track time,
            and analyze documents efficiently - all in one platform.
          </p>
          <ul className="mt-8 space-y-4">
            {[
              'Automated client intake process',
              'Secure document management',
              'Intelligent form generation',
              'Advanced document analysis',
              'AI-powered legal research',
            ].map((feature, index) => (
              <li key={index} className="flex items-center text-blue-100">
                <svg
                  className="mr-2 h-5 w-5 text-blue-200"
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 20 20"
                  fill="currentColor"
                >
                  <path
                    fillRule="evenodd"
                    d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                    clipRule="evenodd"
                  />
                </svg>
                {feature}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};