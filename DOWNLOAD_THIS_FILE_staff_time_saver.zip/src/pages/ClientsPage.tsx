import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { UserPlus, Users } from 'lucide-react';
import { MainLayout } from '../layouts/MainLayout';
import { ClientList } from '../components/ClientList';
import { ClientDetail } from '../components/ClientDetail';
import { ClientIntakeForm } from '../components/ClientIntakeForm';

enum ClientsView {
  LIST = 'list',
  DETAIL = 'detail',
  CREATE = 'create',
  EDIT = 'edit',
}

export default function ClientsPage() {
  const { t } = useTranslation();
  const [view, setView] = useState<ClientsView>(ClientsView.LIST);
  const [selectedClientId, setSelectedClientId] = useState<number | null>(null);
  
  const handleViewClient = (id: number) => {
    setSelectedClientId(id);
    setView(ClientsView.DETAIL);
  };
  
  const handleNewClient = () => {
    setView(ClientsView.CREATE);
  };
  
  const handleEditClient = (id: number) => {
    setSelectedClientId(id);
    setView(ClientsView.EDIT);
  };
  
  const handleBackToList = () => {
    setView(ClientsView.LIST);
    setSelectedClientId(null);
  };
  
  // Render the appropriate view
  const renderContent = () => {
    switch (view) {
      case ClientsView.DETAIL:
        return (
          <ClientDetail
            clientId={selectedClientId!}
            onBack={handleBackToList}
            onEdit={handleEditClient}
          />
        );
      case ClientsView.CREATE:
        return (
          <div>
            <div className="flex items-center mb-6">
              <button
                onClick={handleBackToList}
                className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300 mr-3"
              >
                ← {t('common.back')}
              </button>
              <h1 className="text-2xl font-bold">{t('clients.newClient')}</h1>
            </div>
            <ClientIntakeForm />
          </div>
        );
      case ClientsView.EDIT:
        return (
          <div>
            <div className="flex items-center mb-6">
              <button
                onClick={() => {
                  setView(ClientsView.DETAIL);
                }}
                className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300 mr-3"
              >
                ← {t('common.back')}
              </button>
              <h1 className="text-2xl font-bold">{t('clients.editClient')}</h1>
            </div>
            {/* TODO: Implement edit form */}
            <p className="text-gray-500">Edit form will be implemented in a future update.</p>
          </div>
        );
      case ClientsView.LIST:
      default:
        return (
          <>
            <div className="flex justify-between items-center mb-6">
              <h1 className="text-2xl font-bold flex items-center">
                <Users className="h-6 w-6 mr-2" />
                {t('common.clients')}
              </h1>
              <button
                onClick={handleNewClient}
                className="flex items-center bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md"
              >
                <UserPlus className="h-4 w-4 mr-2" />
                {t('clients.newClient')}
              </button>
            </div>
            <ClientList onViewClient={handleViewClient} onNewClient={handleNewClient} />
          </>
        );
    }
  };
  
  return (
    <MainLayout>
      <div className="container mx-auto py-6 px-4 max-w-7xl">
        {renderContent()}
      </div>
    </MainLayout>
  );
}