import React from 'react';
import { useTranslation } from 'react-i18next';
import { DocumentAnalyzer } from '@/components/document/DocumentAnalyzer';
import { check } from '@/lib/check-secrets';

export default function DocumentAnalysisPage() {
  const { t } = useTranslation();
  const hasOpenAiKey = check('OPENAI_API_KEY');

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">{t('documents.analysisPageTitle')}</h1>
      
      {hasOpenAiKey ? (
        <DocumentAnalyzer />
      ) : (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 text-center">
          <h2 className="text-xl font-semibold text-yellow-700 mb-3">
            {t('documents.apiKeyMissing')}
          </h2>
          <p className="text-yellow-600 mb-4">
            {t('documents.apiKeyInstructions')}
          </p>
        </div>
      )}
    </div>
  );
}