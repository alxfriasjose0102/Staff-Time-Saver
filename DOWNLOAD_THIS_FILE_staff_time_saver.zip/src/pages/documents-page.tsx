import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useQuery, useMutation } from '@tanstack/react-query';
import { 
  Plus,
  Search,
  FileText,
  Upload,
  Filter,
  ArrowUpDown,
  MoreHorizontal,
  RefreshCcw,
  ChevronDown,
  Download
} from 'lucide-react';
import { MainLayout } from '@/layouts/MainLayout';
import { DocumentAnalysis } from '@/components/documents/DocumentAnalysis';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';

interface Document {
  id: number;
  title: string;
  content?: string;
  fileName?: string;
  fileUrl?: string;
  fileType?: string;
  fileSize?: number;
  status?: string;
  createdAt: string;
  updatedAt: string;
}

// Mock documents list for demonstration
const mockDocuments: Document[] = [
  {
    id: 1,
    title: 'Sale Agreement - 123 Main St',
    status: 'analyzed',
    fileType: 'pdf',
    fileName: 'sale_agreement_123_main.pdf',
    content: 'This SALE AGREEMENT is made and entered into this 20th day of April, 2025, by and between ABC Properties LLC ("Seller") and John Smith ("Buyer")...',
    createdAt: '2025-04-20T14:30:00Z',
    updatedAt: '2025-04-21T09:15:00Z'
  },
  {
    id: 2,
    title: 'Lease Agreement - 456 Oak Ave',
    status: 'pending',
    fileType: 'docx',
    fileName: 'lease_agreement_456_oak.docx',
    content: 'RESIDENTIAL LEASE AGREEMENT. This Lease Agreement ("Lease") is entered into this 25th day of April, 2025, by and between Oak Property Management ("Landlord") and Jane Doe ("Tenant")...',
    createdAt: '2025-04-25T11:45:00Z',
    updatedAt: '2025-04-25T11:45:00Z'
  },
  {
    id: 3,
    title: 'Employment Contract - Acme Corp',
    status: 'uploaded',
    fileType: 'txt',
    fileName: 'acme_employment_contract.txt',
    content: 'EMPLOYMENT AGREEMENT. This Employment Agreement is made and effective as of April 18, 2025, by and between Acme Corporation ("Employer") and Robert Johnson ("Employee")...',
    createdAt: '2025-04-18T09:30:00Z',
    updatedAt: '2025-04-18T09:30:00Z'
  },
  {
    id: 4,
    title: 'Power of Attorney - Medical',
    status: 'uploaded',
    fileType: 'pdf',
    fileName: 'medical_power_of_attorney.pdf',
    content: 'MEDICAL POWER OF ATTORNEY. I, Sarah Williams, residing at 789 Pine Street, hereby appoint Michael Williams as my agent to make healthcare decisions for me when I cannot make those decisions myself...',
    createdAt: '2025-05-01T10:20:00Z',
    updatedAt: '2025-05-01T10:20:00Z'
  }
];

export default function DocumentsPage() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [newDocumentTitle, setNewDocumentTitle] = useState('');
  const [newDocumentContent, setNewDocumentContent] = useState('');
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null);
  const [activeTab, setActiveTab] = useState('documents');
  
  // This would fetch documents from API in a real implementation
  const { data: documents, isLoading, refetch } = useQuery({
    queryKey: ['/api/documents'],
    queryFn: async () => {
      // In a real implementation, this would be an API call
      return mockDocuments;
    }
  });

  // Filter documents based on search query
  const filteredDocuments = documents?.filter(doc => 
    doc.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleCreateDocument = () => {
    if (!newDocumentTitle.trim() || !newDocumentContent.trim()) {
      toast({
        title: t('common.error'),
        description: t('documents.emptyTitleOrContent'),
        variant: 'destructive',
      });
      return;
    }

    // In a real implementation, this would be a mutation to create the document
    const newDocument: Document = {
      id: Math.floor(Math.random() * 1000),
      title: newDocumentTitle,
      content: newDocumentContent,
      status: 'uploaded',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    // Reset form and close dialog
    setNewDocumentTitle('');
    setNewDocumentContent('');
    setIsCreateDialogOpen(false);
    
    // Show success message
    toast({
      title: t('documents.documentCreated'),
      description: t('documents.documentCreatedDescription'),
    });
    
    // Refetch documents to show the new one
    refetch();
  };

  const handleSelectDocument = (document: Document) => {
    setSelectedDocument(document);
    // Switch to the analyze tab automatically
    setActiveTab('analyze');
    
    // Show notification for document analysis
    toast({
      title: t('documents.analyzingDocument'),
      description: t('documents.preparingAnalysis'),
    });
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    }).format(date);
  };
  
  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
    return (bytes / (1024 * 1024 * 1024)).toFixed(1) + ' GB';
  };

  const getStatusColor = (status?: string) => {
    switch (status) {
      case 'analyzed':
        return 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300';
      default:
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300';
    }
  };

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">{t('documents.title')}</h1>
            <p className="text-muted-foreground">{t('documents.description')}</p>
          </div>
          <div className="flex items-center gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline">
                  <Upload className="mr-2 h-4 w-4" />
                  {t('documents.upload')}
                  <ChevronDown className="ml-2 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuItem onClick={() => setIsCreateDialogOpen(true)}>
                  <Plus className="mr-2 h-4 w-4" />
                  <span>{t('documents.createNew')}</span>
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <label htmlFor="bulk-upload" className="flex items-center cursor-pointer w-full">
                    <FileText className="mr-2 h-4 w-4" />
                    <span>{t('documents.bulkUpload')}</span>
                  </label>
                  <input 
                    id="bulk-upload" 
                    type="file" 
                    className="hidden" 
                    accept=".pdf,.docx,.txt" 
                    multiple
                    onChange={(e) => {
                      const files = e.target.files;
                      if (!files || files.length === 0) return;
                      
                      // Handle multiple files
                      let validFiles = 0;
                      const maxSize = 10 * 1024 * 1024; // 10MB in bytes
                      
                      Array.from(files).forEach(file => {
                        // Check file size
                        if (file.size > maxSize) {
                          toast({
                            title: t('documents.fileUploadError'),
                            description: `${file.name}: ${t('documents.fileTooBig')}`,
                            variant: 'destructive',
                          });
                          return;
                        }
                        
                        // Mock creating document entry
                        // In a real app, these would be uploaded to the server
                        validFiles++;
                      });
                      
                      // Show success message
                      if (validFiles > 0) {
                        toast({
                          title: t('documents.bulkUploadSuccess'),
                          description: t('documents.bulkUploadCount', { count: validFiles }),
                        });
                        
                        // Refresh documents in a real implementation
                        refetch();
                      }
                    }}
                  />
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => window.open('https://docs.example.com/document-templates', '_blank')}>
                  <Download className="mr-2 h-4 w-4" />
                  <span>{t('documents.downloadTemplates')}</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  {t('documents.createNew')}
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[640px]">
                <DialogHeader>
                  <DialogTitle>{t('documents.createNew')}</DialogTitle>
                  <DialogDescription>
                    {t('documents.pasteContent')}
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">{t('common.title')}</Label>
                    <Input
                      id="title"
                      value={newDocumentTitle}
                      onChange={(e) => setNewDocumentTitle(e.target.value)}
                      placeholder={t('documents.untitledDocument')}
                    />
                  </div>
                  <div className="space-y-2">
                    <div className="grid grid-cols-1 gap-4">
                      <div>
                        <Label htmlFor="content">{t('common.content')}</Label>
                        <Textarea
                          id="content"
                          value={newDocumentContent}
                          onChange={(e) => setNewDocumentContent(e.target.value)}
                          placeholder={t('documents.documentPlaceholder')}
                          className="min-h-[200px]"
                        />
                      </div>
                      <div className="text-center">
                        <Label className="block mb-2">{t('common.or')}</Label>
                        <div className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-6 text-center hover:border-primary transition-colors">
                          <Upload className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                          <Label htmlFor="file-upload" className="cursor-pointer block">
                            <span className="text-primary font-medium">{t('documents.uploadFile')}</span>
                            <span className="text-gray-500 dark:text-gray-400 text-sm block mt-1">
                              {t('documents.supportedFormats')}
                            </span>
                            <input 
                              id="file-upload" 
                              type="file" 
                              className="hidden" 
                              accept=".pdf,.docx,.txt"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (!file) return;
                                
                                // Check file size (max 10MB)
                                const maxSize = 10 * 1024 * 1024; // 10MB in bytes
                                if (file.size > maxSize) {
                                  toast({
                                    title: t('documents.fileUploadError'),
                                    description: t('documents.fileTooBig'),
                                    variant: 'destructive',
                                  });
                                  return;
                                }
                                
                                // Check file type
                                const validTypes = ['text/plain', 'application/pdf', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
                                if (!validTypes.includes(file.type) && 
                                    !file.name.endsWith('.pdf') && 
                                    !file.name.endsWith('.docx') && 
                                    !file.name.endsWith('.txt')) {
                                  toast({
                                    title: t('documents.fileUploadError'),
                                    description: t('documents.unsupportedFileType'),
                                    variant: 'destructive',
                                  });
                                  return;
                                }
                                
                                // Set document title to filename if not set
                                if (!newDocumentTitle) {
                                  setNewDocumentTitle(file.name.split('.')[0]);
                                }
                                
                                // Process based on file type
                                if (file.type === 'text/plain' || file.name.endsWith('.txt')) {
                                  toast({
                                    title: t('documents.processingFile'),
                                    description: t('documents.extractingText'),
                                  });
                                  
                                  const reader = new FileReader();
                                  reader.onload = (event) => {
                                    setNewDocumentContent(event.target?.result as string || '');
                                    
                                    toast({
                                      title: t('documents.fileUploaded'),
                                      description: file.name,
                                    });
                                  };
                                  reader.onerror = () => {
                                    toast({
                                      title: t('documents.fileUploadError'),
                                      description: t('documents.unknownError'),
                                      variant: 'destructive',
                                    });
                                  };
                                  reader.readAsText(file);
                                } else {
                                  // For PDFs and DOCXs, we'd need server-side processing
                                  // but for now, just indicate file was selected
                                  setNewDocumentContent(`[File uploaded: ${file.name}]`);
                                  
                                  toast({
                                    title: t('documents.fileUploaded'),
                                    description: file.name,
                                  });
                                }
                              }}
                            />
                          </Label>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                    {t('common.cancel')}
                  </Button>
                  <Button onClick={handleCreateDocument}>
                    {t('common.create')}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500 dark:text-gray-400" />
            <Input
              type="search"
              placeholder={t('documents.search')}
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Button variant="outline" size="icon" title={t('common.refresh')} onClick={() => refetch()}>
            <RefreshCcw className="h-4 w-4" />
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon" title={t('common.filter')}>
                <Filter className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>{t('common.filter')}</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem>{t('documents.analyzed')}</DropdownMenuItem>
              <DropdownMenuItem>{t('documents.pending')}</DropdownMenuItem>
              <DropdownMenuItem>{t('documents.uploaded')}</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon" title={t('common.sort')}>
                <ArrowUpDown className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>{t('common.sort')}</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem>{t('common.newestFirst')}</DropdownMenuItem>
              <DropdownMenuItem>{t('common.oldestFirst')}</DropdownMenuItem>
              <DropdownMenuItem>{t('common.alphabetical')}</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} defaultValue="list" className="w-full">
          <TabsList>
            <TabsTrigger value="list" onClick={() => setActiveTab("list")}>{t('documents.list')}</TabsTrigger>
            {selectedDocument && (
              <TabsTrigger value="analyze" onClick={() => setActiveTab("analyze")}>{t('documents.analyze')}</TabsTrigger>
            )}
          </TabsList>
          
          <TabsContent value="list" className="space-y-4">
            {isLoading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
              </div>
            ) : filteredDocuments && filteredDocuments.length > 0 ? (
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {filteredDocuments.map((doc) => (
                  <Card key={doc.id} className="overflow-hidden">
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <CardTitle className="truncate text-lg">{doc.title}</CardTitle>
                        <span className={`px-2 py-0.5 rounded-full text-xs ${getStatusColor(doc.status)}`}>
                          {doc.status}
                        </span>
                      </div>
                      <CardDescription className="flex flex-col gap-1">
                        <div className="flex justify-between items-center">
                          <span className="text-xs">{formatDate(doc.createdAt)}</span>
                          <span className="text-xs flex items-center gap-1">
                            {doc.fileType && (
                              <span className="uppercase font-mono bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded text-[10px] flex items-center">
                                {doc.fileType === 'pdf' && <FileText className="h-3 w-3 mr-1 text-red-500" />}
                                {doc.fileType === 'docx' && <FileText className="h-3 w-3 mr-1 text-blue-500" />}
                                {doc.fileType === 'doc' && <FileText className="h-3 w-3 mr-1 text-blue-400" />}
                                {doc.fileType === 'txt' && <FileText className="h-3 w-3 mr-1 text-gray-500" />}
                                {doc.fileType === 'rtf' && <FileText className="h-3 w-3 mr-1 text-green-500" />}
                                {doc.fileType === 'xlsx' && <FileText className="h-3 w-3 mr-1 text-green-600" />}
                                {doc.fileType === 'pptx' && <FileText className="h-3 w-3 mr-1 text-orange-500" />}
                                {doc.fileType === 'html' && <FileText className="h-3 w-3 mr-1 text-purple-500" />}
                                {doc.fileType === 'jpg' && <FileText className="h-3 w-3 mr-1 text-blue-400" />}
                                {doc.fileType === 'png' && <FileText className="h-3 w-3 mr-1 text-blue-500" />}
                                {doc.fileType === 'gif' && <FileText className="h-3 w-3 mr-1 text-pink-500" />}
                                {(['pdf', 'docx', 'doc', 'txt', 'rtf', 'xlsx', 'pptx', 'html', 'jpg', 'png', 'gif'].indexOf(doc.fileType) === -1) && 
                                  <FileText className="h-3 w-3 mr-1 text-gray-400" />}
                                {doc.fileType}
                                {doc.fileSize && (
                                  <span className="ml-1 text-[9px] opacity-70">
                                    ({formatFileSize(doc.fileSize)})
                                  </span>
                                )}
                              </span>
                            )}
                          </span>
                        </div>
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="pb-2">
                      <div className="h-24 overflow-hidden text-sm text-muted-foreground">
                        {doc.content || t('documents.noContentPreview')}
                      </div>
                      {doc.fileName && (
                        <div className="flex items-center text-xs text-muted-foreground mt-2 border-t pt-2">
                          <FileText className="h-3 w-3 mr-1" />
                          <span className="truncate">{doc.fileName}</span>
                        </div>
                      )}
                    </CardContent>
                    <CardFooter className="pt-0 flex justify-between">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleSelectDocument(doc)}
                      >
                        <FileText className="mr-2 h-4 w-4" />
                        {t('documents.analyze')}
                      </Button>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>{t('common.edit')}</DropdownMenuItem>
                          <DropdownMenuItem>{t('common.share')}</DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-destructive">
                            {t('common.delete')}
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="p-8 text-center">
                <div className="mx-auto mb-4 rounded-full bg-primary/10 p-3 w-fit">
                  <Upload className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="mb-2">{t('documents.noDocumentsTitle')}</CardTitle>
                <CardDescription className="mb-4">
                  {t('documents.noDocumentsDescription')}
                </CardDescription>
                <Button onClick={() => setIsCreateDialogOpen(true)}>
                  {t('documents.uploadFirst')}
                </Button>
              </Card>
            )}
          </TabsContent>
          
          {selectedDocument && (
            <TabsContent value="analyze">
              <Alert className="mb-4">
                <FileText className="h-4 w-4" />
                <AlertTitle>{selectedDocument.title}</AlertTitle>
                <AlertDescription>
                  {t('documents.analyze')}
                </AlertDescription>
              </Alert>
              <DocumentAnalysis 
                document={selectedDocument} 
                onAnalysisComplete={(result, metadata) => {
                  console.log('Analysis complete:', result, metadata);
                  // In a real implementation, we would save the analysis results to the server
                  
                  // Show a success toast with more details
                  toast({
                    title: t('documents.analysisComplete'),
                    description: t('documents.analysisStats', {
                      risks: result.legalRisks.length,
                      confidence: Math.round(result.confidenceScore * 100)
                    }),
                    variant: 'default'
                  });
                  
                  // The DocumentAnalysis component will automatically switch to the results tab
                  // when analysis is complete, so we don't need to do anything here
                }} 
              />
            </TabsContent>
          )}
        </Tabs>
      </div>
    </MainLayout>
  );
}