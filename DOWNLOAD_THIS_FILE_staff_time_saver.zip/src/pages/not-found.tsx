import React from 'react';
import { Link } from 'wouter';
import { useTranslation } from 'react-i18next';

const NotFound: React.FC = () => {
  const { t } = useTranslation();
  
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-gray-50 dark:bg-gray-900">
      <div className="max-w-md mx-auto text-center">
        <h1 className="text-9xl font-bold text-primary">404</h1>
        <h2 className="text-2xl font-semibold mt-4 mb-2">
          {t('notFound.title') || "Page Not Found"}
        </h2>
        <p className="text-gray-600 dark:text-gray-400 mb-8">
          {t('notFound.description') || "The page you are looking for doesn't exist or has been moved."}
        </p>
        <Link href="/">
          <a className="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-white bg-primary hover:bg-primary/90">
            {t('notFound.backToHome') || "Back to Home"}
          </a>
        </Link>
      </div>
    </div>
  );
};

export default NotFound;