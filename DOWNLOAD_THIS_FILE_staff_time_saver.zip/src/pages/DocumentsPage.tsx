import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { FileText, Upload } from 'lucide-react';
import { MainLayout } from '../layouts/MainLayout';
import { DocumentList } from '../components/DocumentList';
import { DocumentDetail } from '../components/DocumentDetail';
import { DocumentUploadForm } from '../components/DocumentUploadForm';

enum DocumentsView {
  LIST = 'list',
  DETAIL = 'detail',
  UPLOAD = 'upload',
  EDIT = 'edit',
  REQUEST_SIGNATURE = 'request_signature',
}

export default function DocumentsPage() {
  const { t } = useTranslation();
  const [view, setView] = useState<DocumentsView>(DocumentsView.LIST);
  const [selectedDocumentId, setSelectedDocumentId] = useState<number | null>(null);
  
  const handleViewDocument = (id: number) => {
    setSelectedDocumentId(id);
    setView(DocumentsView.DETAIL);
  };
  
  const handleUploadDocument = () => {
    setView(DocumentsView.UPLOAD);
  };
  
  const handleEditDocument = (id: number) => {
    setSelectedDocumentId(id);
    setView(DocumentsView.EDIT);
  };
  
  const handleRequestSignature = (id: number) => {
    setSelectedDocumentId(id);
    setView(DocumentsView.REQUEST_SIGNATURE);
  };
  
  const handleBackToList = () => {
    setView(DocumentsView.LIST);
    setSelectedDocumentId(null);
  };
  
  const handleUploadSuccess = () => {
    setView(DocumentsView.LIST);
  };
  
  // Render the appropriate view
  const renderContent = () => {
    switch (view) {
      case DocumentsView.DETAIL:
        return (
          <DocumentDetail
            documentId={selectedDocumentId!}
            onBack={handleBackToList}
            onEdit={handleEditDocument}
            onRequestSignature={handleRequestSignature}
          />
        );
      case DocumentsView.UPLOAD:
        return (
          <div>
            <div className="flex items-center mb-6">
              <button
                onClick={handleBackToList}
                className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300 mr-3"
              >
                ← {t('common.back')}
              </button>
              <h1 className="text-2xl font-bold">{t('documents.uploadDocument')}</h1>
            </div>
            <DocumentUploadForm onCancel={handleBackToList} onSuccess={handleUploadSuccess} />
          </div>
        );
      case DocumentsView.EDIT:
        return (
          <div>
            <div className="flex items-center mb-6">
              <button
                onClick={() => {
                  setView(DocumentsView.DETAIL);
                }}
                className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300 mr-3"
              >
                ← {t('common.back')}
              </button>
              <h1 className="text-2xl font-bold">{t('documents.editDocument')}</h1>
            </div>
            {/* For now, we'll reuse the upload form for edit */}
            <DocumentUploadForm onCancel={() => setView(DocumentsView.DETAIL)} onSuccess={() => setView(DocumentsView.DETAIL)} />
          </div>
        );
      case DocumentsView.REQUEST_SIGNATURE:
        return (
          <div>
            <div className="flex items-center mb-6">
              <button
                onClick={() => {
                  setView(DocumentsView.DETAIL);
                }}
                className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300 mr-3"
              >
                ← {t('common.back')}
              </button>
              <h1 className="text-2xl font-bold">{t('documents.requestSignature')}</h1>
            </div>
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
              <p className="text-gray-500 dark:text-gray-400 mb-4">
                {t('documents.signatureRequestDescription')}
              </p>
              <p className="text-gray-500">E-signature functionality will be implemented in a future update.</p>
            </div>
          </div>
        );
      case DocumentsView.LIST:
      default:
        return (
          <>
            <div className="flex justify-between items-center mb-6">
              <h1 className="text-2xl font-bold flex items-center">
                <FileText className="h-6 w-6 mr-2" />
                {t('common.documents')}
              </h1>
              <button
                onClick={handleUploadDocument}
                className="flex items-center bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md"
              >
                <Upload className="h-4 w-4 mr-2" />
                {t('documents.uploadDocument')}
              </button>
            </div>
            <DocumentList onViewDocument={handleViewDocument} onUploadDocument={handleUploadDocument} />
          </>
        );
    }
  };
  
  return (
    <MainLayout>
      <div className="container mx-auto py-6 px-4 max-w-7xl">
        {renderContent()}
      </div>
    </MainLayout>
  );
}