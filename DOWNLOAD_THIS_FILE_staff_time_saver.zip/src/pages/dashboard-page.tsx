import React from "react";
import { useTranslation } from "react-i18next";
import { useAuth } from "../hooks/use-auth";
import { Users, FileText, Clock, BarChart3, Calendar, CheckSquare, ArrowRight } from "lucide-react";
import { MainLayout } from "../layouts/MainLayout";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

const DashboardPage: React.FC = () => {
  const { t } = useTranslation();
  const { user } = useAuth();

  // If we somehow end up here without a user, this should never happen
  // because of the ProtectedRoute, but best to be safe
  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <MainLayout>
      <div className="space-y-6 animate-in fade-in duration-500">
        <header className="mb-8">
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
            {t('dashboard.welcomeMessage', { name: user.firstName }) || `Welcome, ${user.firstName}`}
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">
            {t('dashboard.currentDate') || new Date().toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
        </header>

        {/* Quick stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard title={t('dashboard.stats.clients') || "Clients"} value="0" icon={<Users className="h-6 w-6 text-blue-500" />} />
          <StatCard title={t('dashboard.stats.documents') || "Documents"} value="0" icon={<FileText className="h-6 w-6 text-green-500" />} />
          <StatCard title={t('dashboard.stats.tasks') || "Tasks"} value="0" icon={<CheckSquare className="h-6 w-6 text-amber-500" />} />
          <StatCard title={t('dashboard.stats.events') || "Events"} value="0" icon={<Calendar className="h-6 w-6 text-purple-500" />} />
        </div>

        {/* Main content cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
          <DashboardCard 
            title={t('dashboard.recentClients') || "Recent Clients"} 
            icon={<Users className="h-6 w-6 text-blue-500" />}
            actionLink="/clients"
            actionText={t('common.viewAll') || "View All"}
          >
            <p className="text-gray-600 dark:text-gray-400 text-sm">
              {t('dashboard.noClientsYet') || "No clients yet. Add your first client to get started."}
            </p>
            <Button variant="outline" size="sm" className="mt-4" asChild>
              <Link href="/clients/new">
                <a className="flex items-center">
                  {t('dashboard.actions.addClient') || "Add Client"}
                  <ArrowRight className="ml-2 h-4 w-4" />
                </a>
              </Link>
            </Button>
          </DashboardCard>
          
          <DashboardCard 
            title={t('dashboard.pendingDocuments') || "Pending Documents"} 
            icon={<FileText className="h-6 w-6 text-green-500" />}
            actionLink="/documents"
            actionText={t('common.viewAll') || "View All"}
          >
            <p className="text-gray-600 dark:text-gray-400 text-sm">
              {t('dashboard.noDocumentsYet') || "No pending documents. Upload your first document."}
            </p>
            <Button variant="outline" size="sm" className="mt-4" asChild>
              <Link href="/documents/new">
                <a className="flex items-center">
                  {t('dashboard.actions.uploadDocument') || "Upload Document"}
                  <ArrowRight className="ml-2 h-4 w-4" />
                </a>
              </Link>
            </Button>
          </DashboardCard>
          
          <DashboardCard 
            title={t('dashboard.recentActivity') || "Recent Activity"} 
            icon={<Clock className="h-6 w-6 text-amber-500" />}
          >
            <p className="text-gray-600 dark:text-gray-400 text-sm">
              {t('dashboard.noActivityYet') || "No recent activity to display."}
            </p>
          </DashboardCard>
        </div>

        {/* Reports section */}
        <div className="mt-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold">
              {t('dashboard.reports') || "Reports"}
            </h2>
            <Button variant="ghost" size="sm" asChild>
              <Link href="/reports">
                <a className="flex items-center text-sm">
                  {t('common.viewAll') || "View All"}
                  <ArrowRight className="ml-1 h-4 w-4" />
                </a>
              </Link>
            </Button>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
            <div className="flex items-center justify-center h-48 border border-dashed border-gray-300 dark:border-gray-700 rounded-md">
              <div className="text-center">
                <BarChart3 className="h-12 w-12 mx-auto text-gray-400" />
                <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">
                  {t('dashboard.noReportsYet') || "No reports available yet."}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

interface StatCardProps {
  title: string;
  value: string;
  icon: React.ReactNode;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, icon }) => {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-500 dark:text-gray-400">{title}</p>
          <p className="text-2xl font-bold mt-1">{value}</p>
        </div>
        <div className="bg-blue-50 dark:bg-blue-900/20 p-2 rounded-full">
          {icon}
        </div>
      </div>
    </div>
  );
};

interface DashboardCardProps {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  actionLink?: string;
  actionText?: string;
}

const DashboardCard: React.FC<DashboardCardProps> = ({ 
  title, 
  icon, 
  children, 
  actionLink, 
  actionText 
}) => {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-medium">{title}</h3>
        {icon}
      </div>
      <div>
        {children}
      </div>
      {actionLink && actionText && (
        <div className="mt-4 pt-3 border-t border-gray-200 dark:border-gray-700">
          <Link href={actionLink}>
            <a className="text-sm text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 flex items-center">
              {actionText}
              <ArrowRight className="ml-1 h-4 w-4" />
            </a>
          </Link>
        </div>
      )}
    </div>
  );
};

export default DashboardPage;