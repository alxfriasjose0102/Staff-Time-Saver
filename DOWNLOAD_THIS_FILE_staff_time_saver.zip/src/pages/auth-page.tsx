import React, { useState, useEffect, useCallback } from 'react';
import { Link, useLocation } from 'wouter';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../hooks/use-auth';
import { useToast } from '../hooks/use-toast';
import { UserRoleType } from '../../shared/schema';

const AuthPage: React.FC = () => {
  const { t, i18n } = useTranslation();
  const { user, loginMutation, registerMutation } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [isLogin, setIsLogin] = useState(true);
  
  // Form state
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [isCheckingAuth, setIsCheckingAuth] = useState(true);

  // Check for verified email parameter
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const verified = params.get('verified');
    
    if (verified === 'true') {
      toast({
        title: t('auth.emailVerified') || 'Email verified',
        description: t('auth.pleaseLogin') || 'You can now log in with your credentials',
      });
      
      // Remove the query parameter
      window.history.replaceState({}, document.title, window.location.pathname);
    }
    
    setIsCheckingAuth(false);
  }, [toast, t]);

  // Redirect if already logged in
  useEffect(() => {
    if (user && !isCheckingAuth) {
      navigate('/dashboard');
    }
  }, [user, navigate, isCheckingAuth]);

  const handleLoginSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    
    loginMutation.mutate(
      { email, password },
      {
        onSuccess: () => {
          toast({
            title: t('auth.loginSuccess') || 'Login successful',
            description: t('auth.welcomeBack') || 'Welcome back to Staff Time Saver',
          });
          navigate('/dashboard');
        },
        onError: (error) => {
          toast({
            title: t('auth.loginFailed') || 'Login failed',
            description: error.message || t('auth.invalidCredentials') || 'Invalid credentials',
            variant: 'destructive',
          });
        },
      }
    );
  }, [email, password, loginMutation, toast, t, navigate]);

  const handleRegisterSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    
    // Check if passwords match
    if (password !== confirmPassword) {
      toast({
        title: t('auth.registrationFailed') || 'Registration failed',
        description: t('auth.passwordsDontMatch') || 'Passwords do not match',
        variant: 'destructive',
      });
      return;
    }
    
    const role: UserRoleType = 'staff';
    
    registerMutation.mutate(
      { 
        email, 
        password, 
        confirmPassword, 
        firstName, 
        lastName, 
        role
      },
      {
        onSuccess: () => {
          toast({
            title: t('auth.registrationSuccess') || 'Registration successful',
            description: t('auth.accountCreated') || 'Your account has been created',
          });
          navigate('/dashboard');
        },
        onError: (error) => {
          toast({
            title: t('auth.registrationFailed') || 'Registration failed',
            description: error.message || t('auth.registrationError') || 'There was an error during registration',
            variant: 'destructive',
          });
        },
      }
    );
  }, [email, password, confirmPassword, firstName, lastName, registerMutation, toast, t, navigate]);

  const toggleMode = useCallback(() => {
    setIsLogin(!isLogin);
  }, [isLogin]);

  const isSubmitting = loginMutation.isPending || registerMutation.isPending;

  if (isCheckingAuth) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex md:items-center bg-gray-50 dark:bg-gray-900">
      <div className="flex w-full max-w-6xl mx-auto rounded-xl overflow-hidden shadow-lg">
        {/* Hero Section */}
        <div className="hidden md:block md:w-1/2 bg-primary p-12 text-white">
          <h1 className="text-3xl font-bold mb-6">{t('auth.heroTitle') || 'Staff Time Saver'}</h1>
          <p className="mb-8 text-white/90">{t('auth.heroDescription') || 'A comprehensive productivity platform designed specifically for law firms'}</p>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white/10 backdrop-blur-sm p-4 rounded-lg">
              <h3 className="font-medium mb-2">{t('auth.feature1Title') || 'Client Management'}</h3>
              <p className="text-sm text-white/80">{t('auth.feature1Desc') || 'Streamline client intake and communications'}</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm p-4 rounded-lg">
              <h3 className="font-medium mb-2">{t('auth.feature2Title') || 'Document Automation'}</h3>
              <p className="text-sm text-white/80">{t('auth.feature2Desc') || 'Generate and manage legal documents'}</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm p-4 rounded-lg">
              <h3 className="font-medium mb-2">{t('auth.feature3Title') || 'E-Signatures'}</h3>
              <p className="text-sm text-white/80">{t('auth.feature3Desc') || 'Get documents signed electronically'}</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm p-4 rounded-lg">
              <h3 className="font-medium mb-2">{t('auth.feature4Title') || 'Time Tracking'}</h3>
              <p className="text-sm text-white/80">{t('auth.feature4Desc') || 'Accurately track billable hours'}</p>
            </div>
          </div>
          
          <div className="mt-auto pt-6">
            <div className="flex space-x-2">
              <LanguageButton 
                language="en" 
                current={i18n.language} 
                onClick={() => i18n.changeLanguage('en')} 
              />
              <LanguageButton 
                language="es" 
                current={i18n.language} 
                onClick={() => i18n.changeLanguage('es')} 
              />
              <LanguageButton 
                language="ht" 
                current={i18n.language} 
                onClick={() => i18n.changeLanguage('ht')} 
              />
              <LanguageButton 
                language="ru" 
                current={i18n.language} 
                onClick={() => i18n.changeLanguage('ru')} 
              />
            </div>
          </div>
        </div>

        {/* Form Section */}
        <div className="w-full md:w-1/2 bg-white dark:bg-gray-800 p-8 md:p-12">
          <div className="text-center mb-8">
            <Link href="/">
              <span className="text-2xl font-bold text-primary cursor-pointer">
                {t('app.name') || 'Staff Time Saver'}
              </span>
            </Link>
            <h2 className="text-2xl font-bold mt-6">
              {isLogin 
                ? (t('auth.login') || 'Log In') 
                : (t('auth.register') || 'Register')}
            </h2>
            <p className="text-gray-600 dark:text-gray-400 mt-2">
              {isLogin 
                ? (t('auth.loginDescription') || 'Sign in to your account') 
                : (t('auth.registerDescription') || 'Create a new account')}
            </p>
          </div>

          {isLogin ? (
            <form onSubmit={handleLoginSubmit} className="space-y-6">
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t('auth.email') || 'Email'}
                </label>
                <input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary focus:border-primary dark:bg-gray-700"
                />
              </div>

              <div>
                <label htmlFor="password" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t('auth.password') || 'Password'}
                </label>
                <input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary focus:border-primary dark:bg-gray-700"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSubmitting 
                  ? (t('auth.loading') || 'Loading...') 
                  : (t('auth.loginButton') || 'Log In')}
              </button>

              <div className="text-center text-sm">
                <p className="text-gray-600 dark:text-gray-400">
                  {t('auth.noAccount') || "Don't have an account?"}{' '}
                  <button
                    type="button"
                    onClick={toggleMode}
                    className="text-primary hover:text-primary/80"
                  >
                    {t('auth.createAccount') || 'Create one'}
                  </button>
                </p>
              </div>
            </form>
          ) : (
            <form onSubmit={handleRegisterSubmit} className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('auth.firstName') || 'First Name'}
                  </label>
                  <input
                    id="firstName"
                    type="text"
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    required
                    className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary focus:border-primary dark:bg-gray-700"
                  />
                </div>

                <div>
                  <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('auth.lastName') || 'Last Name'}
                  </label>
                  <input
                    id="lastName"
                    type="text"
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    required
                    className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary focus:border-primary dark:bg-gray-700"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="reg-email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t('auth.email') || 'Email'}
                </label>
                <input
                  id="reg-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary focus:border-primary dark:bg-gray-700"
                />
              </div>

              <div>
                <label htmlFor="reg-password" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t('auth.password') || 'Password'}
                </label>
                <input
                  id="reg-password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  minLength={8}
                  className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary focus:border-primary dark:bg-gray-700"
                />
                <p className="text-xs text-gray-500 mt-1">
                  {t('auth.passwordRequirements') || 'Must be at least 8 characters with one uppercase letter, one lowercase letter, and one number'}
                </p>
              </div>

              <div>
                <label htmlFor="confirm-password" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t('auth.confirmPassword') || 'Confirm Password'}
                </label>
                <input
                  id="confirm-password"
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                  className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary focus:border-primary dark:bg-gray-700"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSubmitting 
                  ? (t('auth.loading') || 'Loading...') 
                  : (t('auth.registerButton') || 'Register')}
              </button>

              <div className="text-center text-sm">
                <p className="text-gray-600 dark:text-gray-400">
                  {t('auth.haveAccount') || 'Already have an account?'}{' '}
                  <button
                    type="button"
                    onClick={toggleMode}
                    className="text-primary hover:text-primary/80"
                  >
                    {t('auth.loginInstead') || 'Log in instead'}
                  </button>
                </p>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

interface LanguageButtonProps {
  language: string;
  current: string;
  onClick: () => void;
}

const LanguageButton: React.FC<LanguageButtonProps> = ({ language, current, onClick }) => (
  <button
    type="button"
    onClick={onClick}
    className={`px-2 py-1 text-sm rounded ${
      current === language
        ? 'bg-white/20 text-white'
        : 'text-white/70 hover:text-white hover:bg-white/10'
    }`}
  >
    {language.toUpperCase()}
  </button>
);

export default AuthPage;