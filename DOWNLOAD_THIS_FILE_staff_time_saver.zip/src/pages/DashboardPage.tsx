import { useAuth } from "../hooks/use-auth";
import { Link } from "wouter";
import { useHasPermission, permissions } from "../components/RoleBasedAccess";
import { 
  LogOut, 
  User as UserIcon, 
  FileText, 
  Clock, 
  Briefcase, 
  Users, 
  BarChart,
  Settings,
  ChevronDown
} from "lucide-react";

export default function DashboardPage() {
  const { user, logoutMutation } = useAuth();
  const canViewClients = useHasPermission(permissions.VIEW_CLIENTS);
  const canViewDocuments = useHasPermission(permissions.VIEW_DOCUMENTS);
  const canViewReports = useHasPermission(permissions.VIEW_REPORTS);
  
  // Handle logout
  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Top Navigation */}
      <header className="bg-white shadow-sm">
        <div className="flex justify-between items-center px-4 py-3 lg:px-8">
          <div className="flex items-center space-x-3">
            <span className="text-xl font-bold text-blue-600">Staff Time Saver</span>
          </div>
          <div className="flex items-center space-x-4">
            <div className="relative">
              <button className="flex items-center space-x-1 text-sm text-gray-700 hover:text-blue-600">
                <span>Help</span>
                <ChevronDown className="h-4 w-4 opacity-70" />
              </button>
            </div>
            <div className="relative">
              <button className="flex items-center space-x-2 text-sm">
                <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center">
                  <UserIcon className="h-5 w-5 text-blue-600" />
                </div>
                <span className="text-gray-700 font-medium hidden sm:inline-block">
                  {user?.firstName} {user?.lastName}
                </span>
                <ChevronDown className="h-4 w-4 text-gray-400" />
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex flex-1">
        {/* Sidebar */}
        <aside className="hidden md:flex md:flex-shrink-0">
          <div className="flex flex-col w-64 border-r border-gray-200 bg-white">
            <div className="h-0 flex-1 flex flex-col pt-5 pb-4 overflow-y-auto">
              {/* Sidebar Links */}
              <nav className="mt-5 px-3 space-y-3">
                <Link href="/dashboard">
                  <a className="group flex items-center px-2 py-2 text-sm font-medium rounded-md bg-blue-50 text-blue-700">
                    <BarChart className="mr-3 h-5 w-5 text-blue-500" />
                    Dashboard
                  </a>
                </Link>
                
                {canViewClients && (
                  <Link href="/clients">
                    <a className="group flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900">
                      <Users className="mr-3 h-5 w-5 text-gray-400" />
                      Clients
                    </a>
                  </Link>
                )}
                
                <Link href="/matters">
                  <a className="group flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900">
                    <Briefcase className="mr-3 h-5 w-5 text-gray-400" />
                    Matters
                  </a>
                </Link>
                
                {canViewDocuments && (
                  <Link href="/documents">
                    <a className="group flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900">
                      <FileText className="mr-3 h-5 w-5 text-gray-400" />
                      Documents
                    </a>
                  </Link>
                )}
                
                <Link href="/time-tracking">
                  <a className="group flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900">
                    <Clock className="mr-3 h-5 w-5 text-gray-400" />
                    Time Tracking
                  </a>
                </Link>
                
                {canViewReports && (
                  <Link href="/reports">
                    <a className="group flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900">
                      <BarChart className="mr-3 h-5 w-5 text-gray-400" />
                      Reports
                    </a>
                  </Link>
                )}
                
                <Link href="/settings">
                  <a className="group flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900">
                    <Settings className="mr-3 h-5 w-5 text-gray-400" />
                    Settings
                  </a>
                </Link>
              </nav>
            </div>
            
            <div className="flex-shrink-0 border-t border-gray-200 p-4">
              <button
                onClick={handleLogout}
                className="w-full flex items-center px-2 py-2 text-sm font-medium rounded-md text-red-600 hover:bg-red-50"
              >
                <LogOut className="mr-3 h-5 w-5 text-red-500" />
                Sign out
              </button>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto bg-gray-50 p-6">
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-gray-900">Welcome, {user?.firstName}!</h1>
            <p className="text-gray-500">Here's what's happening today</p>
          </div>

          {/* Dashboard Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {/* Open Matters */}
            <div className="bg-white overflow-hidden shadow rounded-lg">
              <div className="p-5">
                <div className="flex items-center">
                  <div className="flex-shrink-0 bg-blue-50 rounded-md p-3">
                    <Briefcase className="h-6 w-6 text-blue-600" />
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">Open Matters</dt>
                      <dd>
                        <div className="text-lg font-medium text-gray-900">24</div>
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>
            </div>

            {/* Pending Documents */}
            <div className="bg-white overflow-hidden shadow rounded-lg">
              <div className="p-5">
                <div className="flex items-center">
                  <div className="flex-shrink-0 bg-green-50 rounded-md p-3">
                    <FileText className="h-6 w-6 text-green-600" />
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">Pending Documents</dt>
                      <dd>
                        <div className="text-lg font-medium text-gray-900">8</div>
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>
            </div>

            {/* Billable Hours */}
            <div className="bg-white overflow-hidden shadow rounded-lg">
              <div className="p-5">
                <div className="flex items-center">
                  <div className="flex-shrink-0 bg-purple-50 rounded-md p-3">
                    <Clock className="h-6 w-6 text-purple-600" />
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">Billable Hours (This Week)</dt>
                      <dd>
                        <div className="text-lg font-medium text-gray-900">18.5</div>
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>
            </div>

            {/* Active Clients */}
            <div className="bg-white overflow-hidden shadow rounded-lg">
              <div className="p-5">
                <div className="flex items-center">
                  <div className="flex-shrink-0 bg-yellow-50 rounded-md p-3">
                    <Users className="h-6 w-6 text-yellow-600" />
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">Active Clients</dt>
                      <dd>
                        <div className="text-lg font-medium text-gray-900">36</div>
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Recent Activity */}
          <div className="bg-white shadow overflow-hidden sm:rounded-lg mb-8">
            <div className="px-4 py-5 sm:px-6">
              <h3 className="text-lg leading-6 font-medium text-gray-900">Recent Activity</h3>
              <p className="mt-1 max-w-2xl text-sm text-gray-500">Your latest actions and notifications</p>
            </div>
            <div className="border-t border-gray-200">
              <ul className="divide-y divide-gray-200">
                {[
                  { id: 1, title: "Document uploaded", description: "Smith v. Johnson - Complaint", time: "10 minutes ago" },
                  { id: 2, title: "Client meeting scheduled", description: "ABC Corp. - Contract Review", time: "2 hours ago" },
                  { id: 3, title: "Time entry recorded", description: "Williams Matter - 1.5 hours", time: "Yesterday" },
                  { id: 4, title: "Matter status updated", description: "Jones Litigation - Discovery Phase", time: "Yesterday" },
                ].map((activity) => (
                  <li key={activity.id} className="px-4 py-4 sm:px-6 hover:bg-gray-50">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium text-blue-600 truncate">{activity.title}</p>
                      <div className="ml-2 flex-shrink-0 flex">
                        <p className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                          {activity.time}
                        </p>
                      </div>
                    </div>
                    <div className="mt-2 sm:flex sm:justify-between">
                      <div className="sm:flex">
                        <p className="flex items-center text-sm text-gray-500">
                          {activity.description}
                        </p>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Upcoming Deadlines */}
          <div className="bg-white shadow overflow-hidden sm:rounded-lg">
            <div className="px-4 py-5 sm:px-6">
              <h3 className="text-lg leading-6 font-medium text-gray-900">Upcoming Deadlines</h3>
              <p className="mt-1 max-w-2xl text-sm text-gray-500">Key dates for your matters</p>
            </div>
            <div className="border-t border-gray-200">
              <ul className="divide-y divide-gray-200">
                {[
                  { id: 1, title: "Motion Filing Deadline", matter: "Smith v. Johnson", date: "May 10, 2025", urgent: true },
                  { id: 2, title: "Contract Review", matter: "ABC Corp.", date: "May 15, 2025", urgent: false },
                  { id: 3, title: "Discovery Response Due", matter: "Williams Matter", date: "May 20, 2025", urgent: false },
                ].map((deadline) => (
                  <li key={deadline.id} className="px-4 py-4 sm:px-6 hover:bg-gray-50">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium text-gray-900 truncate">{deadline.title}</p>
                      <div className="ml-2 flex-shrink-0 flex">
                        <p className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          deadline.urgent ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'
                        }`}>
                          {deadline.date}
                        </p>
                      </div>
                    </div>
                    <div className="mt-2 sm:flex sm:justify-between">
                      <div className="sm:flex">
                        <p className="flex items-center text-sm text-gray-500">
                          {deadline.matter}
                        </p>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}