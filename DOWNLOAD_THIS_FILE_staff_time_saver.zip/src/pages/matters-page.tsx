import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { MainLayout } from '@/layouts/MainLayout';
import { MatterList } from '@/components/matter/MatterList';
import { MatterDetail } from '@/components/matter/MatterDetail';
import { MatterForm } from '@/components/matter/MatterForm';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function MattersPage() {
  const { t } = useTranslation();
  const [selectedMatterId, setSelectedMatterId] = useState<number | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);

  const handleViewMatter = (id: number) => {
    setSelectedMatterId(id);
    setShowAddForm(false);
  };

  const handleNewMatter = () => {
    setSelectedMatterId(null);
    setShowAddForm(true);
  };

  const handleBack = () => {
    setSelectedMatterId(null);
    setShowAddForm(false);
  };

  const handleEdit = (id: number) => {
    // For future implementation: open matter in edit mode
    console.log('Edit matter', id);
  };

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-6">
        <Tabs defaultValue={showAddForm ? "add" : "list"} value={showAddForm ? "add" : "list"}>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold">{t('matters.title')}</h1>
              <p className="text-gray-500 dark:text-gray-400 mt-1">{t('matters.description')}</p>
            </div>
            <div className="flex items-center mt-4 md:mt-0">
              <TabsList>
                <TabsTrigger
                  value="list"
                  onClick={() => {
                    setShowAddForm(false);
                  }}
                >
                  {t('matters.list')}
                </TabsTrigger>
                <TabsTrigger
                  value="add"
                  onClick={() => {
                    setShowAddForm(true);
                  }}
                >
                  {t('matters.add')}
                </TabsTrigger>
              </TabsList>
            </div>
          </div>

          <TabsContent value="list">
            {selectedMatterId ? (
              <MatterDetail 
                matterId={selectedMatterId} 
                onBack={handleBack} 
                onEdit={handleEdit}
              />
            ) : (
              <MatterList 
                onViewMatter={handleViewMatter} 
                onNewMatter={handleNewMatter}
              />
            )}
          </TabsContent>

          <TabsContent value="add">
            <MatterForm />
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
}