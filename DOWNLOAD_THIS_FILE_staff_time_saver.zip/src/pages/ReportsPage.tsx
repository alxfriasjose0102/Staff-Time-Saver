import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useQuery } from '@tanstack/react-query';
import { 
  BarChart3, 
  Users, 
  FileText, 
  Pen, 
  Calendar, 
  DollarSign,
  Clock,
  ChevronDown,
  Download,
  Filter,
  Loader2
} from 'lucide-react';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { MainLayout } from '../layouts/MainLayout';
import { Button } from '../components/ui/button';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '../components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../components/ui/select';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '../components/ui/tabs';

interface StatCardProps {
  title: string;
  value: string | number;
  description?: string;
  icon: React.ReactNode;
  change?: string;
  isPositive?: boolean;
  isLoading?: boolean;
}

const StatCard: React.FC<StatCardProps> = ({ 
  title, 
  value, 
  description, 
  icon, 
  change, 
  isPositive = true,
  isLoading = false
}) => {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">
          {title}
        </CardTitle>
        <div className="h-4 w-4 text-muted-foreground">
          {icon}
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex items-center space-x-2">
            <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
            <p className="text-sm text-muted-foreground">Loading...</p>
          </div>
        ) : (
          <>
            <div className="text-2xl font-bold">{value}</div>
            {change && (
              <p className={`text-xs ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
                {isPositive ? '+' : ''}{change} from last month
              </p>
            )}
            {description && (
              <p className="text-xs text-muted-foreground">{description}</p>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
};

// Summary statistics type
interface SummaryStats {
  totalClients: number;
  activeClients: number;
  totalDocuments: number;
  pendingSignatures: number;
  completedSignatures: number;
  clientsMonthlyChange: string;
  documentsMonthlyChange: string;
  signaturesMonthlyChange: string;
}

// Client statistics type
interface ClientStats {
  newClients: number;
  returningClients: number;
  clientsByType: {
    individual: number;
    business: number;
    other: number;
  };
  clientsByMonth: {
    month: string;
    count: number;
  }[];
}

// Document statistics type
interface DocumentStats {
  totalUploaded: number;
  totalPending: number;
  totalSigned: number;
  documentsByMonth: {
    month: string;
    uploaded: number;
    signed: number;
  }[];
  documentsByType: {
    type: string;
    count: number;
  }[];
}

export default function ReportsPage() {
  const { t } = useTranslation();
  const [timeRange, setTimeRange] = useState<string>('30d');
  
  // Fetch summary statistics
  const { 
    data: summaryStats, 
    isLoading: isSummaryLoading,
    error: summaryError
  } = useQuery<SummaryStats>({
    queryKey: ['/api/reports/summary', timeRange],
    queryFn: async () => {
      const response = await fetch(`/api/reports/summary?timeRange=${timeRange}`, {
        credentials: 'include',
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch summary statistics');
      }
      
      return response.json();
    },
  });
  
  // Fetch client statistics
  const { 
    data: clientStats, 
    isLoading: isClientStatsLoading,
    error: clientStatsError
  } = useQuery<ClientStats>({
    queryKey: ['/api/reports/clients', timeRange],
    queryFn: async () => {
      const response = await fetch(`/api/reports/clients?timeRange=${timeRange}`, {
        credentials: 'include',
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch client statistics');
      }
      
      return response.json();
    },
  });
  
  // Fetch document statistics
  const { 
    data: documentStats, 
    isLoading: isDocumentStatsLoading,
    error: documentStatsError
  } = useQuery<DocumentStats>({
    queryKey: ['/api/reports/documents', timeRange],
    queryFn: async () => {
      const response = await fetch(`/api/reports/documents?timeRange=${timeRange}`, {
        credentials: 'include',
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch document statistics');
      }
      
      return response.json();
    },
  });
  
  const handleTimeRangeChange = (value: string) => {
    setTimeRange(value);
  };
  
  const handleExportReport = (format: 'pdf' | 'csv') => {
    // Download report implementation
    console.log(`Exporting report in ${format} format`);
  };
  
  return (
    <MainLayout>
      <div className="container mx-auto py-6 px-4 max-w-7xl">
        <div className="flex flex-col space-y-6">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold flex items-center">
                <BarChart3 className="h-6 w-6 mr-2" />
                {t('reports.title')}
              </h1>
              <p className="text-muted-foreground">{t('reports.description')}</p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-2">
              <Select 
                defaultValue={timeRange} 
                onValueChange={handleTimeRangeChange}
              >
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Select time range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7d">{t('reports.timeRange.7days')}</SelectItem>
                  <SelectItem value="30d">{t('reports.timeRange.30days')}</SelectItem>
                  <SelectItem value="90d">{t('reports.timeRange.90days')}</SelectItem>
                  <SelectItem value="year">{t('reports.timeRange.year')}</SelectItem>
                  <SelectItem value="all">{t('reports.timeRange.allTime')}</SelectItem>
                </SelectContent>
              </Select>
              
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleExportReport('pdf')}
                  className="flex items-center gap-1"
                >
                  <Download className="h-4 w-4" />
                  PDF
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleExportReport('csv')}
                  className="flex items-center gap-1"
                >
                  <Download className="h-4 w-4" />
                  CSV
                </Button>
              </div>
            </div>
          </div>
          
          {/* Summary Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard
              title={t('reports.stats.totalClients')}
              value={summaryStats?.totalClients || 0}
              icon={<Users className="h-4 w-4" />}
              change={summaryStats?.clientsMonthlyChange}
              isPositive={true}
              isLoading={isSummaryLoading}
            />
            <StatCard
              title={t('reports.stats.totalDocuments')}
              value={summaryStats?.totalDocuments || 0}
              icon={<FileText className="h-4 w-4" />}
              change={summaryStats?.documentsMonthlyChange}
              isPositive={true}
              isLoading={isSummaryLoading}
            />
            <StatCard
              title={t('reports.stats.pendingSignatures')}
              value={summaryStats?.pendingSignatures || 0}
              icon={<Pen className="h-4 w-4" />}
              description={t('reports.stats.awaitingSignature')}
              isLoading={isSummaryLoading}
            />
            <StatCard
              title={t('reports.stats.completedSignatures')}
              value={summaryStats?.completedSignatures || 0}
              icon={<Pen className="h-4 w-4" />}
              change={summaryStats?.signaturesMonthlyChange}
              isPositive={true}
              isLoading={isSummaryLoading}
            />
          </div>
          
          {/* Detailed Reports */}
          <Card className="col-span-4">
            <CardHeader>
              <CardTitle>{t('reports.detailedReports')}</CardTitle>
              <CardDescription>
                {t('reports.detailedDescription')}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="clients">
                <TabsList>
                  <TabsTrigger value="clients">
                    <Users className="h-4 w-4 mr-2" />
                    {t('reports.tabs.clients')}
                  </TabsTrigger>
                  <TabsTrigger value="documents">
                    <FileText className="h-4 w-4 mr-2" />
                    {t('reports.tabs.documents')}
                  </TabsTrigger>
                  <TabsTrigger value="signatures">
                    <Pen className="h-4 w-4 mr-2" />
                    {t('reports.tabs.signatures')}
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="clients" className="space-y-4">
                  {isClientStatsLoading ? (
                    <div className="flex items-center justify-center h-52">
                      <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
                    </div>
                  ) : clientStatsError ? (
                    <div className="p-4 text-center text-red-500">
                      <p>{t('reports.errorLoading')}</p>
                      <p className="text-sm">{(clientStatsError as Error).message}</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <StatCard
                          title={t('reports.clients.new')}
                          value={clientStats?.newClients || 0}
                          icon={<Users className="h-4 w-4" />}
                        />
                        <StatCard
                          title={t('reports.clients.returning')}
                          value={clientStats?.returningClients || 0}
                          icon={<Users className="h-4 w-4" />}
                        />
                        <StatCard
                          title={t('reports.clients.total')}
                          value={(clientStats?.newClients || 0) + (clientStats?.returningClients || 0)}
                          icon={<Users className="h-4 w-4" />}
                        />
                      </div>
                      
                      <div className="border rounded-lg p-4">
                        <h3 className="font-medium mb-4">{t('reports.clients.byType')}</h3>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div className="p-4 border rounded-lg flex flex-col items-center">
                            <span className="text-lg font-semibold">{clientStats?.clientsByType?.individual || 0}</span>
                            <span className="text-sm text-muted-foreground">{t('reports.clients.individual')}</span>
                          </div>
                          <div className="p-4 border rounded-lg flex flex-col items-center">
                            <span className="text-lg font-semibold">{clientStats?.clientsByType?.business || 0}</span>
                            <span className="text-sm text-muted-foreground">{t('reports.clients.business')}</span>
                          </div>
                          <div className="p-4 border rounded-lg flex flex-col items-center">
                            <span className="text-lg font-semibold">{clientStats?.clientsByType?.other || 0}</span>
                            <span className="text-sm text-muted-foreground">{t('reports.clients.other')}</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="border rounded-lg p-4">
                        <h3 className="font-medium mb-4">{t('reports.clients.byMonth')}</h3>
                        <div className="h-64">
                          {clientStats?.clientsByMonth && clientStats.clientsByMonth.length > 0 ? (
                            <ResponsiveContainer width="100%" height="100%">
                              <BarChart
                                data={clientStats.clientsByMonth}
                                margin={{
                                  top: 5,
                                  right: 30,
                                  left: 20,
                                  bottom: 5,
                                }}
                              >
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="month" />
                                <YAxis />
                                <Tooltip />
                                <Legend />
                                <Bar dataKey="count" fill="#3b82f6" name={t('reports.clients.newClients')} />
                              </BarChart>
                            </ResponsiveContainer>
                          ) : (
                            <div className="h-full flex items-center justify-center">
                              <p className="text-muted-foreground">{t('reports.noData')}</p>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  )}
                </TabsContent>
                
                <TabsContent value="documents" className="space-y-4">
                  {isDocumentStatsLoading ? (
                    <div className="flex items-center justify-center h-52">
                      <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
                    </div>
                  ) : documentStatsError ? (
                    <div className="p-4 text-center text-red-500">
                      <p>{t('reports.errorLoading')}</p>
                      <p className="text-sm">{(documentStatsError as Error).message}</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <StatCard
                          title={t('reports.documents.total')}
                          value={documentStats?.totalUploaded || 0}
                          icon={<FileText className="h-4 w-4" />}
                        />
                        <StatCard
                          title={t('reports.documents.pending')}
                          value={documentStats?.totalPending || 0}
                          icon={<Clock className="h-4 w-4" />}
                        />
                        <StatCard
                          title={t('reports.documents.signed')}
                          value={documentStats?.totalSigned || 0}
                          icon={<Pen className="h-4 w-4" />}
                        />
                      </div>
                      
                      <div className="border rounded-lg p-4">
                        <h3 className="font-medium mb-4">{t('reports.documents.byMonth')}</h3>
                        <div className="h-64">
                          {documentStats?.documentsByMonth && documentStats.documentsByMonth.length > 0 ? (
                            <ResponsiveContainer width="100%" height="100%">
                              <LineChart
                                data={documentStats.documentsByMonth}
                                margin={{
                                  top: 5,
                                  right: 30,
                                  left: 20,
                                  bottom: 5,
                                }}
                              >
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="month" />
                                <YAxis />
                                <Tooltip />
                                <Legend />
                                <Line 
                                  type="monotone" 
                                  dataKey="uploaded" 
                                  stroke="#3b82f6" 
                                  name={t('reports.documents.uploaded')} 
                                  activeDot={{ r: 8 }} 
                                />
                                <Line 
                                  type="monotone" 
                                  dataKey="signed" 
                                  stroke="#10b981" 
                                  name={t('reports.documents.signedDocs')} 
                                />
                              </LineChart>
                            </ResponsiveContainer>
                          ) : (
                            <div className="h-full flex items-center justify-center">
                              <p className="text-muted-foreground">{t('reports.noData')}</p>
                            </div>
                          )}
                        </div>
                      </div>
                      
                      <div className="border rounded-lg p-4">
                        <h3 className="font-medium mb-4">{t('reports.documents.byType')}</h3>
                        <div className="h-64">
                          {documentStats?.documentsByType && documentStats.documentsByType.length > 0 ? (
                            <ResponsiveContainer width="100%" height="100%">
                              <PieChart>
                                <Pie
                                  data={documentStats.documentsByType}
                                  cx="50%"
                                  cy="50%"
                                  labelLine={true}
                                  outerRadius={80}
                                  fill="#8884d8"
                                  dataKey="count"
                                  nameKey="type"
                                  label={({ name, percent }: { name: string; percent: number }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                                >
                                  {documentStats.documentsByType.map((entry, index) => (
                                    <Cell 
                                      key={`cell-${index}`} 
                                      fill={[
                                        '#3b82f6', 
                                        '#10b981', 
                                        '#8b5cf6', 
                                        '#ef4444', 
                                        '#f59e0b'
                                      ][index % 5]} 
                                    />
                                  ))}
                                </Pie>
                                <Tooltip formatter={(value, name) => [value, name]} />
                                <Legend />
                              </PieChart>
                            </ResponsiveContainer>
                          ) : (
                            <div className="h-full flex items-center justify-center">
                              <p className="text-muted-foreground">{t('reports.noData')}</p>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  )}
                </TabsContent>
                
                <TabsContent value="signatures" className="space-y-4">
                  <div className="flex items-center justify-center h-52">
                    <p className="text-muted-foreground">{t('reports.comingSoon')}</p>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </MainLayout>
  );
}