import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useQuery, useMutation } from '@tanstack/react-query';
import { 
  Loader2, 
  FileText, 
  CheckCircle2, 
  AlertCircle, 
  X,
  ArrowLeft
} from 'lucide-react';
import { Button } from '../components/ui/button';
import { SignaturePad } from '../components/SignaturePad';

interface SignatureRequest {
  id: string;
  documentId: number;
  document: {
    id: number;
    title: string;
    fileName?: string;
    fileUrl?: string;
  };
  sender: {
    firstName: string;
    lastName: string;
    email: string;
  };
  status: 'Pending' | 'Completed' | 'Expired' | 'Canceled';
  expiresAt: string;
  message?: string;
}

export default function SignDocumentPage() {
  const { t } = useTranslation();
  const { token } = useParams<{ token: string }>();
  const navigate = useNavigate();
  
  const [signatureData, setSignatureData] = useState<string | null>(null);
  const [signingCompleted, setSigningCompleted] = useState(false);
  
  // Fetch signature request details
  const { 
    data: request, 
    isLoading, 
    error 
  } = useQuery<SignatureRequest>({
    queryKey: [`/api/signature-requests/public/${token}`],
    queryFn: async () => {
      if (!token) throw new Error('Invalid signature token');
      
      const response = await fetch(`/api/signature-requests/public/${token}`);
      
      if (!response.ok) {
        if (response.status === 404) {
          throw new Error('This signature request does not exist or has expired');
        } else if (response.status === 410) {
          throw new Error('This signature request has already been completed');
        } else {
          throw new Error('Failed to load signature request');
        }
      }
      
      return response.json();
    },
  });
  
  // Submit signature mutation
  const submitSignatureMutation = useMutation({
    mutationFn: async () => {
      if (!token || !signatureData) {
        throw new Error('Signature is required');
      }
      
      const response = await fetch(`/api/signature-requests/sign/${token}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ signature: signatureData }),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to submit signature');
      }
      
      return response.json();
    },
    onSuccess: () => {
      setSigningCompleted(true);
    },
  });
  
  const handleSignatureChange = (dataUrl: string | null) => {
    setSignatureData(dataUrl);
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!signatureData) {
      alert(t('signatures.signatureRequired'));
      return;
    }
    
    submitSignatureMutation.mutate();
  };
  
  const handleClose = () => {
    navigate('/');
  };
  
  // Show loading state
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <div className="flex flex-col items-center p-8">
          <Loader2 className="h-12 w-12 animate-spin text-blue-500 mb-4" />
          <h1 className="text-xl font-medium text-gray-700 dark:text-gray-300">
            {t('signatures.loadingRequest')}
          </h1>
        </div>
      </div>
    );
  }
  
  // Show error state
  if (error || !request) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <div className="max-w-md bg-white dark:bg-gray-800 shadow-lg rounded-lg p-8 text-center">
          <AlertCircle className="h-16 w-16 text-red-500 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-800 dark:text-white mb-2">
            {t('signatures.requestError')}
          </h1>
          <p className="text-gray-600 dark:text-gray-300 mb-6">
            {(error as Error)?.message || t('signatures.genericError')}
          </p>
          <Button onClick={handleClose}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            {t('common.goToHomepage')}
          </Button>
        </div>
      </div>
    );
  }
  
  // Show completed state
  if (signingCompleted || request.status === 'Completed') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <div className="max-w-md bg-white dark:bg-gray-800 shadow-lg rounded-lg p-8 text-center">
          <CheckCircle2 className="h-16 w-16 text-green-500 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-800 dark:text-white mb-2">
            {t('signatures.thankYou')}
          </h1>
          <p className="text-gray-600 dark:text-gray-300 mb-6">
            {t('signatures.documentSigned')}
          </p>
          <Button onClick={handleClose}>
            {t('common.close')}
          </Button>
        </div>
      </div>
    );
  }
  
  // Show expired or canceled state
  if (request.status === 'Expired' || request.status === 'Canceled') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <div className="max-w-md bg-white dark:bg-gray-800 shadow-lg rounded-lg p-8 text-center">
          <X className="h-16 w-16 text-red-500 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-800 dark:text-white mb-2">
            {request.status === 'Expired' 
              ? t('signatures.requestExpired') 
              : t('signatures.requestCanceled')}
          </h1>
          <p className="text-gray-600 dark:text-gray-300 mb-6">
            {t('signatures.noLongerAvailable')}
          </p>
          <Button onClick={handleClose}>
            {t('common.close')}
          </Button>
        </div>
      </div>
    );
  }
  
  // Show signing form
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white dark:bg-gray-800 shadow-lg rounded-lg overflow-hidden">
          {/* Header */}
          <div className="bg-blue-600 dark:bg-blue-700 p-6 text-white">
            <h1 className="text-2xl font-bold">{t('signatures.signDocumentTitle')}</h1>
            <p className="mt-2 opacity-90">
              {t('signatures.signRequestFrom', { name: `${request.sender.firstName} ${request.sender.lastName}` })}
            </p>
          </div>
          
          {/* Content */}
          <div className="p-6">
            {/* Document information */}
            <div className="mb-8 p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
              <div className="flex items-start">
                <FileText className="h-8 w-8 text-blue-500 mr-3" />
                <div>
                  <h2 className="font-semibold text-lg">{request.document.title}</h2>
                  {request.document.fileName && (
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {request.document.fileName}
                    </p>
                  )}
                  {request.message && (
                    <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-900/30 rounded text-sm">
                      <p className="text-gray-800 dark:text-gray-200 italic">"{request.message}"</p>
                    </div>
                  )}
                  <div className="mt-3">
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {t('signatures.expiresOn', { 
                        date: new Date(request.expiresAt).toLocaleDateString() 
                      })}
                    </p>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Document preview */}
            {request.document.fileUrl && (
              <div className="mb-8">
                <h3 className="font-medium mb-3">{t('signatures.documentPreview')}</h3>
                <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-lg h-64 overflow-hidden flex items-center justify-center">
                  {request.document.fileUrl.endsWith('.pdf') ? (
                    <div className="text-center">
                      <FileText className="h-12 w-12 text-gray-400 dark:text-gray-500 mx-auto mb-3" />
                      <p className="text-gray-500 dark:text-gray-400 mb-3">
                        {t('signatures.pdfPreviewNotAvailable')}
                      </p>
                      <a 
                        href={request.document.fileUrl} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-blue-600 dark:text-blue-400 hover:underline text-sm"
                      >
                        {t('signatures.openInNewTab')}
                      </a>
                    </div>
                  ) : (
                    <img 
                      src={request.document.fileUrl}
                      alt={request.document.title}
                      className="max-h-full max-w-full object-contain"
                    />
                  )}
                </div>
              </div>
            )}
            
            {/* Signature pad */}
            <form onSubmit={handleSubmit}>
              <h3 className="font-medium mb-3">{t('signatures.yourSignature')}</h3>
              <div className="mx-auto" style={{ maxWidth: '400px' }}>
                <SignaturePad onChange={handleSignatureChange} width={400} height={200} />
              </div>
              
              <div className="mt-8 flex justify-end gap-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleClose}
                >
                  {t('common.cancel')}
                </Button>
                <Button
                  type="submit"
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                  disabled={!signatureData || submitSignatureMutation.isPending}
                >
                  {submitSignatureMutation.isPending ? (
                    <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> {t('common.processing')}</>
                  ) : (
                    <><CheckCircle2 className="mr-2 h-4 w-4" /> {t('signatures.signDocument')}</>
                  )}
                </Button>
              </div>
            </form>
          </div>
        </div>
        
        <div className="mt-8 text-center text-sm text-gray-500 dark:text-gray-400">
          <p>{t('signatures.legalDisclaimer')}</p>
        </div>
      </div>
    </div>
  );
}