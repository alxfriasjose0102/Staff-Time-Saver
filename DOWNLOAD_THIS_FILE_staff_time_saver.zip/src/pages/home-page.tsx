import React, { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "../hooks/use-auth";

const HomePage: React.FC = () => {
  const { user } = useAuth();
  const [, navigate] = useLocation();

  // Redirect authenticated users to dashboard, unauthenticated to auth page
  useEffect(() => {
    if (user) {
      navigate("/dashboard");
    } else {
      navigate("/auth");
    }
  }, [user, navigate]);

  return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
    </div>
  );
};

export default HomePage;