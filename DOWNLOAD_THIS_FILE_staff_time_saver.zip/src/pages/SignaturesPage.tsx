import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { 
  Pen, 
  ArrowLeft
} from 'lucide-react';
import { MainLayout } from '../layouts/MainLayout';
import { Button } from '../components/ui/button';
import { SignatureRequestForm } from '../components/SignatureRequestForm';
import { SignatureRequestList } from '../components/SignatureRequestList';

enum SignaturesView {
  LIST = 'list',
  REQUEST_SIGNATURE = 'request_signature',
}

export default function SignaturesPage() {
  const { t } = useTranslation();
  const [view, setView] = useState<SignaturesView>(SignaturesView.LIST);
  const [selectedDocumentId, setSelectedDocumentId] = useState<number | null>(null);
  
  const handleRequestSignature = (documentId: number) => {
    setSelectedDocumentId(documentId);
    setView(SignaturesView.REQUEST_SIGNATURE);
  };
  
  const handleBackToList = () => {
    setView(SignaturesView.LIST);
    setSelectedDocumentId(null);
  };
  
  // Render the appropriate view
  const renderContent = () => {
    switch (view) {
      case SignaturesView.REQUEST_SIGNATURE:
        return (
          <div>
            <div className="flex items-center mb-6">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleBackToList}
                className="gap-1"
              >
                <ArrowLeft className="h-4 w-4" />
                {t('common.back')}
              </Button>
              <h1 className="text-2xl font-bold ml-4">{t('signatures.requestSignature')}</h1>
            </div>
            
            {selectedDocumentId && (
              <SignatureRequestForm 
                documentId={selectedDocumentId}
                onCancel={handleBackToList}
                onSuccess={handleBackToList}
              />
            )}
          </div>
        );
      case SignaturesView.LIST:
      default:
        return (
          <>
            <div className="flex justify-between items-center mb-6">
              <h1 className="text-2xl font-bold flex items-center">
                <Pen className="h-6 w-6 mr-2" />
                {t('common.signatures')}
              </h1>
            </div>
            
            <SignatureRequestList
              onViewSignatureRequest={() => {}} 
              onNewSignatureRequest={() => handleRequestSignature(1)}
            />
          </>
        );
    }
  };
  
  return (
    <MainLayout>
      <div className="container mx-auto py-6 px-4 max-w-7xl">
        {renderContent()}
      </div>
    </MainLayout>
  );
}