import { useState, useEffect } from "react";
import { Redirect, useLocation } from "wouter";
import { useTranslation } from "react-i18next";
import { useAuth } from "../hooks/use-auth";
import { useToast } from "../hooks/use-toast";
import { Loader2, Mail, Lock, User, Briefcase } from "lucide-react";
import { UserRoleType } from "../../shared/schema";
import { LanguageSelector } from "../components/ui/language-selector";

export default function AuthPage() {
  const [isLogin, setIsLogin] = useState(true);
  const { t } = useTranslation();
  const { toast } = useToast();
  const { user, loginMutation, registerMutation } = useAuth();
  const [, setLocation] = useLocation();
  
  // Watch for successful login/registration
  useEffect(() => {
    if (user) {
      // Redirect to dashboard on successful auth
      setLocation('/dashboard');
    }
  }, [user, setLocation]);
  
  // If already authenticated, redirect to dashboard
  if (user) {
    return <Redirect to="/dashboard" />;
  }

  // Login handler
  const handleLogin = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const formData = new FormData(form);
    
    const email = formData.get("email") as string;
    const password = formData.get("password") as string;
    
    // Basic validation
    if (!email || !password) {
      toast({
        title: t('auth.validationError') || "Validation Error",
        description: t('auth.allFieldsRequired') || "All fields are required",
        variant: "destructive",
      });
      return;
    }
    
    // Email format validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      toast({
        title: t('auth.invalidEmail') || "Invalid Email",
        description: t('auth.invalidEmailDesc') || "Please enter a valid email address",
        variant: "destructive",
      });
      return;
    }

    // Display loading toast
    toast({
      title: t('auth.authenticating') || "Authenticating...",
      description: t('auth.pleaseWait') || "Please wait while we log you in",
    });
    
    // Execute login mutation
    loginMutation.mutate({
      email,
      password,
    });
  };

  // Register handler
  const handleRegister = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const formData = new FormData(form);
    
    const email = formData.get("email") as string;
    const password = formData.get("password") as string;
    const confirmPassword = formData.get("confirmPassword") as string;
    const firstName = formData.get("firstName") as string;
    const lastName = formData.get("lastName") as string;
    const role = formData.get("role") as UserRoleType;
    
    // Basic validation
    if (!email || !password || !confirmPassword || !firstName || !lastName || !role) {
      toast({
        title: t('auth.validationError') || "Validation Error",
        description: t('auth.allFieldsRequired') || "All fields are required",
        variant: "destructive",
      });
      return;
    }
    
    // Email format validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      toast({
        title: t('auth.invalidEmail') || "Invalid Email",
        description: t('auth.invalidEmailDesc') || "Please enter a valid email address",
        variant: "destructive",
      });
      return;
    }
    
    // Password strength validation
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;
    if (!passwordRegex.test(password)) {
      toast({
        title: t('auth.weakPassword') || "Weak Password",
        description: t('auth.passwordRequirements') || "Must be at least 8 characters with 1 uppercase, 1 lowercase, and 1 number.",
        variant: "destructive",
      });
      return;
    }
    
    // Validate passwords match
    if (password !== confirmPassword) {
      toast({
        title: t('auth.passwordMismatch') || "Passwords don't match",
        description: t('auth.passwordMismatchDesc') || "Please ensure both passwords are identical",
        variant: "destructive",
      });
      return;
    }
    
    // Name validation
    if (firstName.length < 2 || lastName.length < 2) {
      toast({
        title: t('auth.invalidName') || "Invalid Name",
        description: t('auth.nameRequirements') || "First and last names must be at least 2 characters",
        variant: "destructive",
      });
      return;
    }
    
    // Display loading toast
    toast({
      title: t('auth.creatingAccount') || "Creating account...",
      description: t('auth.pleaseWaitAccount') || "Please wait while we create your account",
    });
    
    // Execute registration mutation
    registerMutation.mutate({
      email,
      password,
      firstName,
      lastName,
      role,
      confirmPassword,
    });
  };

  return (
    <div className="min-h-screen flex bg-gray-50">
      {/* Left side - Form */}
      <div className="flex flex-col justify-center px-4 py-12 sm:px-6 lg:flex-none lg:px-20 xl:px-24 w-full lg:w-1/2">
        <div className="absolute top-4 right-4">
          <LanguageSelector />
        </div>
        <div className="mx-auto w-full max-w-sm lg:w-96">
          <div className="text-center">
            <h2 className="mt-6 text-3xl font-bold tracking-tight text-gray-900">
              {isLogin 
                ? t('auth.signInTitle') || "Sign in to your account" 
                : t('auth.createAccountTitle') || "Create your account"
              }
            </h2>
            <p className="mt-2 text-sm text-gray-600">
              {isLogin 
                ? t('auth.noAccount') || "Don't have an account? " 
                : t('auth.hasAccount') || "Already have an account? "
              }
              <button
                onClick={() => setIsLogin(!isLogin)}
                className="font-medium text-blue-600 hover:text-blue-500"
              >
                {isLogin 
                  ? t('auth.signUp') || "Sign up" 
                  : t('auth.signIn') || "Sign in"
                }
              </button>
            </p>
          </div>

          <div className="mt-8">
            {/* Login Form */}
            {isLogin ? (
              <form onSubmit={handleLogin} className="space-y-6">
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                    {t('auth.emailAddress') || "Email address"}
                  </label>
                  <div className="mt-1 relative rounded-md shadow-sm">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Mail className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                      id="email"
                      name="email"
                      type="email"
                      autoComplete="email"
                      required
                      className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                      placeholder="you@example.com"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                    {t('auth.password') || "Password"}
                  </label>
                  <div className="mt-1 relative rounded-md shadow-sm">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Lock className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                      id="password"
                      name="password"
                      type="password"
                      autoComplete="current-password"
                      required
                      className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                      placeholder="••••••••"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <input
                      id="remember-me"
                      name="remember-me"
                      type="checkbox"
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    />
                    <label htmlFor="remember-me" className="ml-2 block text-sm text-gray-900">
                      {t('auth.rememberMe') || "Remember me"}
                    </label>
                  </div>

                  <div className="text-sm">
                    <a href="#" className="font-medium text-blue-600 hover:text-blue-500">
                      {t('auth.forgotPassword') || "Forgot your password?"}
                    </a>
                  </div>
                </div>

                <div>
                  <button
                    type="submit"
                    disabled={loginMutation.isPending}
                    className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-70 disabled:cursor-not-allowed"
                  >
                    {loginMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        {t('auth.signingIn') || "Signing in..."}
                      </>
                    ) : (
                      t('auth.signIn') || "Sign in"
                    )}
                  </button>
                </div>
              </form>
            ) : (
              /* Registration Form */
              <form onSubmit={handleRegister} className="space-y-6">
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div>
                    <label htmlFor="firstName" className="block text-sm font-medium text-gray-700">
                      {t('auth.firstName') || "First name"}
                    </label>
                    <div className="mt-1 relative rounded-md shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <User className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        id="firstName"
                        name="firstName"
                        type="text"
                        autoComplete="given-name"
                        required
                        className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                        placeholder="John"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="lastName" className="block text-sm font-medium text-gray-700">
                      {t('auth.lastName') || "Last name"}
                    </label>
                    <div className="mt-1 relative rounded-md shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <User className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        id="lastName"
                        name="lastName"
                        type="text"
                        autoComplete="family-name"
                        required
                        className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                        placeholder="Doe"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                    {t('auth.emailAddress') || "Email address"}
                  </label>
                  <div className="mt-1 relative rounded-md shadow-sm">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Mail className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                      id="email"
                      name="email"
                      type="email"
                      autoComplete="email"
                      required
                      className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                      placeholder="you@example.com"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="role" className="block text-sm font-medium text-gray-700">
                    {t('auth.role') || "Role"}
                  </label>
                  <div className="mt-1 relative rounded-md shadow-sm">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Briefcase className="h-5 w-5 text-gray-400" />
                    </div>
                    <select
                      id="role"
                      name="role"
                      required
                      className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    >
                      <option value="staff">{t('auth.roleStaff') || "Staff"}</option>
                      <option value="paralegal">{t('auth.roleParalegal') || "Paralegal"}</option>
                      <option value="attorney">{t('auth.roleAttorney') || "Attorney"}</option>
                      <option value="admin">{t('auth.roleAdmin') || "Administrator"}</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                    {t('auth.password') || "Password"}
                  </label>
                  <div className="mt-1 relative rounded-md shadow-sm">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Lock className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                      id="password"
                      name="password"
                      type="password"
                      autoComplete="new-password"
                      required
                      minLength={8}
                      className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                      placeholder="••••••••"
                    />
                  </div>
                  <p className="mt-1 text-xs text-gray-500">
                    {t('auth.passwordRequirements') || "Must be at least 8 characters with 1 uppercase, 1 lowercase, and 1 number."}
                  </p>
                </div>

                <div>
                  <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700">
                    {t('auth.confirmPassword') || "Confirm Password"}
                  </label>
                  <div className="mt-1 relative rounded-md shadow-sm">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Lock className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                      id="confirmPassword"
                      name="confirmPassword"
                      type="password"
                      autoComplete="new-password"
                      required
                      className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                      placeholder="••••••••"
                    />
                  </div>
                </div>

                <div>
                  <button
                    type="submit"
                    disabled={registerMutation.isPending}
                    className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-70 disabled:cursor-not-allowed"
                  >
                    {registerMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        {t('auth.creatingAccount') || "Creating account..."}
                      </>
                    ) : (
                      t('auth.createAccount') || "Create account"
                    )}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>

      {/* Right side - Hero/Info */}
      <div className="hidden lg:block relative w-0 flex-1 bg-blue-600">
        <div className="flex flex-col justify-center h-full p-12 text-white">
          <div className="max-w-xl">
            <h2 className="text-4xl font-bold mb-6">Staff Time Saver</h2>
            <p className="text-xl mb-8 text-blue-100">
              Increase productivity, streamline workflows, and enhance collaboration within your legal practice.
            </p>

            <div className="space-y-4">
              <div className="flex items-start">
                <div className="flex-shrink-0 h-6 w-6 bg-blue-400 rounded-full flex items-center justify-center">
                  <svg className="h-4 w-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <p className="ml-3 text-blue-100">Secure document management</p>
              </div>
              <div className="flex items-start">
                <div className="flex-shrink-0 h-6 w-6 bg-blue-400 rounded-full flex items-center justify-center">
                  <svg className="h-4 w-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <p className="ml-3 text-blue-100">Efficient time tracking</p>
              </div>
              <div className="flex items-start">
                <div className="flex-shrink-0 h-6 w-6 bg-blue-400 rounded-full flex items-center justify-center">
                  <svg className="h-4 w-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <p className="ml-3 text-blue-100">Simplified client management</p>
              </div>
              <div className="flex items-start">
                <div className="flex-shrink-0 h-6 w-6 bg-blue-400 rounded-full flex items-center justify-center">
                  <svg className="h-4 w-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <p className="ml-3 text-blue-100">Comprehensive reporting</p>
              </div>
            </div>

            <blockquote className="mt-8 border-l-4 border-blue-400 pl-4 py-2">
              <p className="italic text-blue-100">
                "Staff Time Saver has revolutionized how our law firm manages cases and client communications. 
                The time savings and increased organization have been remarkable."
              </p>
              <footer className="mt-2 text-blue-200">
                <strong>Jane Doe</strong> • Managing Partner, Doe & Associates
              </footer>
            </blockquote>
          </div>
        </div>
      </div>
    </div>
  );
}