// netlify/functions/api.js
import express from 'express';
import serverless from 'serverless-http';
import { setupAuth } from '../../server/auth';
import { db } from '../../server/db';
import bodyParser from 'body-parser';
import cors from 'cors';

// Initialize express app
const app = express();

// Middleware
app.use(cors({
  origin: process.env.URL || 'http://localhost:8888',
  credentials: true
}));
app.use(bodyParser.json());

// Setup authentication
setupAuth(app);

// API routes
app.get('/.netlify/functions/api/ping', (req, res) => {
  res.json({ message: 'API is working!' });
});

// Import your existing API routes
// Note: You may need to adjust these imports based on your project structure
const { registerRoutes } = require('../../server/routes');
registerRoutes(app);

// This is the format required for Netlify Functions
export const handler = serverless(app);